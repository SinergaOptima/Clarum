# Peer-Reviewed Anchors — Index

*Academic validation for LRF-1 Domains.*

## A1: Regulatory Stability
- **Anchor:** Kaufmann, D., Kraay, A., & Mastruzzi, M. (2010). *The Worldwide Governance Indicators: Methodology and Analytical Issues*.
- **Concept:** Defines "Regulatory Quality" and "Rule of Law" as measurable constructs.

## A2: Geopolitics
- **Anchor:** Davis, D. R., & Weinstein, D. E. (2002). *Bonuses or Wagers: Trade and Conflict*.
- **Concept:** Link between trade openness and conflict probability.

## A3: Industrial Policy
- **Anchor:** Rodrik, D. (2004). *Industrial Policy for the Twenty-First Century*.
- **Concept:** Framework for distinguishing rent-seeking from developmental policy.

## A4: Infrastructure
- **Anchor:** Arvis, J. F., et al. (2018). *Connecting to Compete: Trade Logistics in the Global Economy*.
- **Concept:** LPI methodology (Efficiency of customs, infrastructure quality).

## A5: Supply Chain
- **Anchor:** Gereffi, G., & Lee, J. (2012). *Why the World Suddenly Cares About Global Supply Chains*.
- **Concept:** Global Value Chain (GVC) governance types.

## A6: Labor
- **Anchor:** Hanushek, E. A., & Woessmann, L. (2008). *The Role of Cognitive Skills in Economic Development*.
- **Concept:** Quality of education vs. quantity.

## A7: Capital
- **Anchor:** Chinn, M. D., & Ito, H. (2006). *What Matters for Financial Development? Capital Controls, Institutions, and Interactions*.
- **Concept:** The Chinn-Ito Index for financial openness.

## A8: Integrity/ESG
- **Anchor:** Olken, B. A., & Pande, R. (2012). *Corruption in Developing Countries*.
- **Concept:** Measurement techniques for corruption beyond perception.

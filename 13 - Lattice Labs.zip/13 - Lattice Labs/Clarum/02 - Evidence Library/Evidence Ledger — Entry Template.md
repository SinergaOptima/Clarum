# Evidence Ledger — Entry Template

## Meta
- **ID:** EV-[Year]-[Sequential]
- **Domain:** [[Lattice Risk Framework#Layer A — Ontology|Domain ID]]
- **Type:** (Dataset / Report / Paper / Expert Interview)
- **Tier:** (A / B / C)

## Content
### Claim
> *Concise statement of what this evidence proves.*

### Source Details
- **Title:**
- **Author/Org:**
- **Year:**
- **URL/DOI:**
- **Access Method:** (Public / Subscription / API)

### Relevance
- **Direct Support:** (How it maps to the sub-dimension)
- **Limitations:** (Bias, lag, proxy issues)

### Excerpt / Data Points
- "Quote or Key Statistic 1"
- "Quote or Key Statistic 2"

### Tags
#country/code #sector/ev #sector/semi

# Source Register

*Approved Data Sources for Clarum MVP.*

## Evidence tiers
- Indicator values may be tagged with evidence_tier: "A" or "B" in country packs (missing defaults to Tier A).
- Tier B values are explicitly flagged in generated reports and have confidence caps applied.
- Policy + definitions: 04 - Data & Ontology/Ontology/_machine/EVIDENCE_TIER_POLICY.v1.md.

## Multilateral / Global (Tier A)
- **World Bank:** WDI, WGI, LPI, Doing Business (Historical), Enterprise Surveys.
- **World Bank (proxy series):** SP.POP.SCIE.RD.P6 (Researchers in R&D per million), EN.ATM.PM25.MC.M3 (PM2.5 exposure), CC.EST (WGI Control of Corruption), VA.EST (WGI Voice and Accountability), SP.POP.TOTL (population). Transforms used in Sprint 13: $score_{0-100} = (x+2.5)/5*100$ for WGI indices; $score_{0-100} = \mathrm{clamp}((35-\mathrm{PM2.5})/30*100, 0, 100)$ for PM2.5.
- **World Bank Enterprise Surveys (proxy variables):** IC.FRM.WRKF.WK9 (labor regulations major constraint), IC.FRM.WRKF.WK10 (inadequately educated workforce major constraint).
- **World Bank WITS TradeStats:** HH market concentration index (HH-MKT-CNCNTRTN-NDX) | measures export market concentration on a 0-1 scale (higher = more concentrated) | acceptable Tier-A proxy for export concentration in MVP.
- **IMF:** World Economic Outlook, Financial Statistics.
- **OECD:** FDI Restrictiveness Index, Product Market Regulation.
- **WTO:** Tariff Profiles, Technical Barriers to Trade (TBT).
- **UNCTAD:** World Investment Report, Liner Shipping Connectivity.
- **Chinn-Ito:** KAOPEN capital account openness index (2023 dataset).
- **World Bank LPI (proxy for A5-SUP-005):** LPI Timeliness (0-5), source: https://api.worldbank.org/v2/country/{ISO}/indicator/LP.LPI.TIML.XQ?format=json | transform: $score_{0-100} = \mathrm{clamp}(raw \times 20, 0, 100)$ | year: latest available non-null | retrieved_date: date the API value is pulled. Note: if LP.LPI.TIML.XQ is unavailable, use LP.LPI.LOGS.XQ as the documented proxy and record in notes.

## Industry / Specialized (Tier B)
- **IEA:** Energy Prices and Taxes.
- **Fraser Institute:** Economic Freedom of the World.
- **US Department of State:** Investment Climate Statements (country reports).
- **Transparency International:** CPI.
- **Yale/Columbia:** EPI (Environmental Performance).
- **S&P Global:** PMI Data (Purchasing Managers Index).

## Geopolitical / Conflict (Tier A/B)
- **UCDP:** Uppsala Conflict Data Program.
- **ACLED:** Armed Conflict Location & Event Data.
- **BIS:** Bureau of Industry and Security (Entity Lists).
- **GDELT 2.1 Events API (Tier B proxy):** example template https://api.gdeltproject.org/api/v2/events/search?query={QUERY}&mode=EventList&format=json&startdatetime=YYYYMMDDhhmmss&enddatetime=YYYYMMDDhhmmss. Use event counts over a fixed window and scale per capita with SP.POP.TOTL when available.

## Sanctions and Export Controls (Tier A)
- **UN Security Council Consolidated List** | jurisdiction: global | type: sanctions list | canonical_url: https://main.un.org/securitycouncil/content/un-sc-consolidated-list | machine_access: yes | formats: xml, pdf, html | update_cadence: last updated 2025-12-07 | supports: A2
- **OFAC Sanctions List Service (SLS)** | jurisdiction: US | type: sanctions list | canonical_url: https://ofac.treasury.gov/sanctions-list-service | machine_access: yes | formats: xml, csv, pdf | update_cadence: not stated | supports: A2
- **OFAC SDN List** | jurisdiction: US | type: sanctions list | canonical_url: https://sanctionslist.ofac.treas.gov/Home/SdnList | machine_access: yes | formats: xml, csv, pdf | update_cadence: last updated 2026-02-10 | supports: A2
- **OFAC Consolidated (Non-SDN) List** | jurisdiction: US | type: sanctions list | canonical_url: https://sanctionslist.ofac.treas.gov/Home/ConsolidatedList | machine_access: yes | formats: xml, csv, pdf | update_cadence: last updated 2026-01-08 | supports: A2
- **UK Sanctions List** | jurisdiction: UK | type: sanctions list | canonical_url: https://www.gov.uk/government/publications/the-uk-sanctions-list | machine_access: yes | formats: csv, xml, pdf | update_cadence: last updated 2026-02-10 | supports: A2
- **EU Dual-Use Regulation (EU) 2021/821 (consolidated)** | jurisdiction: EU | type: export control | canonical_url: https://eur-lex.europa.eu/legal-content/EN/AUTO/?uri=CELEX:02021R0821-20251115 | machine_access: no | formats: html, xml, pdf | update_cadence: consolidated text 2025-11-15 | supports: A2
- **EU Consolidated Financial Sanctions List** | jurisdiction: EU | type: sanctions list | canonical_url: https://data.europa.eu/euodp/en/data/dataset/consolidated-list-of-persons-groups-and-entities-subject-to-eu-financial-sanctions | machine_access: yes | formats: xml, csv, pdf | update_cadence: updated 2024-10-21 | supports: A2

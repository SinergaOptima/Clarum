# Evidence Library — Index

> **Purpose:** Central repository for all "truth sources" used in Clarum.
> **Rule:** If it's not here, it can't drive a score.

## Components
- [[Evidence Tiering & Gating]] — Rules for what counts as evidence.
- [[Source Register]] — Approved datasets and institutions.
- [[Peer-Reviewed Anchors — Index]] — Academic backing for domains.
- [[Evidence Ledger — Entry Template]] — Copy this for every new finding.

## Quick Links
- [[LRF-1 — Indicator Library (v1)]] (The active implementation of these sources)

## Recent Tier-A Additions (2026-02-10)
- EV-2026-033 — UN Security Council Consolidated List (Tier A, global)
- EV-2026-034 — OFAC SDN List (Tier A, US)
- EV-2026-035 — OFAC Consolidated (Non-SDN) List (Tier A, US)
- EV-2026-036 — UK Sanctions List (Tier A, UK)
- EV-2026-037 — EU Dual-Use Regulation (EU) 2021/821 (Tier A, EU)
- EV-2026-038 — EU consolidated financial sanctions dataset (Tier A, EU)
- EV-2026-039 — OFAC Sanctions List Service (SLS) landing page (Tier A, US)

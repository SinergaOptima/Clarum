# Evidence Tiering & Gating

## Tier Definitions

### Tier A: Gold Standard
*Required for "High Confidence" scores.*
- **Nature:** Peer-reviewed academic papers, official multilateral datasets (WB, IMF, OECD), National Statistics Offices (if independent).
- **Utility:** Defines the baseline truth; sets the score anchors.
- **Verification:** Methodology is public and reproducible.

### Tier B: Silver Standard
*Acceptable for "Medium Confidence"; supplements Tier A.*
- **Nature:** Reputable industry reports (Big 4, Major Consultancies), NGO indices (Transparency Int'l), Think Tank analysis (CSIS, Peterson Institute).
- **Utility:** Fills gaps where official stats lag; provides qualitative context.
- **Verification:** Methodology is transparent but may be subjective.

### Tier C: Context Only
*Does not drive scores directly.*
- **Nature:** News articles (Reuters, Bloomberg), Op-Eds, Twitter/X threads, anonymous expert inputs.
- **Utility:** Confirms "events" (e.g., "A strike happened on date X"), checks timeline.
- **Verification:** Corroboration required.

## Confidence Gating
- **High Confidence:** ≥ 5 Tier A/B pieces (mostly A) + < 10% missing data.
- **Medium Confidence:** ≥ 3 Tier A/B pieces + < 30% missing data.
- **Low Confidence:** Reliance on proxies or Tier C heavy.

# LRF-1 — Indicator Ops Registry (v1)

> **Status:** v1.0 (Operational)  
> **Owner:** Lattice Labs — Methodology  
> **Applies to:** Clarum Scoring Ops (LRF-1.1)  
> **Last Updated:** 2026-02-09

---

## 1) Overview

This registry operationalizes the LRF-1 Indicator Library by mapping each **IND-*** to a canonical source, retrieval method, and transformation recipe. It is the bridge from **[[LRF-1 — Indicator Library (v1)]] → scoring engine → dossiers**, ensuring reproducibility and auditability. Dossiers should cite Country Packs (not raw sources) to keep evidence centralized.

---

## 2) Global Rules

### 2.1 Completeness & Confidence Mechanics
- **Completeness** is computed per domain as: `(valid indicators / required indicators) * 100`.
- **Confidence gating** follows [[LRF-1 — Rubric Anchors & Thresholds (v1)]] and [[Evidence Tiering & Gating]].
- **Hard cap:** if completeness <50% in any domain, confidence must be **Low**.

### 2.2 Fatal Missingness Policy (Manual Override Required)
Missingness for the following indicators is **fatal** and requires manual override with explicit rationale:
- **IND-A2-GEO-002** (Sanctions Alignment Risk)
- **IND-A2-GEO-005** (High-Tech Export Restrictions)

### 2.3 Normalization Policy
- **Default comparator set:** GLOBAL-GDP-10B+.
- **Primary method:** Percentile Rank mapping per rubric (invert where "higher is better").
- **Inversion rule:** If indicator directionality is "higher is better" (e.g., Regulatory Quality), invert the percentile before mapping.

---

## 3) Master Indicator Table (LRF-1 v1)

| Indicator ID | Domain/Sub-dim | Indicator name | Canonical source (institution) | Canonical URL(s) | Retrieval method | Update cadence | Transform recipe | Required-by (Critical profiles) | Missingness handling | Notes |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| IND-A1-REG-001 | A1.1 | Regulatory Quality Estimate | World Bank | TODO(URL) | API | Annual | Percentile Rank (invert) | WP-BATT-CELL-GREEN-1.1, WP-SEMI-ADV-EXPORT-1.1 | Fallback to regional avg + confidence penalty | WGI indicator |
| IND-A1-REG-002 | A1.2 | Rule of Law Estimate | World Bank | TODO(URL) | API | Annual | Percentile Rank (invert) | WP-BATT-CELL-GREEN-1.1, WP-SEMI-ADV-EXPORT-1.1 | Fallback to regional avg + confidence penalty | WGI indicator |
| IND-A1-REG-003 | A1.4 | Contract Enforcement Efficiency | World Bank | TODO(URL) | Table/Portal | Annual | Inverse normalized (lower is better) | WP-BATT-CELL-GREEN-1.1, WP-SEMI-ADV-EXPORT-1.1 | Fallback to regional avg + confidence penalty | Doing Business legacy or WJP proxy |
| IND-A1-REG-004 | A1.3 | Permitting Complexity Index | World Bank / OECD | TODO(URL) | Table/Portal | Annual | Inverse normalized | WP-BATT-CELL-GREEN-1.1, WP-SEMI-ADV-EXPORT-1.1 | Fallback to regional avg + confidence penalty | Construction permits proxy |
| IND-A1-REG-005 | A1.5 | Regulatory Burden Perception | WEF | TODO(URL) | Table/Portal | Annual | Z-score | WP-BATT-CELL-GREEN-1.1, WP-SEMI-ADV-EXPORT-1.1 | Fallback to regional avg + confidence penalty | GCR executive opinion |
| IND-A1-REG-006 | A1.6 | Policy Instability Concern | Fund for Peace / PRS Group | TODO(URL) | Table/Portal | Annual | Bucket thresholds | WP-BATT-CELL-GREEN-1.1, WP-SEMI-ADV-EXPORT-1.1 | Fallback to regional avg + confidence penalty | FSI/PRS proxy |
| IND-A2-GEO-001 | A2.1 | Trade Openness Index | World Bank / WTO | TODO(URL) | API | Annual | Bucket thresholds | WP-EV-OEM-EXPORT-1.1, WP-SEMI-OSAT-EXPORT-1.1, WP-SEMI-ADV-EXPORT-1.1 | Fallback to regional avg + confidence penalty | Trade % GDP or tariff proxy |
| IND-A2-GEO-002 | A2.2 | Sanctions Alignment Risk | United Nations | TODO(URL) | Table/Portal | Event-driven | Linear scaling | WP-EV-OEM-EXPORT-1.1, WP-SEMI-OSAT-EXPORT-1.1, WP-SEMI-ADV-EXPORT-1.1 | **Fatal missingness** | UN voting alignment; Lattice proprietary layer |
| IND-A2-GEO-003 | A2.4 | Geopolitical Alignment (Bloc) | Treaty databases | TODO(URL) | Table/Portal | Event-driven | Risk weights | WP-EV-OEM-EXPORT-1.1, WP-SEMI-OSAT-EXPORT-1.1, WP-SEMI-ADV-EXPORT-1.1 | Fallback to manual classification | NATO/CPTPP/RCEP flags |
| IND-A2-GEO-004 | A2.5 | Conflict Intensity Index | ACLED / UCDP | TODO(URL) | API | Annual | Thresholds | WP-EV-OEM-EXPORT-1.1, WP-SEMI-OSAT-EXPORT-1.1, WP-SEMI-ADV-EXPORT-1.1 | Fallback to regional avg + confidence penalty | Conflict presence proxy |
| IND-A2-GEO-005 | A2.3 | High-Tech Export Restrictions | US BIS / Wassenaar | TODO(URL) | Table/Portal | Event-driven | Boolean flag | WP-EV-OEM-EXPORT-1.1, WP-SEMI-OSAT-EXPORT-1.1, WP-SEMI-ADV-EXPORT-1.1 | **Fatal missingness** | Export controls mapping |
| IND-A3-POL-001 | A3.2 | FDI Restrictiveness Index | OECD | TODO(URL) | API | Annual | Direct mapping | WP-EV-OEM-DOM-1.1 | Qualitative override allowed | Statutory restrictions |
| IND-A3-POL-002 | A3.4 | Gov't Support for Tech | WEF / ITU | TODO(URL) | Table/Portal | Annual | Z-score | WP-EV-OEM-DOM-1.1 | Qualitative override allowed | Policy support proxy |
| IND-A3-POL-003 | A3.3 | Local Content Requirements | WTO / USTR | TODO(URL) | Table/Portal | Annual | Risk weights | WP-EV-OEM-DOM-1.1 | Qualitative override allowed | LCR presence/severity |
| IND-A3-POL-004 | A3.6 | SOE Prevalence | OECD / IMF | TODO(URL) | Table/Portal | Annual | Bucket thresholds | WP-EV-OEM-DOM-1.1 | Qualitative override allowed | SOE distortion proxy |
| IND-A3-POL-005 | A3.1 | Strategic Sector Designation | National policy documents | TODO(URL) | Manual | Ad-hoc | Bonus/penalty | WP-EV-OEM-DOM-1.1 | Qualitative override allowed | National plan includes sector |
| IND-A4-INF-001 | A4.3 | LPI - Logistics Performance Index | World Bank | TODO(URL) | API | Biennial | Inverted scale | WP-EV-OEM-EXPORT-1.1, WP-BATT-CELL-GREEN-1.1, WP-BATT-PACK-MIXED-1.1, WP-BATT-MAT-EXPORT-1.1, WP-SEMI-OSAT-EXPORT-1.1 | Fallback to regional avg + confidence penalty | LPI score |
| IND-A4-INF-002 | A4.1 | Quality of Electricity Supply | WEF | TODO(URL) | Table/Portal | Annual | Z-score | WP-EV-OEM-EXPORT-1.1, WP-BATT-CELL-GREEN-1.1, WP-BATT-PACK-MIXED-1.1, WP-BATT-MAT-EXPORT-1.1, WP-SEMI-OSAT-EXPORT-1.1 | Fallback to regional avg + confidence penalty | Reliability proxy |
| IND-A4-INF-003 | A4.2 | Industrial Electricity Price Volatility | IEA / National Grid | TODO(URL) | Table/Portal | Annual | Thresholds | WP-EV-OEM-EXPORT-1.1, WP-BATT-CELL-GREEN-1.1, WP-BATT-PACK-MIXED-1.1, WP-BATT-MAT-EXPORT-1.1, WP-SEMI-OSAT-EXPORT-1.1 | Fallback to regional avg + confidence penalty | 3y variance |
| IND-A4-INF-004 | A4.3 | Port Efficiency / Dwell Time | IMF PortWatch / UNCTAD | TODO(URL) | API | Monthly | Inverse normalized | WP-EV-OEM-EXPORT-1.1, WP-BATT-CELL-GREEN-1.1, WP-BATT-PACK-MIXED-1.1, WP-BATT-MAT-EXPORT-1.1, WP-SEMI-OSAT-EXPORT-1.1 | Fallback to regional avg + confidence penalty | Dwell time proxy |
| IND-A4-INF-005 | A4.6 | Industrial Internet Quality | Ookla / ITU | TODO(URL) | Table/Portal | Annual | Thresholds | WP-EV-OEM-EXPORT-1.1, WP-BATT-CELL-GREEN-1.1, WP-BATT-PACK-MIXED-1.1, WP-BATT-MAT-EXPORT-1.1, WP-SEMI-OSAT-EXPORT-1.1 | Fallback to regional avg + confidence penalty | Bandwidth/latency proxy |
| IND-A4-INF-006 | A4.5 | Industrial Land Availability | World Bank | TODO(URL) | API | Annual | Inverse normalized | WP-EV-OEM-EXPORT-1.1, WP-BATT-CELL-GREEN-1.1, WP-BATT-PACK-MIXED-1.1, WP-BATT-MAT-EXPORT-1.1, WP-SEMI-OSAT-EXPORT-1.1 | Fallback to regional avg + confidence penalty | Property registration proxy |
| IND-A5-SUP-001 | A5.1 | Export Concentration Index | UNCTAD | TODO(URL) | API | Annual | Direct mapping | WP-SEMI-COMP-EXPORT-1.1 | Fallback to regional avg + confidence penalty | HHI proxy |
| IND-A5-SUP-002 | A5.3 | Manufacturing Value Added | World Bank | TODO(URL) | API | Annual | Percentile rank | WP-SEMI-COMP-EXPORT-1.1 | Fallback to regional avg + confidence penalty | MVA % GDP |
| IND-A5-SUP-003 | A5.2 | Critical Raw Material Production | USGS / IEA | TODO(URL) | Table/Portal | Annual | Inverted risk (higher share = lower risk) | WP-SEMI-COMP-EXPORT-1.1 | Fallback to regional avg + confidence penalty | Mineral share proxy |
| IND-A5-SUP-004 | A5.4 | Quality Certification Density | ISO | TODO(URL) | Table/Portal | Annual | Percentile rank | WP-SEMI-COMP-EXPORT-1.1 | Fallback to regional avg + confidence penalty | ISO 9001 density |
| IND-A5-SUP-005 | A5.6 | Supplier Delivery Time | S&P Global | TODO(URL) | Table/Portal | Monthly | Deviation from 50 | WP-SEMI-COMP-EXPORT-1.1 | Fallback to regional avg + confidence penalty | PMI sub-index |
| IND-A6-LAB-001 | A6.1 | Human Capital Index | World Bank | TODO(URL) | API | Annual | Percentile rank | WP-EV-COMP-EXPORT-1.1, WP-BATT-PACK-MIXED-1.1 | Fallback to regional avg + confidence penalty | HCI proxy |
| IND-A6-LAB-002 | A6.2 | STEM Graduates | UNESCO / OECD | TODO(URL) | Table/Portal | Annual | Bucket thresholds | WP-EV-COMP-EXPORT-1.1, WP-BATT-PACK-MIXED-1.1 | Fallback to regional avg + confidence penalty | STEM share |
| IND-A6-LAB-003 | A6.3 | Labor Freedom / Flexibility | Fraser Institute / Heritage | TODO(URL) | Table/Portal | Annual | Inverted (if rigidity is risk) | WP-EV-COMP-EXPORT-1.1, WP-BATT-PACK-MIXED-1.1 | Fallback to regional avg + confidence penalty | Labor regs proxy |
| IND-A6-LAB-004 | A6.3 | Strike / Labor Unrest Risk | Verisk / ACLED | TODO(URL) | Table/Portal | Quarterly | Thresholds | WP-EV-COMP-EXPORT-1.1, WP-BATT-PACK-MIXED-1.1 | Fallback to regional avg + confidence penalty | Unrest proxy |
| IND-A6-LAB-005 | A6.1 | Ease of Finding Skilled Employees | WEF / ManpowerGroup | TODO(URL) | Table/Portal | Annual | Z-score | WP-EV-COMP-EXPORT-1.1, WP-BATT-PACK-MIXED-1.1 | Fallback to regional avg + confidence penalty | Executive sentiment |
| IND-A7-CAP-001 | A7.1 | Exchange Rate Volatility | IMF | TODO(URL) | API | Monthly | Bucket thresholds | None (no domain-critical profiles) | Fallback to regional avg + confidence penalty | IMF IFS |
| IND-A7-CAP-002 | A7.2 | Chinn-Ito Index | Chinn-Ito | TODO(URL) | Table/Portal | Annual | Percentile rank | None (no domain-critical profiles) | Fallback to regional avg + confidence penalty | Capital controls proxy |
| IND-A7-CAP-003 | A7.3 | Inflation Rate (CPI) | IMF / Central Bank | TODO(URL) | API | Monthly | Risk curve | None (no domain-critical profiles) | Fallback to regional avg + confidence penalty | CPI % |
| IND-A7-CAP-004 | A7.4 | Sovereign Credit Rating | S&P / Moody's / Fitch | TODO(URL) | Manual | Ad-hoc | Linear mapping to 1-5 | None (no domain-critical profiles) | Fallback to regional avg + confidence penalty | Rating scale |
| IND-A7-CAP-005 | A7.5 | Central Bank Transparency | Academic / BIS | TODO(URL) | Table/Portal | Annual | Thresholds | None (no domain-critical profiles) | Fallback to regional avg + confidence penalty | Dincer/Eichengreen |
| IND-A8-ESG-001 | A8.1 | Corruption Perceptions Index | Transparency International | TODO(URL) | Table/Portal | Annual | Inverted scale | WP-BATT-MAT-EXPORT-1.1, WP-SEMI-COMP-EXPORT-1.1 | Fallback to regional avg + confidence penalty | CPI score |
| IND-A8-ESG-002 | A8.2 | Environmental Performance Index | Yale / Columbia | TODO(URL) | Table/Portal | Biennial | Percentile rank | WP-BATT-MAT-EXPORT-1.1, WP-SEMI-COMP-EXPORT-1.1 | Fallback to regional avg + confidence penalty | EPI score |
| IND-A8-ESG-003 | A8.3 | Labor Rights Index | Penn State / NGO | TODO(URL) | Table/Portal | Annual | Inverted scale | WP-BATT-MAT-EXPORT-1.1, WP-SEMI-COMP-EXPORT-1.1 | Fallback to regional avg + confidence penalty | Labor rights proxy |
| IND-A8-ESG-004 | A8.1 | Control of Corruption | World Bank | TODO(URL) | API | Annual | Percentile rank | WP-BATT-MAT-EXPORT-1.1, WP-SEMI-COMP-EXPORT-1.1 | Fallback to regional avg + confidence penalty | WGI indicator |
| IND-A8-ESG-005 | A8.5 | Social License / Protest Risk | Verisk / ACLED | TODO(URL) | Table/Portal | Annual | Thresholds | WP-BATT-MAT-EXPORT-1.1, WP-SEMI-COMP-EXPORT-1.1 | Fallback to regional avg + confidence penalty | Protest risk proxy |

---

## 4) Rubric Crosswalk (A1–A8)

- **A1 Governance & Institutions**
  - A1.1 Regulatory Quality: IND-A1-REG-001
  - A1.2 Rule of Law: IND-A1-REG-002
  - A1.3 Permitting: IND-A1-REG-004
  - A1.4 Contracts: IND-A1-REG-003
  - A1.5 Burden: IND-A1-REG-005
  - A1.6 Instability: IND-A1-REG-006

- **A2 Trade & Market Access**
  - A2.1 Tariff/Trade Openness: IND-A2-GEO-001
  - A2.2 Sanctions Alignment: IND-A2-GEO-002
  - A2.3 Export Controls: IND-A2-GEO-005
  - A2.4 Alliance Alignment: IND-A2-GEO-003
  - A2.5 Conflict Intensity: IND-A2-GEO-004

- **A3 Regulatory & Compliance**
  - A3.1 Strategic Sector: IND-A3-POL-005
  - A3.2 FDI Restrictiveness: IND-A3-POL-001
  - A3.3 Local Content: IND-A3-POL-003
  - A3.4 Government Support: IND-A3-POL-002
  - A3.6 SOE Prevalence: IND-A3-POL-004

- **A4 Infrastructure & Logistics**
  - A4.1 Grid Reliability: IND-A4-INF-002
  - A4.2 Energy Price Volatility: IND-A4-INF-003
  - A4.3 Logistics/Ports: IND-A4-INF-001, IND-A4-INF-004
  - A4.5 Land Availability: IND-A4-INF-006
  - A4.6 Digital Quality: IND-A4-INF-005

- **A5 Supply Chain & Ecosystem**
  - A5.1 Concentration: IND-A5-SUP-001
  - A5.2 Raw Materials: IND-A5-SUP-003
  - A5.3 Manufacturing Base: IND-A5-SUP-002
  - A5.4 Quality Density: IND-A5-SUP-004
  - A5.6 Supplier Delivery: IND-A5-SUP-005

- **A6 Talent & Labor**
  - A6.1 Human Capital/Skilled: IND-A6-LAB-001, IND-A6-LAB-005
  - A6.2 STEM Pipeline: IND-A6-LAB-002
  - A6.3 Labor Flexibility/Unrest: IND-A6-LAB-003, IND-A6-LAB-004

- **A7 Capital & Macro**
  - A7.1 FX Volatility: IND-A7-CAP-001
  - A7.2 Capital Controls: IND-A7-CAP-002
  - A7.3 Inflation: IND-A7-CAP-003
  - A7.4 Credit Rating: IND-A7-CAP-004
  - A7.5 Central Bank Transparency: IND-A7-CAP-005

- **A8 Integrity, ESG & Security**
  - A8.1 Corruption: IND-A8-ESG-001, IND-A8-ESG-004
  - A8.2 Environmental Performance: IND-A8-ESG-002
  - A8.3 Labor Rights: IND-A8-ESG-003
  - A8.5 Social License: IND-A8-ESG-005

---

## 5) Flag Linkage (Rubric → Indicators)

- **FLG-A1-001 (Rule of Law < 10th percentile)**
  - IND-A1-REG-002 (Rule of Law Estimate)
  - Evidence required: Tier A (World Bank WGI)

- **FLG-A2-001 (Sanctions on sector)**
  - IND-A2-GEO-002 (Sanctions Alignment Risk)
  - Evidence required: Tier A/B (UN, US/EU sanctions lists)

- **FLG-A2-002 (Active armed conflict in industrial zones)**
  - IND-A2-GEO-004 (Conflict Intensity Index)
  - Evidence required: Tier A (ACLED/UCDP)

- **FLG-A2-003 (Entity List designation, major supplier)**
  - IND-A2-GEO-005 (High-Tech Export Restrictions)
  - Evidence required: Tier A (US BIS, Wassenaar)

- **FLG-A3-001 (Local content requirement >60%)**
  - IND-A3-POL-003 (Local Content Requirements)
  - Evidence required: Tier A/B (WTO/USTR)

- **FLG-A4-001 (Grid outages >10%)**
  - IND-A4-INF-002 (Quality of Electricity Supply)
  - Evidence required: Tier A/B (WEF; national grid SAIDI/SAIFI where available)

- **FLG-A4-002 (Water stress extremely high)**
  - No v1 indicator; manual override using WRI Aqueduct (planned in v1.1 expansions)
  - Evidence required: Tier A (WRI Aqueduct)

- **FLG-A5-001 (Single-source supplier >80%)**
  - IND-A5-SUP-001 (Export Concentration Index)
  - Evidence required: Tier A (UNCTAD)

- **FLG-A7-001 (Capital controls block repatriation)**
  - IND-A7-CAP-002 (Chinn-Ito Index)
  - Evidence required: Tier A (Chinn-Ito)

- **FLG-A7-002 (Hyperinflation >50%)**
  - IND-A7-CAP-003 (Inflation Rate)
  - Evidence required: Tier A (IMF / Central Bank)

- **FLG-A8-001 (Systemic child/forced labor)**
  - IND-A8-ESG-003 (Labor Rights Index)
  - Evidence required: Tier A/B (ILO or rights index)

- **FLG-A8-002 (Environmental moratorium)**
  - No v1 indicator; manual override using government moratorium notices
  - Evidence required: Tier A/B (government gazette, regulator notices)

---

## 6) Versioning & Reproducibility

- **Append-only:** Do not rewrite v1 entries. Add new indicators in a new version file (e.g., v1.1) and update references.
- **Reproducibility:** A dossier must reference the exact registry version used for scoring.
- **Change control:** All revisions must include a changelog and explicit owner approval.

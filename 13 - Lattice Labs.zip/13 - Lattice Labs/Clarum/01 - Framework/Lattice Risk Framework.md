# (LRF-1)
## Decision-grade Market-Entry Risk Model for High-Tech Industries  
**Clarum, by Lattice Labs**

> **Status:** v1.0 (initial)  
> **Owner:** Lattice Labs — Methodology & Research  
> **Applies to:** Market entry / expansion decisions in **EVs, batteries, semiconductors**, and adjacent industrial tech  
> **Primary output:** Structured risk scores + explainable rationale + evidence ledger + confidence + exportable dossiers  
> **Core promise:** *Clarum does not predict outcomes; it maps exposure with discipline and auditability.*

---

## 0) Why LRF-1 exists
LRF-1 is the methodology moat behind Clarum.

Most “AI risk tools” fail because they are:
- unstructured (chatty summaries)
- un-auditable (no claim → evidence chain)
- un-calibrated (arbitrary weights)
- untrustworthy under scrutiny (no uncertainty treatment)

 linking: LRF-1 provides:
- a stable **risk ontology** (what we measure)
- a disciplined **indicator library** (how we measure)
- a defensible **scoring + weighting method** (how we combine)
- a built-in **evidence ledger** (why we believe it)
- explicit **uncertainty/confidence** (how sure we are)

**Goal:** LRF-1 should be valuable as a standalone framework. People should trust the method *before* they trust the UI.

---

## 1) Core definitions (strict)
### 1.1 Risk (for market entry)
In LRF-1, **risk = exposure to adverse conditions that can impair value creation**, characterized by:

- **Hazards**: events/conditions (policy shocks, trade restrictions, grid failures)
- **Exposure**: how dependent the project is on the hazard pathways
- **Vulnerability**: sensitivity of operations to disruption
- **Resilience**: capacity to absorb, adapt, substitute, and recover

**Important:** LRF-1 scores **exposure and structural vulnerability** more than “probability of crisis.”  
We do not claim prophecy. We claim disciplined mapping.

### 1.2 Units of analysis
LRF-1 always scores a **Case** defined as:

- **Country/Region** (and optionally state/province)
- **Sector** (EV / battery / semis / adjacent)
- **Value-chain role** (e.g., OEM assembly, pack integration, cathode processing, OSAT/ATP)
- **Operating model** (JV/wholly owned, export-oriented vs domestic, greenfield vs acquisition)

A score without these inputs is not “decision grade.”

---

## 2) Framework principles (non-negotiable)
1. **Explainability over mystique**: every score must have a rationale and citations.
2. **Reproducibility**: same inputs + same model version ⇒ same outputs.
3. **Corrigibility**: model can be updated without rewriting history; old outputs remain interpretable.
4. **Evidence discipline**: no category scores without a minimum evidence floor.
5. **Uncertainty honesty**: confidence is first-class; missing data is not hidden.
6. **Sector specificity**: weights and indicator relevance change by sector + role.
7. **Anti-narrative bias**: we separate “story” from “support”; contradictions are recorded, not smoothed away.

---

## 3) LRF-1 architecture (4 layers)
### Layer A — Ontology
Defines domains and sub-dimensions.

### Layer B — Indicators
Defines measurable proxies, sources, transformations, and caveats.

### Layer C — Scoring & weighting
Defines rubrics, aggregation method, and sensitivity controls.

### Layer D — Evidence ledger & uncertainty
Defines claim formats, evidence grading, confidence, and audit trail.

**Moat claim:** UI can be copied. LRF-1’s 4-layer discipline is expensive to replicate.

---

## 4) Layer A — Risk ontology (domains & sub-dimensions)
LRF-1 uses **8 top-level domains** (stable).  
Each domain decomposes into **sub-dimensions** (evolvable).

> **Scoring scale:** 1.0 (low) → 5.0 (extreme)  
> **Displayed:** one decimal  
> **Each domain:** weighted aggregation of its sub-dimensions (default weights below)

---

### A1) Regulatory Stability & Rule-of-Law
**What it measures:** predictability and enforceability of the operating environment.

**Sub-dimensions**
- A1.1 Policy volatility (relevant to sector)
- A1.2 Enforcement consistency (regional/agency variance)
- A1.3 Permitting friction & timeline uncertainty
- A1.4 Contract enforceability & dispute resolution reliability
- A1.5 Administrative burden (licensing, compliance overhead)
- A1.6 Regulatory capture risk (dominant incumbents shaping rules)

**Sector switches**
- **Battery/chemicals:** environmental permitting and waste rules ↑ relevance
- **Semis:** IP enforcement and export compliance regimes ↑ relevance
- **EV OEM:** homologation/standards regime and import rules ↑ relevance

---

### A2) Geopolitical, Sanctions, & Trade Exposure
**What it measures:** vulnerability to cross-border policy conflict and restriction regimes.

**Sub-dimensions**
- A2.1 Tariff/trade policy volatility exposure
- A2.2 Sanctions spillover exposure (direct and indirect)
- A2.3 Export controls / tech restrictions exposure
- A2.4 Alliance alignment sensitivity (market access vs bloc tension)
- A2.5 Cross-border escalation pathways (routes through chokepoints)
- A2.6 Legal extraterritorial risk (compliance regime complexity)

**Sector switches**
- **Semis:** export controls ↑↑ relevance
- **EV/battery:** material sourcing sanctions pathways ↑ relevance

---

### A3) Industrial Policy Alignment & Market Access
**What it measures:** whether the state’s industrial trajectory supports or obstructs your entry.

**Sub-dimensions**
- A3.1 Sector strategic priority stability (not just “exists”)
- A3.2 FDI screening/approval friction (including informal barriers)
- A3.3 Localization rules (content requirements, JV pressures)
- A3.4 Subsidy dependence risk (cliff effects, eligibility shifts)
- A3.5 Standards regime compatibility (global vs local divergence)
- A3.6 Competitive neutrality (SOEs/favored champions)

---

### A4) Infrastructure Readiness (Energy • Logistics • Digital)
**What it measures:** operational bottleneck likelihood at target scale.

**Sub-dimensions**
- A4.1 Grid reliability and capacity adequacy
- A4.2 Energy cost stability and policy exposure
- A4.3 Logistics throughput & corridor reliability (port/rail/road)
- A4.4 Customs efficiency and border friction
- A4.5 Industrial land / utilities readiness
- A4.6 Digital infrastructure (only where critical)

**Sector switches**
- **Battery:** grid + water + waste infrastructure ↑ relevance
- **Semis:** power quality and uptime ↑↑ relevance

---

### A5) Supply Chain Structure, Fragility, & Resilience
**What it measures:** how brittle the value chain is and how quickly it can adapt.

**Sub-dimensions**
- A5.1 Concentration risk (single-source, single-country)
- A5.2 Chokepoint exposure (materials processing, ports, equipment)
- A5.3 Substitutability (qualified alternatives availability)
- A5.4 Supplier maturity & quality systems readiness
- A5.5 Inventory/buffering feasibility (cost vs necessity)
- A5.6 Reconfiguration speed (qualification and switching time)

**Required framing:** vulnerability + resilience (not “list of disruptions”).

---

### A6) Labor, Talent, & Operational Capacity
**What it measures:** whether the workforce and operational institutions can support ramp.

**Sub-dimensions**
- A6.1 Skilled labor availability for role
- A6.2 Engineering and QA pipeline maturity
- A6.3 Labor relations volatility (strike/turnover risk)
- A6.4 Training/ramp timeline realism
- A6.5 Management talent and local ecosystem (suppliers + services)
- A6.6 Safety regime maturity (industry-specific)

---

### A7) Capital, Currency, & Repatriation Risk
**What it measures:** financial friction and downside risk from macro constraints.

**Sub-dimensions**
- A7.1 FX volatility exposure relative to cost/revenue structure
- A7.2 Capital controls and repatriation friction
- A7.3 Inflation and interest rate environment
- A7.4 Credit availability and counterparty stability
- A7.5 Fiscal/monetary policy credibility (as operational risk)

---

### A8) Integrity, ESG, & Compliance Exposure
**What it measures:** compliance friction and legal exposure from governance and ESG constraints.

**Sub-dimensions**
- A8.1 Corruption/integrity risk (as operational/legal cost)
- A8.2 Environmental permitting volatility and enforcement
- A8.3 Human rights / labor compliance exposure in chain
- A8.4 Reporting burden and auditability requirements
- A8.5 Community opposition / legitimacy risk (project acceptance)
- A8.6 Litigation/regulatory action climate (sector specific)

---

## 5) Layer B — Indicator design (how we measure)
### 5.1 Indicator types (LRF-1 supports)
- **Primary quantitative**: official stats, registries, macro/sector data  
- **Composite indices**: governance/logistics indices (*must* store uncertainty/caveats)  
- **Event counts**: strikes, expropriation events, regulatory reversals (with definitions)  
- **Policy texts → coded variables**: industrial policy and FDI rules mapped to structured tags  
- **Network measures** (supply chain): concentration indices, dependency graphs  
- **Expert-elicited inputs**: only when structured (AHP/paired comparisons), versioned, and auditable

### 5.2 Indicator rules (discipline)
- Every indicator must have:
  - definition + unit
  - source + update cadence
  - transformation (normalization/percentiles)
  - known limitations (bias, lag, missingness)
  - mapping rule to rubric anchors (see Section 6)

### 5.3 Missing data handling (no silent gaps)
Missingness is scored and surfaced:
- **Data completeness** per domain (0–100%)
- **Confidence penalty** for missing critical indicators
- Clear notation: *“Score relies on proxies; confidence reduced.”*

### 5.4 “Relevance switches”
Not all indicators apply to all cases. LRF-1 uses:
- Sector relevance flags (EV/battery/semis/adjacent)
- Role relevance flags (upstream processing vs assembly vs services)
- Operating model flags (JV vs wholly owned; export vs domestic)

---

## 6) Layer C — Scoring method (rubrics > vibes)
### 6.1 Score scale (continuous, anchored)
Scores are **continuous 1.0–5.0**, but anchored to **rubric bands**:

- **1.0–1.9 Low:** constraints are minor and predictable; mitigation is routine
- **2.0–2.9 Moderate:** constraints are real; mitigation requires planning + buffers
- **3.0–3.9 High:** constraints likely to materially disrupt timelines/costs
- **4.0–5.0 Extreme:** constraints threaten viability or require major redesign

### 6.2 Rubric anchoring (how indicators become scores)
For each sub-dimension:
1. Select applicable indicators (by relevance switches)
2. Normalize indicators against comparator set (e.g., peer countries, region, income band)
3. Map to rubric anchors using:
   - percentile thresholds, or
   - expert-coded thresholds (documented)
4. Produce a sub-dimension score and confidence

### 6.3 Aggregation (sub-dimensions → domain)
Domain score = weighted average of sub-dimension scores  
with:
- minimum evidence floor (see Section 8)
- confidence propagation (Section 9)

### 6.4 Composite index (domains → overall)
Overall score = weighted average of domain scores (default weights below), with:
- sector/role weight profiles (versioned)
- sensitivity reporting (top 3 drivers)

---

## 7) Weighting discipline (MCDA backbone)
LRF-1 uses a **multi-criteria decision analysis** approach:
- Default weights are **published, justified, and versioned**
- Weight updates require a change log
- Optional expert calibration uses **pairwise comparisons** (AHP-style discipline)

### 7.1 Default domain weights (v1 baseline)
> These are defaults; sector/role profiles override them.

- A1 Regulatory & Rule-of-Law: **0.15**
- A2 Geopolitical/Trade: **0.15**
- A3 Industrial Policy/Access: **0.15**
- A4 Infrastructure: **0.15**
- A5 Supply Chain Resilience: **0.15**
- A6 Labor/Talent: **0.10**
- A7 Capital/Currency: **0.10**
- A8 Integrity/ESG/Compliance: **0.05**

### 7.2 Sector/role profiles (required for decision grade)
LRF-1 maintains default profiles:
- EV OEM assembly (export-oriented)
- Battery cell manufacturing
- Battery materials/processing
- Semiconductor OSAT/ATP
- Semiconductor equipment suppliers (if applicable later)

Each profile defines:
- domain weights
- indicator relevance switches
- minimum evidence floors by domain

---

## 8) Layer D — Evidence ledger (the trust engine)
### 8.1 Claim-Evidence rule (mandatory)
No score is valid unless it is backed by a **claim-evidence set**.

Each sub-dimension must output:
- **Score** (1.0–5.0)
- **Rationale** (2–4 sentences)
- **Evidence bullets** (3–7)
- **Citations** per bullet (peer-reviewed and/or authoritative)
- **Confidence** (Low/Medium/High) + reason
- **Flags** (structured tags)

### 8.2 Evidence grading (two-axis)
**Tier (quality)**
- **Tier A:** peer-reviewed studies, primary datasets, official methodologies
- **Tier B:** high-quality institutional reports (OECD, central banks, regulators)
- **Tier C:** reputable news / analysis (only to support factual timelines or context)

**Fit (relevance)**
- **Direct:** addresses the construct in the case context
- **Indirect:** supports construct generally; partial transfer
- **Contextual:** background only (should not drive score)

### 8.3 Contradictions are recorded
If evidence conflicts:
- store both
- note disagreement
- reflect uncertainty in confidence
- do not “average away” contradictions

---

## 9) Confidence & uncertainty (first-class)
LRF-1 treats confidence as a structured variable, not vibes.

### 9.1 Confidence drivers
- **Data completeness** (coverage of required indicators)
- **Evidence tier** (A/B/C balance)
- **Recency** (timeliness vs lag)
- **Agreement** (evidence consistency)
- **Model fit** (how directly indicators map to construct)

### 9.2 Confidence output
- **High:** strong Tier A/B base, current, consistent, complete
- **Medium:** adequate base but gaps or mixed evidence
- **Low:** proxy-heavy, stale, contradictory, or sparse evidence

### 9.3 Sensitivity reporting (required)
Each dossier must show:
- top 3 domains driving the composite score
- how the score changes under:
  - conservative profile vs aggressive profile (if applicable)
  - alternative weight set (sector profile)

This prevents “false precision.”

---

## 10) Standard Clarum dossier output (LRF-1 compliant)
A Clarum dossier must include:

1. **Executive summary** (decision framing + top risks)
2. **Overall score** + confidence + model version
3. **Domain breakdown** (8 domains) with:
   - domain score
   - rationale
   - key evidence bullets + citations
   - flags
4. **Key risk flags** (structured list)
5. **Decision checkpoints** (what to verify before committing)
6. **Mitigation levers** (buffers, alternatives, structure changes)
7. **Assumptions** (explicit)
8. **Evidence appendix** (ledger export)

**Every export must include:** `LRF-1 version + weight profile ID + timestamp`.

---

## 11) Validation & calibration plan (how LRF becomes famous)
To make LRF-1 a “known good framework,” we must validate it.

### 11.1 Inter-rater reliability
- Two independent scorers evaluate the same case
- Measure agreement at:
  - domain level
  - key flags level
  - final decision recommendation (if present)

### 11.2 Backtesting (exposure accuracy, not prediction)
- Apply LRF-1 to historical expansions
- Check whether high domain scores correlate with:
  - permitting delays
  - cost overruns
  - trade disruptions
  - compliance incidents
  - supply failures

### 11.3 Sensitivity & robustness
- Run weight perturbations
- Ensure no single indicator dominates without justification
- Document brittleness cases and adjust rubrics

### 11.4 Publication strategy (methodology credibility)
- Publish:
  - an LRF-1 methodology page
  - a validation note (case study pack)
  - a changelog across LRF versions

---

## 12) Governance & versioning (methodology operations)
LRF-1 is versioned like software.

### 12.1 Version rules
- **LRF-1.x**: same ontology; indicator/rubric improvements
- **LRF-2.0**: ontology changes (breaking)
- Dossiers always store the version used.

### 12.2 Change log requirements
Any change to:
- sub-dimensions
- indicator mapping
- weights
- thresholds
requires:
- reason
- impact assessment
- backward compatibility notes

---

## 13) LRF-1 “Academic Anchor Library” (starter blueprint)
> **Note:** This section defines *what kinds* of peer-reviewed anchors must exist per domain.  
> The actual citation list should be maintained in a separate note: **LRF-1 — Evidence Library (A/B)**.

For each domain (A1–A8), Lattice Labs should maintain:
- **2–5 peer-reviewed anchors** defining the construct + empirical relevance
- **1–3 authoritative methodologies/datasets** used as indicators
- **1–2 limitations papers** (measurement error, bias, missingness)

**Minimum viability rule:** A dossier cannot claim “High confidence” in a domain without at least one Tier A anchor and one Tier B dataset/methodology reference supporting the mapping.

---

## 14) Appendix — Evidence Ledger Entry Template (copy/paste)
Use this for each sub-dimension:

### [A#.#] Sub-dimension name
- **Score:** X.X / 5  
- **Confidence:** Low / Medium / High  
- **Rationale (2–4 sentences):**  
  - …
- **Evidence bullets (3–7):**
  - Claim: …  
    - Source: (Tier A/B/C, Fit Direct/Indirect/Context)  
    - Notes: limitations, recency, caveats  
  - Claim: …  
    - Source: …
- **Flags:** `#tag #tag #tag`  
- **Assumptions:**  
  - …
- **Counter-evidence / disagreement (if any):**
  - …

---

## 15) Next Obsidian notes to create (recommended)
To operationalize LRF-1 immediately:

1. **LRF-1 — Indicator Library (v1)**  
   - 5–10 indicators per domain  
   - includes definitions, sources, update cadence, transformations, caveats

2. **LRF-1 — Weight Profiles (EV/Battery/Semis)**  
   - profile IDs, domain weights, relevance switches, evidence floors

3. **LRF-1 — Rubric Anchors & Thresholds (v1)**  
   - how percentiles/thresholds map to 1–5  
   - per sub-dimension, with examples

4. **LRF-1 — Evidence Library (Tier A/B)**  
   - curated peer-reviewed anchors + institutional methodologies  
   - formatted for quick citation and update discipline

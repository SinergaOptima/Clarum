# Clarum Risk Model Framework

## Philosophy

Risk is multi-dimensional.

Clarum must score categories independently, explain each score, and combine them into a weighted composite that can be tuned by:
- sector (EV vs semiconductors vs batteries)
- value-chain role (assembly vs components vs upstream materials)
- risk tolerance profile (conservative vs aggressive)

Clarum must be:
- explainable (why a score is what it is)
- evidence-backed (citations/links per claim)
- repeatable (same inputs → stable outputs)
- corrigible (easy to update when reality changes)

## Score Scale

Default scale (per category):
- **1.0–1.9:** Low risk
- **2.0–2.9:** Moderate risk
- **3.0–3.9:** High risk
- **4.0–5.0:** Extreme risk

(Internally: store as floats; display as one decimal.)

## Core Risk Categories (v1)

### 1) Regulatory Stability
Assesses:
- clarity of regulatory regime relevant to sector
- consistency of enforcement
- licensing and permitting friction
- legal transparency and contract enforceability
- history of abrupt policy changes

### 2) Geopolitical Exposure
Assesses:
- trade conflict exposure (tariffs, restrictions)
- alliance alignment and tension vectors
- likelihood of sanctions spillover
- cross-border political volatility affecting operations
- diplomatic relations with key markets

### 3) Industrial Policy Alignment
Assesses:
- explicit government support for sector (incentives, zones, subsidies)
- foreign ownership rules and localization requirements
- strategic priority status (and how stable that priority is)
- domestic-content mandates and compliance burden
- risk of policy reversal after elections/leadership change

### 4) Infrastructure Readiness
Assesses:
- grid reliability and energy cost volatility
- logistics capacity (ports, roads, rail, customs efficiency)
- industrial land availability and build timelines
- telecom/digital infrastructure reliability (where relevant)
- single points of failure

### 5) Supply Chain Fragility
Assesses:
- dependency on imports for critical inputs
- maturity of domestic supplier ecosystem
- chokepoints (materials, processing, components)
- redundancy and substitutability
- resilience to disruption (shipping, conflict, export controls)

### 6) Labor & Talent Pool
Assesses:
- availability of skilled labor (manufacturing, engineering, QA)
- training pipeline and retention
- labor regulation rigidity
- strike/instability risk
- wage and productivity dynamics

### 7) Capital & Currency Risk
Assesses:
- FX volatility exposure
- capital controls and repatriation risk
- inflation and interest rate environment
- financing availability for foreign entrants
- political interference in monetary policy (where relevant)

### 8) ESG & Compliance Risk
Assesses:
- environmental permitting and enforcement volatility
- reporting requirements and compliance burden
- corruption perception and procurement risk
- human rights / labor compliance exposure
- sustainability constraints relevant to the sector

## Output Requirements (per category)

Each category must produce:
- score (float)
- short justification (2–4 sentences)
- key evidence bullets (3–7 bullets)
- citations/links per evidence bullet (where possible)
- flags (structured tags)
- confidence level (low/medium/high)

## Composite Risk Index

Composite score = weighted average of category scores.

Default weights (v1):
- Regulatory Stability: 0.15
- Geopolitical Exposure: 0.15
- Industrial Policy Alignment: 0.15
- Infrastructure Readiness: 0.15
- Supply Chain Fragility: 0.15
- Labor & Talent Pool: 0.10
- Capital & Currency Risk: 0.10
- ESG & Compliance Risk: 0.05

Weights are:
- sector-adjustable
- user-adjustable (later feature)
- versioned (so score changes are auditable)

## Moat Principle

The moat is not “AI.”
The moat is:
- the risk ontology,
- the evidence trail,
- the repeatable scoring methodology,
- and the ability to tune weights by sector and role.

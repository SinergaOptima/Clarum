# LRF-1 — Rubric Anchors & Thresholds (v1)

> **Status:** v1.1 (Stable)  
> **Parent:** [[Lattice Risk Framework]] (LRF-1)  
> **Linked:** [[LRF-1 — Indicator Library (v1)]] | [[LRF-1 — Weight Profiles (EV, Battery, Semis)]] | [[Evidence Tiering & Gating]] | [[Clarum — Report Schema (JSON)]]  
> **Applies to:** Clarum — Scoring Engine Layer C  
> **Last Updated:** 2026-02-09

---

## 0. Purpose
This note defines the **Scoring Rubric** for LRF-1. It provides the deterministic rules to convert raw indicators (Layer B) and qualitative evidence (Layer D) into structured risk scores (1.0–5.0).

**Key Principle:** Scores are **outputs**, not inputs. An analyst does not "choose" a score; the system *derives* a score from the rubric, and the analyst validates the evidence trail.

---

## 1. Scoring Scale & Interpretation

| Score Band | Range | Definition | Operational Implication |
| :--- | :--- | :--- | :--- |
| **Low** | 1.0 – 1.9 | **Routine Constraints.** Friction is minimal or highly predictable. | Standard mitigation SOPs apply. No special buffers needed. |
| **Moderate** | 2.0 – 2.9 | **Manageable Friction.** Constraints exist but are navigable with planning. | Requires specific mitigation planning and budget buffers (e.g., +10% time). |
| **High** | 3.0 – 3.9 | **Structural Barriers.** Constraints will materially impact timeline or cost. | Requires strategic mitigation (JV partner, site selection) and significant buffers (+25%). |
| **Extreme** | 4.0 – 5.0 | **Viability Threat.** Constraints threaten the core business case. | Requires executive sign-off or "Go/No-Go" review. Mitigation may not be possible. |

*   **Precision:** Internal calculation uses `float` (e.g., 3.42). Display uses 1 decimal place (e.g., 3.4). Rounding is **Half-Up** (3.45 -> 3.5).

---

## 2. Scoring Pipeline (Algorithm)

### Step 1: Case Definition
*   Define `Case` inputs: `Country`, `Sector` (EV/BATT/SEMI), `Role` (OEM/SUPPLIER/etc), `Mode` (EXPORT/DOM/GREEN/MIXED).

### Step 2: Profile Selection
*   Select `WeightProfileID` (e.g., `WP-EV-OEM-EXPORT-1.1`).
*   Select `OverlayID` (e.g., `Balanced`, `Conservative`).
*   Retrieve `DomainWeights` and `CriticalDomains` from [[LRF-1 — Weight Profiles (EV, Battery, Semis)]].

### Step 3: Indicator Selection & Normalization
*   For each Sub-dimension (A1.1 ... A8.5):
    *   Select `RequiredIndicators` based on Relevance Switches in Profile.
    *   Retrieve `RawValue` for each indicator from [[LRF-1 — Indicator Library (v1)]].
    *   **Normalize:** Convert `RawValue` to `NormalizedScore` (1-5) using the **Comparator Set** (Section 3).

### Step 4: Provisional Scoring
*   `SubDimScore_Provisional` = Average of `NormalizedScore`s for valid indicators.
*   If no quantitative indicators exist: Mark as `QualitativeOnly` (requires manual rubric mapping).

### Step 5: Evidence Gating & Confidence
*   Calculate `EvidenceCount` and `TierRatio` (A/B/C).
*   Check against `EvidenceRequirements` block from Weight Profile.
*   Assign `Confidence` (Low/Med/High).

### Step 6: Missingness Penalty
*   Calculate `CompletenessScore` (0-100%).
*   Apply **Conservative Tilt**: If `Completeness < Threshold`, score remains neutral (2.5) but `Confidence` is capped at **Low**. We do *not* artificially inflate risk for missing data unless the "Unknown" itself is a known hazard.

### Step 7: Overrides & Flags
*   Check **Override Flags** (Section 6).
*   If triggered: `SubDimScore_Final = Max(SubDimScore_Provisional, FlagFloor)`.
*   Append `FlagID` to output.

### Step 8: Aggregation
*   `DomainScore` = Weighted Average of `SubDimScore_Final` (Default: Equal weights for sub-dims unless specified).
*   `CompositeScore` = Sum(`DomainScore` * `ProfileWeight_Domain`).

### Step 9: Audit Emission
*   Generate JSON output conforming to [[Clarum — Report Schema (JSON)]] including all audit fields (Section 9).

---

## 3. Comparator Sets & Normalization

### 3.1 Comparator Sets
To ensure "High Risk" means something relative to reality, we normalize against a defined set.

*   **Option A: Global (Default):** All countries with >$10B GDP. Robust, stable.
*   **Option B: Peer Group (Income):** Upper-Middle Income + High Income. (Stricter standard).
*   **Option C: Regional:** E.g., "ASEAN + India". (Good for "Best in Region" analysis).

**Default Rule (v1):** Use **Option A (Global)** for all quantitative normalization to ensure cross-region comparability.

### 3.2 Normalization Method: Percentile Mapping
Because data distributions vary (some normal, some power-law), we use Percentile Ranks mapped to the 1-5 scale.

*   **Percentile 0-20 (Best):** Score 1.0 - 1.8
*   **Percentile 20-40:** Score 1.9 - 2.6
*   **Percentile 40-60:** Score 2.7 - 3.4
*   **Percentile 60-80:** Score 3.5 - 4.2
*   **Percentile 80-100 (Worst):** Score 4.3 - 5.0

*Note: Invert percentiles if "Higher is Better" (e.g., Regulatory Quality).*

---

## 4. Evidence Gating (Rubric-Level)

### 4.1 Universal Minimums
Unless the **Weight Profile** specifies stricter rules (e.g., for Critical Domains):

*   **High Confidence:**
    *   ≥ 5 Evidence Bullets total per Domain.
    *   ≥ 2 Tier A sources per Domain.
    *   No un-adjudicated contradictions.
    *   Completeness > 80%.

*   **Medium Confidence:**
    *   ≥ 3 Evidence Bullets total per Domain.
    *   ≥ 1 Tier A/B source.
    *   Completeness > 50%.

*   **Low Confidence:**
    *   Anything less.

### 4.2 Contradiction Handling
*   **Rule:** If Tier A and Tier B conflict, Tier A wins.
*   **Rule:** If two Tier A sources conflict (e.g., World Bank vs IMF), score effectively averages them, but `Confidence` is capped at **Medium** and a `ContradictionFlag` is raised.

---

## 5. Missingness & Proxy Penalties

### 5.1 Completeness Score
*   Per Sub-Dimension: `Count(ValidIndicators) / Count(RequiredIndicators)`
*   Per Domain: Average of Sub-Dimension scores.

### 5.2 Penalty Function (Conservative Tilt)
We do not punish the *Score* for missing data (avoiding false alarms). We punish the *Confidence*.

*   **Algorithm:**
    *   If `Completeness < 50%`: `Confidence` = **Low** (Hard Cap).
    *   If `Completeness >= 50%`: `Confidence` calculated via Evidence Gating.
    *   **Dashboard Flag:** Display "Data Gaps" warning if >20% of Critical Domains have <50% completeness.

---

## 6. Override Flags & Floors
These are "Hard Stops" that override the weighted average. They represent existential or severe structural risks.

| Flag ID | Trigger Definition | Effect | Applies To | Notes |
| :--- | :--- | :--- | :--- | :--- |
| **FLG-A1-001** | Rule of Law Index < 10th Percentile | **Floor: 4.5 (A1)** | All | Systemic collapse risk. |
| **FLG-A2-001** | Binding UN/US/EU Sanctions on Sector | **Floor: 5.0 (A2)** | All | Market entry likely illegal/impossible. |
| **FLG-A2-002** | Active Armed Conflict in Industrial Zones | **Floor: 4.5 (A2)** | All | Physical safety threat. |
| **FLG-A2-003** | Entity List Designation (Major Supplier) | **Review Required** | Semi | Check specific license exceptions. |
| **FLG-A3-001** | Local Content Requirement > 60% w/ Penalties | **Floor: 4.0 (A3)** | EV/Batt | Forced localization trap. |
| **FLG-A4-001** | Grid Outages > 10% of Operating Hours | **Floor: 4.5 (A4)** | Batt/Semi | Incompatible with continuous mfg. |
| **FLG-A4-002** | Water Stress "Extremely High" (>80%) | **Floor: 4.5 (A4)** | Batt/Semi | Existential for wet processes. |
| **FLG-A5-001** | Single-Source Supplier (>80% depend.) in Risk Zone | **Floor: 4.0 (A5)** | All | Single point of failure. |
| **FLG-A7-001** | Capital Controls (No Repatriation allowed) | **Floor: 4.5 (A7)** | Foreign Inv | Trapped cash flow. |
| **FLG-A7-002** | Hyperinflation (>50% annual) | **Floor: 4.0 (A7)** | All | Cost planning impossible. |
| **FLG-A8-001** | Systemic Child/Forced Labor (Tier 3 Watchlist) | **Floor: 4.5 (A8)** | Brand Sensitive | Supply chain exclusion risk. |
| **FLG-A8-002** | Enforced Environmental Moratorium | **Floor: 5.0 (A8)** | Extractive | Project legally blocked. |

---

## 7. Rubric Anchors by Domain

### A1: Regulatory Stability & Rule-of-Law
*Sub-dimensions: A1.1 Policy Volatility, A1.2 Enforcement, A1.3 Permitting, A1.4 Contracts, A1.5 Admin Burden, A1.6 Capture.*

#### [A1.3] Permitting Friction & Timeline Uncertainty
**Measures:** Predictability and speed of obtaining necessary licenses (Construction, Environmental, Operating).
**Primary Indicators:** Doing Business (Construction Permits), expert survey data.

| Anchor ID | Anchor | Score Range | Criteria (Qualitative/Quantitative) |
| :--- | :--- | :--- | :--- |
| **RA-A1.3-001** | **Routine** | 1.0 – 1.9 | Digital/One-stop shop exists. Timelines < 3 months. Clear statutory limits. |
| **RA-A1.3-002** | **Manageable** | 2.0 – 2.9 | Delays common (3-6 months) but process is defined. Expediting possible via legitimate fees. |
| **RA-A1.3-003** | **Structural** | 3.0 – 3.9 | Timelines unpredictable (6-18 months). Multiple overlapping agencies. Discretionary veto power. |
| **RA-A1.3-004** | **Extreme** | 4.0 – 5.0 | Indefinite delays standard. Political sign-off required for routine permits. Moratoriums frequent. |

#### [A1.2] Enforcement Consistency
**Measures:** Whether rules are applied equally to all actors or selectively.
**Primary Indicators:** WGI Rule of Law, WJP Open Government.

| Anchor ID | Anchor | Score Range | Criteria |
| :--- | :--- | :--- | :--- |
| **RA-A1.2-001** | **Routine** | 1.0 – 1.9 | Courts independent. Rulings enforced reliably. |
| **RA-A1.2-002** | **Manageable** | 2.0 – 2.9 | Slow enforcement. Some inconsistency in lower courts/provinces. |
| **RA-A1.2-003** | **Structural** | 3.0 – 3.9 | Systemic bias against foreign firms. Selective enforcement used as political tool. |
| **RA-A1.2-004** | **Extreme** | 4.0 – 5.0 | Rule by decree. Expropriation risk. Contracts unenforceable. |

---

### A2: Geopolitical, Sanctions, & Trade Exposure
*Sub-dimensions: A2.1 Tariffs, A2.2 Sanctions, A2.3 Export Controls, A2.4 Alliances, A2.5 Conflict, A2.6 Extraterritorial.*

#### [A2.1] Tariff & Trade Policy Volatility
**Measures:** Exposure to duty changes and market access barriers.
**Primary Indicators:** Weighted Mean Tariff, FTA coverage.

| Anchor ID | Anchor | Score Range | Criteria |
| :--- | :--- | :--- | :--- |
| **RA-A2.1-001** | **Routine** | 1.0 – 1.9 | Full FTA access to target markets. Bound tariffs. Stable relationships. |
| **RA-A2.1-002** | **Manageable** | 2.0 – 2.9 | Moderate tariffs (5-10%). Some non-tariff barriers (NTBs). |
| **RA-A2.1-003** | **Structural** | 3.0 – 3.9 | High tariffs (>25%). Active trade disputes. retaliatory threats common. |
| **RA-A2.1-004** | **Extreme** | 4.0 – 5.0 | Embargoes. Quotas fully utilized. Market access denied. |

#### [A2.3] Export Controls / Tech Restrictions
**Measures:** Risk of technology transfer blocks or input denial.
**Primary Indicators:** BIS Entity List, Wassenaar Arrangement status.

| Anchor ID | Anchor | Score Range | Criteria |
| :--- | :--- | :--- | :--- |
| **RA-A2.3-001** | **Routine** | 1.0 – 1.9 | No restrictions. Full ally status (NATO/Five Eyes equivalent). |
| **RA-A2.3-002** | **Manageable** | 2.0 – 2.9 | Standard dual-use licensing. Routine compliance overhead. |
| **RA-A2.3-003** | **Structural** | 3.0 – 3.9 | "Grey list" status. High scrutiny. Some inputs restricted/delayed. |
| **RA-A2.3-004** | **Extreme** | 4.0 – 5.0 | Comprehensive denial orders. "Foreign Direct Product Rule" applies. |

---

### A3: Industrial Policy Alignment
*Sub-dimensions: A3.1 Priority, A3.2 FDI Screening, A3.3 Localization, A3.4 Subsidies, A3.5 Standards, A3.6 Neutrality.*

#### [A3.3] Localization & Content Rules (LCR)
**Measures:** Requirements to source locally or transfer IP.
**Primary Indicators:** OECD FDI Restrictiveness, USTR reports.

| Anchor ID | Anchor | Score Range | Criteria |
| :--- | :--- | :--- | :--- |
| **RA-A3.3-001** | **Routine** | 1.0 – 1.9 | No LCRs. Full freedom of sourcing. |
| **RA-A3.3-002** | **Manageable** | 2.0 – 2.9 | Soft targets (incentive-tied). Moderate LCR (<30%) achievable. |
| **RA-A3.3-003** | **Structural** | 3.0 – 3.9 | Binding LCR (>40%) with penalties. Forced JV or Tech Transfer pressure. |
| **RA-A3.3-004** | **Extreme** | 4.0 – 5.0 | Prohibitive LCR (>60%) impossible to meet. Import bans on key components. |

---

### A4: Infrastructure Readiness
*Sub-dimensions: A4.1 Grid, A4.2 Energy Cost, A4.3 Logistics, A4.4 Customs, A4.5 Land, A4.6 Digital.*

#### [A4.1] Grid Reliability & Capacity
**Measures:** Uptime, voltage stability, and connection timeline.
**Primary Indicators:** SAIDI/SAIFI, WEF Electricity Quality.

| Anchor ID | Anchor | Score Range | Criteria |
| :--- | :--- | :--- | :--- |
| **RA-A4.1-001** | **Routine** | 1.0 – 1.9 | 99.9% uptime. Industrial voltage stable. Connection < 3 months. |
| **RA-A4.1-002** | **Manageable** | 2.0 – 2.9 | Occasional brownouts (planned). Connection 6-12 months. |
| **RA-A4.1-003** | **Structural** | 3.0 – 3.9 | Frequent unplanned outages. Generators mandatory. Connection > 18 months. |
| **RA-A4.1-004** | **Extreme** | 4.0 – 5.0 | Grid collapse common. Rationing enforced. Capacity unavailable for large loads. |

#### [A4.3] Logistics Throughput
**Measures:** Port/Rail/Road efficiency and capacity.
**Primary Indicators:** LPI (Logistics Performance Index), Container Dwell Time.

| Anchor ID | Anchor | Score Range | Criteria |
| :--- | :--- | :--- | :--- |
| **RA-A4.3-001** | **Routine** | 1.0 – 1.9 | LPI Top Quartile. Dwell time < 3 days. Multi-modal redundancy. |
| **RA-A4.3-002** | **Manageable** | 2.0 – 2.9 | LPI 2nd Quartile. Dwell time 4-7 days. Occasional congestion. |
| **RA-A4.3-003** | **Structural** | 3.0 – 3.9 | LPI 3rd Quartile. Dwell time > 10 days. Single choke point (one road/port). |
| **RA-A4.3-004** | **Extreme** | 4.0 – 5.0 | Systemic failure. indefinite backlogs. Theft/security risk high. |

---

### A5: Supply Chain Resilience
*Sub-dimensions: A5.1 Concentration, A5.2 Chokepoints, A5.3 Substitutes, A5.4 Maturity, A5.5 Inventory, A5.6 Reconfig.*

#### [A5.1] Concentration Risk
**Measures:** Dependence on single geographies or suppliers.
**Primary Indicators:** Herfindahl-Hirschman Index (Trade).

| Anchor ID | Anchor | Score Range | Criteria |
| :--- | :--- | :--- | :--- |
| **RA-A5.1-001** | **Routine** | 1.0 – 1.9 | Diversified supply (<20% from one source). Substitutes readily available. |
| **RA-A5.1-002** | **Manageable** | 2.0 – 2.9 | Moderate concentration (20-50%). Alternatives qualify-able in < 3 months. |
| **RA-A5.1-003** | **Structural** | 3.0 – 3.9 | High concentration (>50%). Re-qualification takes > 6 months. |
| **RA-A5.1-004** | **Extreme** | 4.0 – 5.0 | Single-source monopoly (>80%). No viable substitutes. |

---

### A6: Labor, Talent, & Capacity
*Sub-dimensions: A6.1 Skilled Labor, A6.2 Eng Pipeline, A6.3 Volatility, A6.4 Training, A6.5 Mgmt, A6.6 Safety.*

#### [A6.1] Skilled Labor Availability
**Measures:** Depth of local pool for specific technical roles.
**Primary Indicators:** Human Capital Index, STEM grad stats.

| Anchor ID | Anchor | Score Range | Criteria |
| :--- | :--- | :--- | :--- |
| **RA-A6.1-001** | **Routine** | 1.0 – 1.9 | Deep ecosystem. Hiring lead time < 4 weeks. High retention. |
| **RA-A6.1-002** | **Manageable** | 2.0 – 2.9 | Pool exists but competitive. Hiring lead time 4-12 weeks. Wage inflation moderate. |
| **RA-A6.1-003** | **Structural** | 3.0 – 3.9 | Scarcity. Expat reliance required for technical roles. High turnover. |
| **RA-A6.1-004** | **Extreme** | 4.0 – 5.0 | "Talent Desert." Essential skills unavailable locally. massive training burden. |

---

### A7: Capital, Currency, & Repatriation
*Sub-dimensions: A7.1 FX Volatility, A7.2 Controls, A7.3 Inflation, A7.4 Credit, A7.5 Policy Credibility.*

#### [A7.2] Capital Controls & Repatriation
**Measures:** Ability to move profit and capital across borders.
**Primary Indicators:** Chinn-Ito Index.

| Anchor ID | Anchor | Score Range | Criteria |
| :--- | :--- | :--- | :--- |
| **RA-A7.2-001** | **Routine** | 1.0 – 1.9 | Open capital account. No restrictions. |
| **RA-A7.2-002** | **Manageable** | 2.0 – 2.9 | Reporting requirements. Minor delays (days). |
| **RA-A7.2-003** | **Structural** | 3.0 – 3.9 | Approval required for large transfers. Delays (weeks). FX rationing. |
| **RA-A7.2-004** | **Extreme** | 4.0 – 5.0 | Strict controls. Repatriation blocked. Parallel exchange rates. |

---

### A8: Integrity, ESG, & Compliance
*Sub-dimensions: A8.1 Corruption, A8.2 Env Permitting, A8.3 Human Rights, A8.4 Reporting, A8.5 Social License, A8.6 Litigation.*

#### [A8.1] Corruption & Integrity
**Measures:** Operational corruption (bribes) and state capture.
**Primary Indicators:** CPI (Transparency Int'l), Trace Matrix.

| Anchor ID | Anchor | Score Range | Criteria |
| :--- | :--- | :--- | :--- |
| **RA-A8.1-001** | **Routine** | 1.0 – 1.9 | Rare/Isolated. Strong anti-bribery enforcement. |
| **RA-A8.1-002** | **Manageable** | 2.0 – 2.9 | Occasional facilitation payments in lower tiers. Policy prohibits but enforcement lags. |
| **RA-A8.1-003** | **Structural** | 3.0 – 3.9 | Systemic in specific sectors (customs/permitting). "Pay to play" common. |
| **RA-A8.1-004** | **Extreme** | 4.0 – 5.0 | State Capture. Kleptocracy. Compliance with FCPA/UKBA impossible without exiting. |

---

### Missing Sub-Dimensions (v1.0 Placeholders)
*Rules for sub-dimensions not explicitly detailed above (e.g., A1.1, A2.2, A4.4).*

1.  **Inheritance:** Use the **Domain Score** calculated from present sub-dimensions as the provisional baseline.
2.  **Qualitative Adjustment:** Analyst may adjust ±0.5 based on Tier A evidence.
3.  **Confidence Cap:** **Cannot exceed Medium Confidence.**
4.  **Audit Flag:** Record `is_placeholder=true` in output.

---

## 8. Aggregation Rules

### 8.1 Sub-Dimension Weights
*   **Default:** Equal weighting (Arithmetic Mean) of all *valid* sub-dimensions within a Domain.
*   **Justification:** Precision at the sub-dimension level is often spurious; averaging reduces noise.

### 8.2 Missing Sub-Dimensions
*   If a sub-dimension is missing (no data + no qualitative evidence), it is excluded from the average (denominator reduction).
*   **Constraint:** If >50% of sub-dimensions in a Domain are missing, the Domain Score defaults to **Review Required** (null).

### 8.3 Confidence Propagation
*   `DomainConfidence` = Lowest common denominator of the *Critical* sub-dimensions defined in the Weight Profile.
*   *Example:* If A4 (Infra) is Critical, and A4.1 (Grid) has Low Confidence, then Domain A4 has Low Confidence, even if A4.3 (Logistics) is High.

---

## 9. Audit Fields Required (Schema)
The following fields must be persisted in the JSON output for every scoring run:

*   `rubric_version`: "LRF-1.1"
*   `comparator_set_id`: "GLOBAL-GDP-10B+"
*   `normalization_method`: "PERCENTILE-RANK"
*   `indicator_inputs_used`: List of `{indicator_id, raw_value, normalized_score}`
*   `evidence_counts_by_tier`: `{tier_a: int, tier_b: int, tier_c: int}`
*   `completeness_scores`: Map of Domain -> %
*   `flags_triggered`: List of `flag_id`s
*   `overrides_applied`: List of `{sub_dim_id, original_score, final_score, reason}`
*   `weight_profile_id`: "WP-EV-OEM-EXPORT-1.1"
*   `overlay_id`: "CONS" (plus `effective_deltas`)
*   `final_scores`: Map of Domain/Composite scores.

---

## 10. Versioning & Change Control

### 10.1 Versioning Rules
*   **v1.0 (MVP):** Fixed anchors.
*   **v1.1:** Added explicit ID tags (`RA-A#.#-NNN`) and Placeholder rules for coverage completeness.

### 10.2 Changelog Template
> **2026-02-09 - Rubric v1.1 Update**
> *   **Added:** Explicit ID tags to all Anchor rows.
> *   **Added:** Placeholder logic for missing sub-dimensions (A1.1, A1.4, etc.).
> *   **Impact:** Enables machine-readable audit trails and safe handling of missing rubrics.
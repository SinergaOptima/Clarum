# LRF-1 — Weight Profiles (EV, Battery, Semis)

> **Status:** v1.1 (Stable)  
> **Parent:** [[Lattice Risk Framework]] (LRF-1)  
> **Linked:** [[LRF-1 — Indicator Library (v1)]] | [[Evidence Tiering & Gating]]  
> **Applies to:** Clarum — Scoring Engine Layer C  
> **Last Updated:** 2026-02-09

---

## 1. Overview & ID System
This note defines the **Weight Profiles** used to compute the **composite risk score from Domain scores** in LRF-1. A weight profile adjusts the importance of each risk domain (A1–A8) based on the specific sector, role, and operating model of the market entry project.

### 1.1 Profile ID Logic
Profiles use a stable, machine-readable ID format: `WP-<SECTOR>-<ROLE>-<MODE>-<VERSION>`

| Component | Allowed Values |
| :--- | :--- |
| **WP** | Constant (Weight Profile) |
| **SECTOR** | `EV` (Electric Vehicle), `BATT` (Battery), `SEMI` (Semiconductors) |
| **ROLE** | `OEM`, `CELL`, `PACK`, `MAT` (Materials), `OSAT` (Assembly/Test), `ADV` (Advanced Packaging), `COMP` (Components) |
| **MODE** | `EXPORT` (Global supply), `DOM` (Local market), `GREEN` (Greenfield build), `MIXED` (Hybrid) |
| **VERSION** | `1.1` (Major.Minor) |

**Example:** `WP-EV-OEM-EXPORT-1.1` (EV OEM, Export-oriented, Version 1.1)

### 1.2 Deprecation Rules
- Profiles are **Immutable** once published. A dossier generated with `WP-EV-OEM-EXPORT-1.0` must always be reproducible.
- Updates create new versions (e.g., `1.1`).
- Deprecated profiles are flagged `[ARCHIVED]` but remain in the codebase.

---

## 2. Baseline Profiles (v1.1)
**Global Rule (v1.1):** No domain weight may be below **0.05** (blind spot protection).

### 2.1 Electric Vehicle (EV) Sector

#### Profile 1: EV OEM Assembly — Export-Oriented
**ID:** `WP-EV-OEM-EXPORT-1.1`  
**Scenario:** Establishing a vehicle assembly plant primarily to serve export markets (US/EU/Global).
**Assumptions:** High logistics sensitivity; high trade policy exposure; moderate energy intensity.

| Domain | Name | Weight | Rationale |
| :--- | :--- | :--- | :--- |
| **A1** | Regulatory Stability | 0.10 | Important for long-term ops, but less critical than trade access. |
| **A2** | Geopolitics & Trade | **0.20** | **Critical.** Tariffs (USMCA/EU CBAM) and origin rules define viability. |
| **A3** | Ind. Policy & Access | 0.15 | Subsidies/Incentives often drive the location decision. |
| **A4** | Infrastructure | **0.20** | **Critical.** Port throughput and rail reliability are non-negotiable. |
| **A5** | Supply Chain | 0.15 | Need local supplier ecosystem (Just-in-Sequence). |
| **A6** | Labor & Talent | 0.10 | Assembly is labor-intensive; strikes/turnover matter. |
| **A7** | Capital & FX | 0.05 | Hedging usually managed centrally; CAPEX is one-off. |
| **A8** | Integrity & ESG | 0.05 | Compliance is standard; less material impact on daily output. |
| **SUM** | | **1.00** | |

**Evidence Requirements:**
```yaml
critical_domains: ["A2", "A4"]
min_confidence_critical: "High"
min_tier_critical: "Tier A"
min_evidence_bullets_per_domain: 3
review_required_trigger: "Confidence < High on A2 OR A4"
```
*   **Mitigation Levers:** Free Trade Zone location; Dual-port access strategy; Bonded warehousing.

#### Profile 2: EV OEM Assembly — Domestic Demand / Mixed
**ID:** `WP-EV-OEM-DOM-1.1`  
**Scenario:** Building to serve the local growing market (e.g., India, Indonesia).
**Assumptions:** Profitability depends on local purchasing power and policy support; less trade risk.

| Domain | Weight | Rationale |
| :--- | :--- | :--- |
| **A1** | 0.15 | Domestic rule enforcement drives daily friction. |
| **A2** | 0.05 | Less export exposure; mainly import of components. |
| **A3** | **0.25** | **Critical.** Domestic subsidies/adoption targets make the market. |
| **A4** | 0.15 | Road/Charging infrastructure matters for demand. |
| **A5** | 0.15 | Local content requirements (LCR) drive supply chain risk. |
| **A6** | 0.10 | Cost sensitivity requires efficient local labor. |
| **A7** | 0.10 | Local currency revenue vs. USD component costs (FX mismatch). |
| **A8** | 0.05 | Standard compliance. |
| **SUM** | **1.00** | |

**Evidence Requirements:**
```yaml
critical_domains: ["A3", "A1"]
min_confidence_critical: "Medium"
min_tier_critical: "Tier B"
min_evidence_bullets_per_domain: 3
review_required_trigger: "Confidence < Medium on A3"
```
*   **Mitigation Levers:** JV with local champion; Lobbying for demand-side subsidies; Local currency financing.

#### Profile 3: EV Components Supplier — Tier-1/2
**ID:** `WP-EV-COMP-EXPORT-1.1`  
**Scenario:** Manufacturing subsystems (brakes, seats, electronics) for global OEMs.
**Assumptions:** Margins are thin; reliability and cost are paramount.

| Domain | Weight | Rationale |
| :--- | :--- | :--- |
| **A1** | 0.15 | Permitting speed for quick capacity expansion. |
| **A2** | 0.15 | Indirect trade exposure via OEM clients. |
| **A3** | 0.10 | Less political weight than OEMs. |
| **A4** | 0.15 | Logistics reliability to meet JIT windows. |
| **A5** | 0.10 | Raw material sourcing usually directed by OEM. |
| **A6** | **0.20** | **Critical.** Skilled technical labor for quality control. |
| **A7** | 0.10 | Working capital cycles can be strained by delays. |
| **A8** | 0.05 | Audit trail for OEM compliance. |
| **SUM** | **1.00** | |

**Evidence Requirements:**
```yaml
critical_domains: ["A6", "A4"]
min_confidence_critical: "Medium"
min_tier_critical: "Tier B"
min_evidence_bullets_per_domain: 2
review_required_trigger: "Confidence < Medium on A6"
```
*   **Mitigation Levers:** Training academies; Cluster location (proximity to OEM).

---

### 2.2 Battery Sector

#### Profile 4: Battery Cell Manufacturing — Greenfield
**ID:** `WP-BATT-CELL-GREEN-1.1`  
**Scenario:** Gigafactory construction (Cells). High CAPEX, massive energy/water needs.
**Assumptions:** Utility connection is the single biggest failure point. A7 floor enforced.

| Domain | Name | Weight | Rationale |
| :--- | :--- | :--- | :--- |
| **A1** | Regulatory Stability | 0.15 | Environmental permitting is complex and slow. |
| **A2** | Geopolitics & Trade | 0.10 | Material sourcing restrictions (IRA/CRMA). |
| **A3** | Ind. Policy & Access | 0.15 | CAPEX subsidies are essential for ROI. |
| **A4** | Infrastructure | **0.25** | **Dominant.** Power quality, water access, waste treatment. (Reduced 0.05 to fund A7 floor). |
| **A5** | Supply Chain | 0.15 | Precursor chemicals logistics. |
| **A6** | Labor & Talent | 0.10 | Process engineers are scarce. |
| **A7** | Capital & FX | 0.05 | (v1.1 Floor Enforced). Global financing still primary, but local working cap matters. |
| **A8** | Integrity & ESG | 0.05 | Community opposition risk (NIMBY). |
| **SUM** | | **1.00** | |

**Evidence Requirements:**
```yaml
critical_domains: ["A4", "A1"]
min_confidence_critical: "High"
min_tier_critical: "Tier A"
min_evidence_bullets_per_domain: 4
review_required_trigger: "Missing Tier A data for A4 (Grid)"
```
*   **Mitigation Levers:** On-site substations; Water recycling loops; Pre-permitted industrial park.

#### Profile 5: Battery Pack Integration — Near-OEM
**ID:** `WP-BATT-PACK-MIXED-1.1`  
**Scenario:** Assembling cells into packs near the vehicle plant. Logistics-heavy.
**Assumptions:** Dangerous goods (DG) logistics constraints; Just-in-Time pressure.

| Domain | Weight | Rationale |
| :--- | :--- | :--- |
| **A1** | 0.10 | Fire safety/DG regulations. |
| **A2** | 0.10 | Cells often imported (tariffs apply). |
| **A3** | 0.10 | Moderate policy sensitivity. |
| **A4** | **0.25** | **Critical.** Transport infrastructure (hazmat routes). |
| **A5** | 0.15 | Cell supply consistency. |
| **A6** | **0.20** | **Critical.** High manual assembly or automated line upkeep. |
| **A7** | 0.05 | Standard. |
| **A8** | 0.05 | Safety compliance. |
| **SUM** | **1.00** | |

**Evidence Requirements:**
```yaml
critical_domains: ["A4", "A6"]
min_confidence_critical: "Medium"
min_tier_critical: "Tier B"
min_evidence_bullets_per_domain: 3
review_required_trigger: "Confidence < Medium on A4"
```
*   **Mitigation Levers:** Rail access (if approved for batteries); Co-location with OEM.

#### Profile 6: Battery Materials / Processing — Upstream
**ID:** `WP-BATT-MAT-EXPORT-1.1`  
**Scenario:** Chemical processing (Cathode/Anode active materials). Heavy environmental footprint.
**Assumptions:** Environmental compliance and waste disposal are existential risks.

| Domain | Weight | Rationale |
| :--- | :--- | :--- |
| **A1** | 0.15 | Mining/Chemical codes change frequently. |
| **A2** | 0.15 | Strategic mineral controls / Export bans. |
| **A3** | 0.10 | Downstream integration incentives. |
| **A4** | 0.15 | Energy intensity (Cost of KWh). |
| **A5** | 0.10 | Access to raw ore/brine. |
| **A6** | 0.05 | Low headcount relative to CAPEX. |
| **A7** | 0.05 | Standard. |
| **A8** | **0.25** | **Critical.** Environmental enforcement, tailings, community impact. |
| **SUM** | **1.00** | |

**Evidence Requirements:**
```yaml
critical_domains: ["A8", "A4"]
min_confidence_critical: "High"
min_tier_critical: "Tier A"
min_evidence_bullets_per_domain: 5
review_required_trigger: "Confidence < High on A8"
```
*   **Mitigation Levers:** Zero-liquid discharge (ZLD) tech; Strong community engagement (SLO).

---

### 2.3 Semiconductor Sector

#### Profile 7: Semiconductor OSAT/ATP — Export-Oriented
**ID:** `WP-SEMI-OSAT-EXPORT-1.1`  
**Scenario:** Assembly, Test, and Packaging. High volume, cost-sensitive, export-only.
**Assumptions:** Must move massive volume in/out quickly; sensitive to power blips.

| Domain | Name | Weight | Rationale |
| :--- | :--- | :--- | :--- |
| **A1** | Regulatory Stability | 0.10 | FTZ/Bonded status usually insulates from local friction. |
| **A2** | Geopolitics & Trade | **0.20** | **Critical.** Export controls/Entity List risks. |
| **A3** | Ind. Policy & Access | 0.15 | Tax holidays are the primary driver. |
| **A4** | Infrastructure | **0.20** | **Critical.** Power quality (freq/sag) + Airport proximity. |
| **A5** | Supply Chain | 0.10 | Materials (leadframes/resins) are global. |
| **A6** | Labor & Talent | 0.15 | Scale of operators + equipment technicians. |
| **A7** | Capital & FX | 0.05 | Minimal exposure. |
| **A8** | Integrity & ESG | 0.05 | Customer audit requirements. |
| **SUM** | | **1.00** | |

**Evidence Requirements:**
```yaml
critical_domains: ["A2", "A4"]
min_confidence_critical: "High"
min_tier_critical: "Tier A"
min_evidence_bullets_per_domain: 3
review_required_trigger: "Confidence < High on A2"
```
*   **Mitigation Levers:** Backup power generation (UPS); Airport-adjacent location; bonded zone status.

#### Profile 8: Semiconductor Advanced Packaging — Capability
**ID:** `WP-SEMI-ADV-EXPORT-1.1`  
**Scenario:** CoWoS, 2.5D/3D packaging. Higher value, lower volume than standard OSAT.
**Assumptions:** IP protection and engineering talent are more important than low-cost labor. A7 floor enforced.

| Domain | Weight | Rationale |
| :--- | :--- | :--- |
| **A1** | **0.20** | **Critical.** IP protection & contract enforcement. |
| **A2** | **0.20** | **Critical.** High risk of tech transfer restrictions. (Reduced 0.05 to fund A7). |
| **A3** | 0.10 | Strategic alignment. |
| **A4** | 0.15 | Power stability (clean room uptime). |
| **A5** | 0.10 | Specialized substrate supply. |
| **A6** | 0.15 | High-end process engineers needed. |
| **A7** | 0.05 | (v1.1 Floor Enforced). Capital access for tool upgrades. |
| **A8** | 0.05 | Standard. |
| **SUM** | **1.00** | |

**Evidence Requirements:**
```yaml
critical_domains: ["A2", "A1"]
min_confidence_critical: "High"
min_tier_critical: "Tier A"
min_evidence_bullets_per_domain: 4
review_required_trigger: "Confidence < High on A2 OR A1"
```
*   **Mitigation Levers:** Segregated IP networks; Expat technical leads; redundancy in supply routes.

#### Profile 9: Semiconductor Components — Reliability
**ID:** `WP-SEMI-COMP-EXPORT-1.1`  
**Scenario:** Producing critical consumables (photoresists, gases) or tools.
**Assumptions:** Supply chain purity and continuity are paramount.

| Domain | Weight | Rationale |
| :--- | :--- | :--- |
| **A1** | 0.10 | Chemical handling regs. |
| **A2** | 0.15 | Dual-use chemical controls. |
| **A3** | 0.10 | Localization incentives. |
| **A4** | 0.15 | Transport safety/reliability. |
| **A5** | **0.25** | **Critical.** Feedstock purity & single-source risks. |
| **A6** | 0.10 | Specialized chemical handling talent. |
| **A7** | 0.05 | Standard. |
| **A8** | 0.10 | Environmental/Safety compliance. |
| **SUM** | **1.00** | |

**Evidence Requirements:**
```yaml
critical_domains: ["A5", "A8"]
min_confidence_critical: "High"
min_tier_critical: "Tier B"
min_evidence_bullets_per_domain: 3
review_required_trigger: "Confidence < High on A5"
```
*   **Mitigation Levers:** Multi-sourcing feedstocks; Strategic inventory buffering.

---

## 3. Risk Tolerance Overlays
Overlays allow users to adjust the "sensitivity" of the model based on their organization's risk appetite. These apply mathematically on top of the base profile.

### 3.1 Rules
1.  **Zero-Sum:** Adjustments must broadly balance (conceptually), though LRF-1 allows normalization post-adjustment.
2.  **Constraint:** No domain weight can drop below **0.05** (floor) to prevent blind spots.
3.  **Constraint:** No domain weight can exceed **0.40** (ceiling) to prevent single-variable dominance.

### 3.2 Overlay Definitions

| Overlay | ID Suffix | Description | Weight Logic |
| :--- | :--- | :--- | :--- |
| **Balanced** | `(None)` | Default view. | No change to profile. |
| **Conservative** | `-CONS` | "We cannot afford a surprise." Penalizes instability. | **+0.05 to A1, A2, A8.** <br> **-0.05 from A3, A6, A7.** <br> *Focuses on "Existential Risks" over operational friction.* |
| **Aggressive** | `-AGGR` | "We can solve problems with money." Focuses on fundamentals. | **+0.05 to A3, A4, A6.** <br> **-0.05 from A1, A2, A8.** <br> *Focuses on "Can we build it?" over "Is it stable?"* |

### 3.3 Overlay Application Algorithm (v1.1)
The engine must execute overlays in this exact sequence to ensure reproducibility:

1.  **Apply Deltas:** `Weight_Proposed[i] = Weight_Base[i] + Delta[i]`
2.  **Clamp:** For each domain `i`:
    - `Weight_Clamped[i] = Max(0.05, Min(0.40, Weight_Proposed[i]))`
3.  **Calculate Residual:** `Residual = 1.00 - Sum(Weight_Clamped)`
4.  **Redistribute:** If `Residual != 0`:
    - Distribute `Residual` proportionally across all domains that were **not clamped** to the floor/ceiling.
    - If all domains are clamped (edge case), relax the ceiling constraint proportionally.
5.  **Finalize:** Ensure `Sum(Weight_Final) == 1.00`.
6.  **Record:** Output `overlay_id`, `pre_overlay_weights`, `post_overlay_weights`, and `effective_deltas` in the dossier JSON.

### 3.4 Confidence Impact
*   **Conservative Overlay** requires a **higher evidence floor**. If a dossier is run with `-CONS`, any Critical Domain with "Low Confidence" automatically triggers a "Review Required" flag in the output.

---

## 4. Governance & Change Control

### 4.1 Proposal Process
New profiles must be proposed via a **Methodology Change Request (MCR)** containing:
1.  Use Case Description.
2.  Proposed Weights.
3.  "Backtest" results (How would this profile score 3 benchmark countries?).

### 4.2 Review
- **Approver:** Head of Methodology (Lattice Labs).
- **Criteria:** Does the profile clearly differentiate from existing ones? Is the separation justified by data?

### 4.3 Versioning & Changelog
- **v1.x:** Minor weight tweaks (<0.05 shift). ID stays same, version bumps.
- **v2.0:** Adding/Removing domains. Breaking change.

**Changelog Template:**
> **[Date] - WP-EV-OEM-EXPORT-1.1**
> *   Adjusted A4 weight from 0.20 to 0.25 based on feedback from Mexico Pilot.
> *   Reduced A6 weight to compensate.

---

## 5. Quick Start: Which Profile?

| If you are... | And your goal is... | Use Profile | Overlay |
| :--- | :--- | :--- | :--- |
| **Tesla/BYD/Ford** | Building a massive export hub in Mexico. | `WP-EV-OEM-EXPORT-1.1` | Balanced |
| **Tesla/BYD/Ford** | Entering India to sell to locals. | `WP-EV-OEM-DOM-1.1` | Aggressive |
| **Battery Co.** | Building a Gigafactory (Cells). | `WP-BATT-CELL-GREEN-1.1` | Conservative |
| **Battery Co.** | Processing Lithium/Nickel. | `WP-BATT-MAT-EXPORT-1.1` | Conservative |
| **Chip Maker** | Packaging/Testing (OSAT) in Vietnam. | `WP-SEMI-OSAT-EXPORT-1.1` | Balanced |
| **Chip Maker** | Advanced Packaging (CoWoS) in Malaysia. | `WP-SEMI-ADV-EXPORT-1.1` | Conservative |

### 5.1 Profile Selection Checklist
*   **Step 1: Determine MODE**
    *   [ ] **EXPORT:** >50% of output crosses a border? (Prioritizes Trade/Logistics)
    *   [ ] **DOM:** >50% of output sold locally? (Prioritizes Market Access/Local Compliance)
    *   [ ] **GREEN:** Building from dirt up? (Prioritizes Permitting/Infrastructure)
    *   [ ] **MIXED:** Brownfield or partial reliance on existing ecosystem?

*   **Step 2: Determine ROLE**
    *   [ ] **OEM/OSAT:** Are you the "anchor" tenant? (High political leverage, high visibility)
    *   [ ] **SUPPLIER:** Are you following a client? (High reliability constraint, lower political weight)
    *   [ ] **UPSTREAM:** Are you processing raw materials? (High environmental/energy constraint)

*   **Step 3: Determine OVERLAY**
    *   [ ] **Default:** Use "Balanced" for standard diligence.
    *   [ ] **Conservative:** Use if capital is debt-financed or reputation risk is existential.
    *   [ ] **Aggressive:** Use if time-to-market is the only metric that matters.
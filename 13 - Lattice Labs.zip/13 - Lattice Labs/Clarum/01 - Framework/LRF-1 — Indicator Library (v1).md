# LRF-1 — Indicator Library (v1)

> **Status:** v1.0 (Stable for MVP)  
> **Parent:** [[Lattice Risk Framework]] (LRF-1)  
> **Owner:** Lattice Labs — Methodology  
> **Applies to:** Clarum Market Entry Risk Model  
> **Last Updated:** 2026-02-09

---

## 1. Overview & Rules
This library defines the **MVP Indicator Set** for LRF-1. These indicators represent the "measurable proxies" (Layer B) that feed the scoring model (Layer C).

### 1.1 Inclusion Criteria (v1)
To be included in v1, an indicator must be:
1.  **Authoritative:** Sourced from a Tier A/B institution (World Bank, IMF, OECD, WEF, ILO, etc.).
2.  **Global/comparable:** Available for at least the MVP focus countries (MX, VN, ID, IN, PL).
3.  **Updateable:** Has a known publication cadence (annual/quarterly).
4.  **Defensible:** Maps conceptually to the LRF-1 Risk Ontology.

### 1.2 Data Completeness & Confidence
A "Data Completeness Score" is calculated per domain:
- **Completeness %** = (Count of available required indicators / Total required indicators) * 100
- **Confidence Penalty:**
    - < 60%: **High Penalty** (Confidence cap: Low)
    - 60-80%: **Medium Penalty** (Confidence cap: Medium)
    - > 80%: **No Penalty**

### 1.3 Minimum Evidence Floor (v1)
To achieve **Medium** or **High** confidence in a domain score, the following minimums apply:
- **Medium Confidence:** ≥ 3 Tier A/B indicators present + < 20% missing data.
- **High Confidence:** ≥ 5 Tier A/B indicators present + 0% missing data + corroborating qualitative evidence.

---

## 2. Indicator Library (by Domain)

### Domain A1: Regulatory Stability & Rule-of-Law
*Predictability and enforceability of the operating environment.*

| ID | Dim | Name | Definition | Measurement | Source (Tier) | Transform | Update |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **IND-A1-REG-001** | A1.1 | **Regulatory Quality Estimate** | Perceived ability of gov't to formulate/implement sound policies. | Score (-2.5 to 2.5) | World Bank WGI (A) | Percentile Rank | Annual |
| **IND-A1-REG-002** | A1.2 | **Rule of Law Estimate** | Confidence in rules of society, contract enforcement, property rights. | Score (-2.5 to 2.5) | World Bank WGI (A) | Percentile Rank | Annual |
| **IND-A1-REG-003** | A1.4 | **Contract Enforcement Efficiency** | Time and cost to resolve a commercial dispute in court. | Days / % of claim | World Bank Doing Business (Legacy) / Rule of Law Index (A) | Inverse Normalized (Lower is better) | Annual |
| **IND-A1-REG-004** | A1.3 | **Permitting Complexity Index** | Proxy: Procedures/time to obtain construction permits. | Number of procedures / Days | World Bank / OECD (A) | Inverse Normalized | Annual |
| **IND-A1-REG-005** | A1.5 | **Regulatory Burden Perception** | Executive opinion on burden of gov't regulation. | Score (1-7) | WEF GCR (B) | Z-Score | Annual |
| **IND-A1-REG-006** | A1.6 | **Policy Instability Concern** | Frequency of policy reversals affecting business (coded). | Index (0-100) | Fragile States Index / PRS Group (B) | Bucket Thresholds | Annual |

*   **Relevance:** Universal.
*   **Missingness:** Fallback to regional average with penalty.
*   **Evidence Anchor:** Kaufmann, D., Kraay, A., & Mastruzzi, M. (2010). *The Worldwide Governance Indicators: Methodology and Analytical Issues*.

### Domain A2: Geopolitical, Sanctions, & Trade Exposure
*Vulnerability to cross-border policy conflict.*

| ID | Dim | Name | Definition | Measurement | Source (Tier) | Transform | Update |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **IND-A2-GEO-001** | A2.1 | **Trade Openness Index** | Trade (% of GDP) or Tariff rate (applied, weighted mean). | Percentage | World Bank / WTO (A) | Bucket Thresholds | Annual |
| **IND-A2-GEO-002** | A2.2 | **Sanctions Alignment Risk** | Voting alignment with major sanctioning bodies (US/EU) on key UN resolutions. | Alignment Score (0-1) | UN / Lattice Proprietary (C) | Linear Scaling | Event-driven |
| **IND-A2-GEO-003** | A2.4 | **Geopolitical Alignment (Bloc)** | Membership in strategic alliances (NATO, BRICS, CPTPP, RCEP). | Categorical (Binary Flags) | Treaty Databases (A) | Risk Weights | Event-driven |
| **IND-A2-GEO-004** | A2.5 | **Conflict Intensity Index** | Presence/intensity of violent internal/external conflict. | Score (0-10) | ACLED / UCDP (A) | Thresholds | Annual |
| **IND-A2-GEO-005** | A2.3 | **High-Tech Export Restrictions** | Presence of specific export controls on dual-use tech (Semis/AI). | Binary / Count | BIS / WA / National Lists (A) | Boolean Flag | Event-driven |

*   **Relevance:** A2.3 Critical for Semis; A2.2 Critical for all cross-border.
*   **Missingness:** Fatal for A2.2/A2.3 (Manual override required).
*   **Evidence Anchor:** Davis, D. R., & Weinstein, D. E. (2002). *Bonuses or Wagers: Trade and Conflict*.

### Domain A3: Industrial Policy Alignment & Market Access
*State support vs. obstruction.*

| ID | Dim | Name | Definition | Measurement | Source (Tier) | Transform | Update |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **IND-A3-POL-001** | A3.2 | **FDI Restrictiveness Index** | Statutory restrictions on foreign equity/screening. | Score (0-1, 0=open) | OECD (A) | Direct Mapping | Annual |
| **IND-A3-POL-002** | A3.4 | **Gov't Support for Tech** | Policy prioritization of ICT/Advanced Mfg (coded). | Score (1-7) | WEF / ITU (B) | Z-Score | Annual |
| **IND-A3-POL-003** | A3.3 | **Local Content Requirements** | Presence of LCRs in target sector (EV/Batt). | Binary / Severity Scale | WTO / USTR Reports (B) | Risk Weights | Annual |
| **IND-A3-POL-004** | A3.6 | **SOE Prevalence** | Share of SOEs in economy/sector or distortion level. | Score/Index | OECD / IMF (A) | Bucket Thresholds | Annual |
| **IND-A3-POL-005** | A3.1 | **Strategic Sector Designation** | Is the sector explicitly named in national dev plans? | Binary (Yes/No) | National Policy Docs (A) | Bonus/Penalty | Ad-hoc |

*   **Relevance:** High for Greenfields/JVs.
*   **Missingness:** Qualitative override permitted.
*   **Evidence Anchor:** Rodrik, D. (2004). *Industrial Policy for the Twenty-First Century*.

### Domain A4: Infrastructure Readiness
*Operational bottlenecks (Energy, Logistics).*

| ID | Dim | Name | Definition | Measurement | Source (Tier) | Transform | Update |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **IND-A4-INF-001** | A4.3 | **LPI - Logistics Performance Index** | Overall quality of trade/transport infrastructure. | Score (1-5) | World Bank (A) | Inverted Scale | Biennial |
| **IND-A4-INF-002** | A4.1 | **Quality of Electricity Supply** | Reliability/frequency of interruptions. | Score (1-7) | WEF GCR (B) | Z-Score | Annual |
| **IND-A4-INF-003** | A4.2 | **Industrial Electricity Price Volatility** | Variance in industrial tariff over 3y. | Variance / CAGR | IEA / National Grid (A) | Thresholds | Annual |
| **IND-A4-INF-004** | A4.3 | **Port Efficiency / Dwell Time** | Average container dwell time (import). | Days | IMF PortWatch / UNCTAD (A) | Inverse Normalized | Monthly |
| **IND-A4-INF-005** | A4.6 | **Industrial Internet Quality** | Bandwidth/latency reliability for enterprise. | Index | Ookla / ITU (B) | Thresholds | Annual |
| **IND-A4-INF-006** | A4.5 | **Industrial Land Availability** | Proxy: Ease of registering property. | Score / Days | World Bank (A) | Inverse Normalized | Annual |

*   **Relevance:** A4.2/A4.1 Critical for Battery Mfg & Semis.
*   **Evidence Anchor:** Arvis, J. F., et al. (2018). *Connecting to Compete: Trade Logistics in the Global Economy*.

### Domain A5: Supply Chain Structure & Resilience
*Fragility and adaptability.*

| ID | Dim | Name | Definition | Measurement | Source (Tier) | Transform | Update |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **IND-A5-SUP-001** | A5.1 | **Export Concentration Index** | Herfindahl-Hirschman Index (HHI) of exports (product/partner). | Score (0-1) | UNCTAD (A) | Direct Mapping | Annual |
| **IND-A5-SUP-002** | A5.3 | **Manufacturing Value Added** | Depth of local industrial base (% of GDP). | Percentage | World Bank (A) | Percentile Rank | Annual |
| **IND-A5-SUP-003** | A5.2 | **Critical Raw Material Production** | Share of global production for sector-critical minerals (Li, Co, Ni). | Percentage | USGS / IEA (A) | Inverted Risk (High share = Low local risk) | Annual |
| **IND-A5-SUP-004** | A5.4 | **Quality Certification Density** | ISO 9001 certificates per capita/firm. | Count / Ratio | ISO Survey (B) | Percentile Rank | Annual |
| **IND-A5-SUP-005** | A5.6 | **Supplier Delivery Time** | PMI Supplier Delivery Times sub-index. | Index (50=neutral) | S&P Global PMI (B) | Deviation from 50 | Monthly |

*   **Relevance:** A5.3 Critical for Battery Materials.
*   **Evidence Anchor:** Gereffi, G., & Lee, J. (2012). *Why the World Suddenly Cares About Global Supply Chains*.

### Domain A6: Labor, Talent, & Operational Capacity
*Workforce support for ramp.*

| ID | Dim | Name | Definition | Measurement | Source (Tier) | Transform | Update |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **IND-A6-LAB-001** | A6.1 | **Human Capital Index (HCI)** | Potential productivity of future worker. | Score (0-1) | World Bank (A) | Percentile Rank | Annual |
| **IND-A6-LAB-002** | A6.2 | **STEM Graduates** | % of tertiary graduates in Science/Eng. | Percentage | UNESCO / OECD (A) | Bucket Thresholds | Annual |
| **IND-A6-LAB-003** | A6.3 | **Labor Freedom / Flexibility** | Regs on hiring/firing, hours, min wage. | Score (0-100) | Fraser Institute / Heritage (B) | Inverted (if rigidity is risk) | Annual |
| **IND-A6-LAB-004** | A6.3 | **Strike / Labor Unrest Risk** | Frequency/severity of civil/labor unrest. | Score | Verisk / ACLED (B) | Thresholds | Quarterly |
| **IND-A6-LAB-005** | A6.1 | **Ease of Finding Skilled Employees** | Executive sentiment. | Score (1-7) | WEF / ManpowerGroup (B) | Z-Score | Annual |

*   **Relevance:** A6.2 Critical for Semis/R&D.
*   **Evidence Anchor:** Hanushek, E. A., & Woessmann, L. (2008). *The Role of Cognitive Skills in Economic Development*.

### Domain A7: Capital, Currency, & Repatriation Risk
*Financial friction.*

| ID | Dim | Name | Definition | Measurement | Source (Tier) | Transform | Update |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **IND-A7-CAP-001** | A7.1 | **Exchange Rate Volatility** | Standard deviation of monthly % change (1y/3y). | Percentage | IMF IFS (A) | Bucket Thresholds | Monthly |
| **IND-A7-CAP-002** | A7.2 | **Chinn-Ito Index** | Measure of financial openness (capital controls). | Score (-1.9 to 2.3) | Chinn-Ito (Academic) (A) | Percentile Rank | Annual |
| **IND-A7-CAP-003** | A7.3 | **Inflation Rate (CPI)** | Annual % change in consumer prices. | Percentage | IMF / Central Banks (A) | Risk Curve (High/Deflation = Risk) | Monthly |
| **IND-A7-CAP-004** | A7.4 | **Sovereign Credit Rating** | Long-term foreign currency rating. | Alphanumeric (AAA-D) | S&P / Moody's / Fitch (A) | Linear Mapping to 1-5 | Ad-hoc |
| **IND-A7-CAP-005** | A7.5 | **Central Bank Transparency** | Dincer/Eichengreen index or proxy. | Score | Academic / BIS (B) | Thresholds | Annual |

*   **Relevance:** Universal.
*   **Evidence Anchor:** Chinn, M. D., & Ito, H. (2006). *What Matters for Financial Development? Capital Controls, Institutions, and Interactions*.

### Domain A8: Integrity, ESG, & Compliance Exposure
*Governance constraints.*

| ID | Dim | Name | Definition | Measurement | Source (Tier) | Transform | Update |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **IND-A8-ESG-001** | A8.1 | **Corruption Perceptions Index (CPI)** | Perceived levels of public sector corruption. | Score (0-100) | Transparency Int'l (A) | Inverted Scale | Annual |
| **IND-A8-ESG-002** | A8.2 | **Environmental Performance Index (EPI)** | State of sustainability and ecosystem vitality. | Score (0-100) | Yale / Columbia (A) | Percentile Rank | Biennial |
| **IND-A8-ESG-003** | A8.3 | **Labor Rights Index** | Legal protection of worker rights. | Score (0-100) | Penn State / various (B) | Inverted Scale | Annual |
| **IND-A8-ESG-004** | A8.1 | **Control of Corruption** | Extent to which public power is exercised for private gain. | Score (-2.5 to 2.5) | World Bank WGI (A) | Percentile Rank | Annual |
| **IND-A8-ESG-005** | A8.5 | **Social License / Protest Risk** | Likelihood of social unrest regarding development. | Index | Verisk / ACLED (B) | Thresholds | Annual |

*   **Relevance:** A8.2 Critical for Battery (chemicals); A8.3 Critical for Supply Chain diligence.
*   **Evidence Anchor:** Olken, B. A., & Pande, R. (2012). *Corruption in Developing Countries*.

---

## 3. Planned v1.1 Expansions
These indicators are deferred for v1.1 to control scope but are identified as high-value additions.

1.  **Grid Greenness Intensity:** (gCO2/kWh) - Critical for EU Battery Passport compliance.
2.  **Water Stress Projections:** (Baseline Water Stress) - WRI Aqueduct data for semiconductor fabs.
3.  **Patent Protection Index:** (IPRI) - Granular IP risk for R&D centers.
4.  **Real-time Port Congestion:** Satellite-based vessel tracking (AIS) density.
5.  **Semiconductor-Specific Export Controls:** Detailed mapping of Commerce Control List (CCL) codes to local enforcement.

# Disclaimers & Limitations

*Standard text to include in all outputs.*

## Legal Disclaimer
"This report is provided for informational purposes only and does not constitute legal, financial, or investment advice. Lattice Labs makes no representation or warranty regarding the accuracy or completeness of the data. Decisions based on this report are the sole responsibility of the user."

## Methodology Limitation
"Scores are derived from a composite of third-party indicators and qualitative assessment. They represent a model of 'structural exposure' and do not predict specific adverse events."

# Naming Screen Checklist

## Process for New Features/Products
1.  **Conflict Check:** Search USPTO TESS database.
2.  **Domain Check:** Is `.com` or `.ai` available?
3.  **Cultural Check:** Does it mean something offensive in target markets (MX, VN, IN)?
4.  **Brand Fit:** Does it sound "Latin/Scientific" (like Clarum/Lattice)?

## Brand Structure

- **Company / Umbrella Brand:** Lattice Labs
- **Product:** Clarum
- Recommended naming pattern in public-facing contexts:
  - **“Clarum, by Lattice Labs”** (premium + avoids “Clarum is the company” confusion)
  - Internally / short-form: **Lattice → Clarum**

Lattice Labs is designed to house multiple products with varying scopes. Clarum is the first flagship product in a broader suite of decision-grade tools.

## Core Thesis

Clarum is an AI-powered market-entry risk intelligence product for high-tech industries (EVs, batteries, semiconductors, industrial tech). It helps teams evaluate geopolitical, regulatory, infrastructure, and supply chain risks when expanding into new markets.

Clarum exists to replace fragmented research, consultant memos, and intuition-driven decisions with structured, explainable, evidence-backed risk intelligence.

Clarum does not predict the future.

## Target Users

Primary:
- EV manufacturers
- Battery suppliers (cells, cathode/anode, pack integrators)
- Semiconductor firms (assembly/test, packaging, component supply)
- Energy & infrastructure firms adjacent to industrial expansion
- Industrial tech startups with cross-border scaling plans
- VC / PE analysts doing diligence on expansion plans
- Corporate strategy and market-entry teams

Secondary (later):
- Logistics and freight operators supporting industrial clients
- Trade advisory teams and public-sector investment promotion agencies

## Problem Statement

Market entry decisions fail because:
- regulation is opaque or unevenly enforced
- geopolitical exposure is misunderstood until it becomes expensive
- sanctions / export control exposure is hard to model
- supply chains break at chokepoints (materials, ports, power)
- infrastructure readiness is overestimated
- industrial policy shifts faster than internal planning cycles

Current solutions are:
- slow (consulting and bespoke analysis)
- expensive (fees scale faster than internal usage)
- inconsistent (methodologies vary; evidence trails are unclear)
- fragmented (reports, news, spreadsheets, PDFs)

Clarum provides a repeatable risk model with transparent reasoning and citations.

## Value Proposition

Clarum answers:
> “Should we enter this market, and what are the risks if we do — specifically for our sector and position in the value chain?”

Clarum delivers:
- quantified risk scores by category
- clear explanations in executive language
- evidence-backed citations and traceability
- key risk flags and decision checkpoints
- exportable dossiers for stakeholders

## What Clarum Is NOT

- not investment advice
- not a prediction engine
- not a news-only feed
- not a general-purpose chatbot
- not a replacement for human judgment

Clarum is decision support.

## Positioning

Clarum is a decision-grade market-entry risk engine for industrial expansion in high-tech sectors.

It sits between:
- expensive consulting memos, and
- internal spreadsheets / ad-hoc research

It is:
- fast enough for frequent use
- structured enough for repeatability
- credible enough for executive decision-making

Tagline options (internal placeholders):
- “Clarity for market entry.”
- “Decision-grade risk intelligence.”
- “Know the exposure before you move.”

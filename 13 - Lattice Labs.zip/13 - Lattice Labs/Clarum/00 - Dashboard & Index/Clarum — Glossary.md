# Clarum — Glossary

## Core Terms
- **Domain:** Top-level risk category (A1–A8).
- **Sub-dimension:** Specific risk vector within a domain (e.g., A1.1 Policy Volatility).
- **Indicator:** A measurable proxy for a sub-dimension (e.g., "World Bank Regulatory Quality").
- **Anchor:** Peer-reviewed paper or authoritative methodology validating a construct.
- **Case:** The specific combination of Country + Sector + Role being analyzed.
- **Dossier:** The final output report for a Case.

## Confidence & Evidence
- **Tier A Source:** Peer-reviewed academic or major institutional (WB, IMF) methodology.
- **Tier B Source:** High-quality institutional report or reputable industry index.
- **Tier C Source:** News media or unverified data (context only).
- **Confidence:** A structural score (High/Med/Low) based on data completeness and evidence quality.

## Roles
- **Analyst:** Lattice Labs researcher validating model outputs.
- **User:** Customer viewing the dossier.
- **Lead:** Methodology owner approving framework changes.

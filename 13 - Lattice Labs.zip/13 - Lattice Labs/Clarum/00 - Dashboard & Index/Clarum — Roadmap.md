# Clarum — Roadmap

## Phase 1: The Foundation (Current)
*Goal: Validated methodology + Manual Dossier Generation*
- [x] Define LRF-1 Ontology ([[Lattice Risk Framework]])
- [x] Define Indicator Library v1 ([[LRF-1 — Indicator Library (v1)]])
- [ ] Source Core Data (Top 5 Countries)
- [ ] Produce "Gold Standard" Manual Dossier (Mexico - EV)
- [ ] Inter-rater Reliability Test (2 analysts, 1 case)

## Phase 2: The MVP Application
*Goal: Software-assisted scoring + Web Output*
- [ ] Data Ingestion Pipeline (MVP)
- [ ] RAG Retrieval of Tier A/B Evidence
- [ ] Scoring Engine Logic Implemented
- [ ] Web UI (Select Country/Sector -> View Dashboard)
- [ ] PDF Export Feature

## Phase 3: The Market Beta
*Goal: Paid Pilots*
- [ ] 50 Country Coverage
- [ ] "Trend" Analysis (Time-series)
- [ ] User Management / RBAC
- [ ] Enterprise API Access (Read-only)

## Backlog / Icebox
- Real-time news alerts (Noise risk high)
- Scenario Simulator (Monte Carlo)
- Supply Chain Graph Visualization

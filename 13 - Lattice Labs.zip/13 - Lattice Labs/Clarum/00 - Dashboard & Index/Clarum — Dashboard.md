# Clarum — Dashboard
> **Product:** Clarum (by Lattice Labs)
> **Mission:** Decision-grade market-entry risk intelligence.
> **Status:** MVP Build

## 📌 Key Links
- [[Clarum — Roadmap]]
- [[Lattice Risk Framework|Core Methodology (LRF-1)]]
- [[LRF-1 — Indicator Library (v1)]]
- [[Clarum — PRD]]

## 📂 Project Structure
- **01 Framework:** The "Brain" — LRF-1 methodology, domains, and indicators.
- **02 Evidence:** The "Trust" — Peer-reviewed anchors and source registers.
- **03 Product:** The "Spec" — Requirements, user stories, and output design.
- **04 Data:** The "Model" — Entities, taxonomies, and relationships.
- **05 Engineering:** The "Build" — Architecture, RAG, and security.
- **06 Validation:** The "Proof" — Backtesting and case studies.
- **07 GTM:** The "Pitch" — ICP, positioning, and sales assets.
- **08 Ops:** The "Machine" — Research workflows and QA.

## ⚡ Active Tracks
| Track | Status | Lead | Link |
| :--- | :--- | :--- | :--- |
| **Methodology** | 🟢 Stable | Research | [[Lattice Risk Framework]] |
| **Data Eng** | 🟡 Building | Eng | [[Clarum — System Architecture (MVP)]] |
| **Validation** | 🔴 Pending | QA | [[LRF-1 — Validation Plan]] |

## 🧭 Current Ops Snapshot (2026-02-09)
- **Profile-weighted completeness** added to report generator (renormalizes weights when domains are out-of-scope).
- **Mexico A5**: IND-A5-SUP-002 filled (World Bank MVA % GDP, 2024).
- **Malaysia A6**: Tier-A attempts only; remaining indicators still TODO.
- **Open decision:** IND-A3-POL-002 remains Tier-B (WEF/ITU). Decide whether to allow Tier-B fill or keep TODO.
 - **2026-02-10 update:** Sanctions/export-controls Tier-A evidence added (EV-2026-033..039); OFAC SLS is the canonical service anchor (EV-2026-039); Source Register now includes sanctions/export controls section.
 - **2026-02-10 update:** IND-A5-SUP-001 filled via WITS (HH market concentration index) for HU/MX/MY; reports regenerated.
 - **2026-02-10 update:** Evidence tiers (A/B) now supported in packs and reports; Tier B caps per-indicator confidence and adds report flags.

## 🛠 Quick Actions
- [ ] Log a new decision: [[Clarum — Decisions & Assumptions Log]]
- [ ] Add a new source: [[Source Register]]
- [ ] Draft a research brief: [[Research Workflow]]

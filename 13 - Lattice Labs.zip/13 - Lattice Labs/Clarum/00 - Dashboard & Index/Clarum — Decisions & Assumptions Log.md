# Clarum — Decisions & Assumptions Log

## Decisions
| Date | ID | Decision | Rationale | Status |
| :--- | :--- | :--- | :--- | :--- |
| 2026-02-09 | DEC-001 | Use 1-5 continuous scoring. | Allows finer gradation than High/Med/Low traffic lights; maps to maturity models. | Active |
| 2026-02-09 | DEC-002 | Exclude news feeds from MVP. | High noise, low signal for structural risk; requires complex NLP filter. | Active |

## Assumptions (to validate)
| ID | Assumption | Validation Method |
| :--- | :--- | :--- |
| ASM-001 | Users care more about "why" (evidence) than the score itself. | User interviews / Feedback on dossier. |
| ASM-002 | Tier A data is available for Vietnam & Indonesia at sufficient granularity. | Data sourcing sprint (Phase 1). |

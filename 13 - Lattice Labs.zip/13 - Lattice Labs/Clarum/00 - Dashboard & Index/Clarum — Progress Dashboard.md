# Clarum — Progress Dashboard

Snapshot date: 2026-02-10

- Sprint 5: IND-A5-SUP-001 filled via WITS (HH market concentration index); reports regenerated.
- Sprint 6: Evidence tiers (A/B) supported in schema + reports; Tier B caps per-indicator confidence and flags reports.
- Sprint 6: Tier B pipeline exercised (Mexico IND-A5-SUP-002 marked evidence_tier=B; report now flags Tier B and caps confidence).
- Sprint 7: Tier B is allowlist-enforced via TIERB_ALLOWLIST.v1.json (indicator-specific tokens/domains); IND-A3-POL-002 Tier B allowed only from WEF/ITU.
- Sprint 8: Scope check shows IND-A3-POL-002 is not in-scope for export profiles (WP-EV-OEM-EXPORT-1.1, WP-SEMI-OSAT-EXPORT-1.1); fill deferred.
- Sprint 9: Domestic baseline reports generated (WP-EV-OEM-DOM-1.1); A3 Tier B fill blocked pending ITU/WEF values.
- Sprint 9: IND-A3-POL-002 filled for domestic track using ITU IDI 2023 overall score (Tier B; allowlist enforced). Values: HUN 86.8, MEX 78.0, MYS 94.5. Source: https://www.itu.int/en/ITU-D/Statistics/Documents/IDI/IDI2023Dataset.xlsx
- Sprint 10: site_export includes Domestic track reports + unified report index manifest (track, flags, evidence_tier_summary).
- Sprint 10 runlog: [04 - Data & Ontology/Ontology/_machine/runlogs/flagship_sprint10_site_export_domestic_parity_2026-02-10_2347.txt](04%20-%20Data%20%26%20Ontology/Ontology/_machine/runlogs/flagship_sprint10_site_export_domestic_parity_2026-02-10_2347.txt)

| Country | Raw completeness % | Profile-weighted % | Fatal missingness | Domain breakdown (A1-A8) | Weight profile | Last runlog |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| Hungary | 49.17 | 100.0 | false | A1 100, A2 100, A3 0, A4 100, A5 100, A6 100, A7 0, A8 0 | WP-EV-OEM-EXPORT-1.1 | flagship_sprint5_hungary_regen_2026-02-10_2214.txt |
| Mexico | 36.67 | 100.0 | false | A1 100, A2 100, A3 0, A4 100, A5 100, A6 100, A7 0, A8 0 | WP-EV-OEM-EXPORT-1.1 | flagship_sprint5_mexico_regen_2026-02-10_2214.txt |
| Malaysia | 36.67 | 100.0 | false | A1 100, A2 100, A3 0, A4 100, A5 100, A6 100, A7 0, A8 0 | WP-SEMI-OSAT-EXPORT-1.1 | flagship_sprint5_malaysia_regen_2026-02-10_2214.txt |

## Profile-scope closeout (A2/A4) — Before/After (pack-based)
Note: "After" values reflect regenerated reports (2026-02-09 23:07).

| Country | A2 completeness (before -> after) | A4 completeness (before -> after) | Profile-weighted % (before -> after) | Remaining TODOs |
| :--- | :--- | :--- | :--- | :--- |
| Hungary | 60 -> 80 | 50 -> 100 | 55.0 -> 90.0 | IND-A2-GEO-005 |
| Mexico | 60 -> 80 | 50 -> 100 | 55.0 -> 90.0 | IND-A2-GEO-005 |
| Malaysia | 60 -> 80 | 50 -> 100 | 55.0 -> 90.0 | IND-A2-GEO-005 |

## Flagship Sprint 2 (2026-02-10)
Strict validation OK; reports regenerated at 2026-02-10 17:40.
Update: reports regenerated again at 2026-02-10 17:52 after blocked URL note updates.

| Country | Overall % | Profile-weighted % | IND-A2-GEO-004 | IND-A2-GEO-005 | IND-A4-INF-003 | IND-A4-INF-004 | IND-A4-INF-006 | Last runlog |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| Hungary | 35.0 | 90.0 | Filled | Blocked | Filled (CV) | Filled | Filled | flagship_sprint2_hungary_regen_2026-02-10_1731.txt |
| Mexico | 25.0 | 90.0 | Filled | Blocked | Filled (CV) | Filled | Filled | flagship_sprint2_mexico_regen_2026-02-10_1731.txt |
| Malaysia | 25.0 | 90.0 | Filled | Blocked | Filled (CV) | Filled | Filled | flagship_sprint2_malaysia_regen_2026-02-10_1731.txt |

## Flagship Sprint 4 (2026-02-10)
Strict validation OK; reports regenerated at 2026-02-10 19:07.

| Country | Overall % | Profile-weighted % | IND-A1-REG-001/002 | IND-A5-SUP-002 | IND-A6-LAB-001 | Last runlog |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| Hungary | 46.67 | 80.0 | Filled | Filled | Filled | flagship_sprint4_hungary_regen_2026-02-10_1907.txt |
| Mexico | 34.17 | 80.0 | Filled | Filled | Filled | flagship_sprint4_mexico_regen_2026-02-10_1907.txt |
| Malaysia | 34.17 | 86.67 | Filled | Filled | Filled | flagship_sprint4_malaysia_regen_2026-02-10_1907.txt |

## Flagship Sprint 5 (2026-02-10)
WITS HH market concentration index filled for IND-A5-SUP-001; strict validation clean; reports regenerated; token override patch applied.

## Evidence tiers (A/B)
- Schema + policy: 04 - Data & Ontology/Ontology/_machine/country_pack.schema.v1.json, 04 - Data & Ontology/Ontology/_machine/EVIDENCE_TIER_POLICY.v1.md.
- Usage: set evidence_tier: "B" on an indicator; omit for Tier A.
- Effect: Tier B caps per-indicator confidence and adds a report flag.

## Dossier tracks
- Export track: WP-EV-OEM-EXPORT-1.1 (HU/MX), WP-SEMI-OSAT-EXPORT-1.1 (MY).
- Domestic track: WP-EV-OEM-DOM-1.1 (HU/MX/MY).
- Domestic reports (baseline):
	- [04 - Data & Ontology/Ontology/_machine/reports/hungary.ev_oem_domestic.wp-ev-oem-dom-1.1.balanced.report.v1.json](04%20-%20Data%20%26%20Ontology/Ontology/_machine/reports/hungary.ev_oem_domestic.wp-ev-oem-dom-1.1.balanced.report.v1.json)
	- [04 - Data & Ontology/Ontology/_machine/reports/mexico.ev_oem_domestic.wp-ev-oem-dom-1.1.balanced.report.v1.json](04%20-%20Data%20%26%20Ontology/Ontology/_machine/reports/mexico.ev_oem_domestic.wp-ev-oem-dom-1.1.balanced.report.v1.json)
	- [04 - Data & Ontology/Ontology/_machine/reports/malaysia.ev_oem_domestic.wp-ev-oem-dom-1.1.balanced.report.v1.json](04%20-%20Data%20%26%20Ontology/Ontology/_machine/reports/malaysia.ev_oem_domestic.wp-ev-oem-dom-1.1.balanced.report.v1.json)
- A3 indicators (e.g., IND-A3-POL-002) belong to the Domestic track (Tier B, allowlist-enforced).
- Unified report index: [09 - Publishing/site_export/v1/index/index.reports.v1.json](09%20-%20Publishing/site_export/v1/index/index.reports.v1.json)

## Website Gate Pack v1 (Option A) — Exported 2026-02-10
- Bundle: 09 - Publishing/site_export/v1/
- Manifest: 09 - Publishing/site_export/v1/meta/publish_manifest.v1.json
- Payloads: 09 - Publishing/site_export/v1/index/*.payload.v1.json
- Reports: 09 - Publishing/site_export/v1/reports/*.report.v1.json
- Dossiers: 09 - Publishing/site_export/v1/dossiers/*.dossier.md
- Evidence: 09 - Publishing/site_export/v1/evidence/evidence_index.v1.json

## Evidence Pack Notes (2026-02-10)
- Sanctions/export-controls Tier-A evidence added: EV-2026-033..039.
- OFAC Sanctions List Service (SLS) is the canonical service anchor (EV-2026-039).
- Source Register updated with a sanctions/export controls section.

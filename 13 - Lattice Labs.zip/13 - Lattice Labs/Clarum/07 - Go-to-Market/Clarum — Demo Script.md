# Clarum — Demo Script (MVP)

## Intro (2 mins)
- "You're looking to expand capacity. You have 3 countries on your short list. How do you objectively compare the risk of delays in Mexico vs. Vietnam?"
- "Usually, that's 3 weeks of Googling. Let's do it in 3 minutes."

## The Reveal (3 mins)
- *Show Dashboard.* "Here is the Clarum view for Mexico - EV Assembly."
- *Click Domain A4 (Infrastructure).* "Most reports say Mexico is 'Good'. Clarum flags 'High Risk' in Energy Reliability."
- *Show Evidence.* "Why? Because industrial tariff volatility is up 200% (Source: IEA) and grid reserve margins are critical (Source: CENACE)."

## The Close (2 mins)
- "This isn't a black box. It's a dossier you can take to your Investment Committee today."
- "Shall we run a profile for your top target market?"

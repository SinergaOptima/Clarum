# Clarum — ICP & Positioning

## Ideal Customer Profile (ICP)
### The "Expansion Architect"
- **Title:** VP Strategy / Head of Corp Dev / Director of Supply Chain
- **Company:** Series C+ Hard Tech (EV, Battery, Aerospace) or Legacy OEM
- **Pain:** "I have to present a recommendation to the Board in 2 weeks, and I only have generic consultant slides."
- **Gain:** "I look like the smartest person in the room because I have data no one else has."

## Value Proposition
- **For the Board:** Defensibility. (Why did we choose X? Here is the data.)
- **For the Team:** Speed. (Months of research compressed into minutes.)
- **For the CFO:** Risk avoidance. (Avoiding a $100M mistake.)

## Positioning Statement
**For** corporate strategy teams in high-tech manufacturing,  
**Clarum is** a market-entry risk intelligence platform  
**That** quantifies and explains operational exposure  
**Unlike** generalist consultancies or news feeds,  
**Clarum** provides decision-grade, evidence-backed rigor specifically for industrial supply chains.

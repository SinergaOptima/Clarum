# Clarum — Competitive Landscape

## 1. The Big 3 Consultancies (McK, Bain, BCG)
- **Pros:** High trust, bespoke.
- **Cons:** Very expensive ($500k+), slow (months), static.
- **Clarum Angle:** "80% of the value for 5% of the cost, instantly."

## 2. Political Risk Firms (Eurasia Group, Control Risks)
- **Pros:** Deep expert networks.
- **Cons:** Focus on "Coups and Elections" rather than "Can I get power to my factory?"
- **Clarum Angle:** "Operational reality, not just political theory."

## 3. Data Aggregators (BMI, EIU)
- **Pros:** Lots of data.
- **Cons:** Generic, not sector-specific. "Business Environment" score doesn't tell you if you can build a battery plant.
- **Clarum Angle:** "Built specifically for the EV/Semi value chain."

# Clarum — Outreach Templates

## Cold Email 1: The "Board Prep" Angle
**Subject:** Data for your Mexico expansion strategy

Hi [Name],

Saw you're leading the expansion efforts at [Company].

Most teams struggle to quantify the "operational friction" risks (permitting, grid, logistics) until it's too late.

We built a risk model specifically for the EV supply chain. I'd love to send you a sample dossier on Mexico's current industrial bottlenecks to see if it matches your internal view.

Open to a 10-min walkthough?

Best,
[Melek]
Lattice Labs

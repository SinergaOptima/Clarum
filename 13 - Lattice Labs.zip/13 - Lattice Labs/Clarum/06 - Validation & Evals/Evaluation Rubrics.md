# Evaluation Rubrics (Output Quality)

## 1. The "So What?" Test
- **Fail:** "Corruption is high in Mexico." (Generic)
- **Pass:** "Corruption in customs at Manzanillo port adds ~4 days to import timelines." (Specific & Actionable)

## 2. The Evidence Link
- **Fail:** Claim made without citation.
- **Pass:** Every claim > 3.0 severity has a Tier A/B citation linked.

## 3. The Tone Check
- **Fail:** Alarmist language ("Catastrophic collapse imminent").
- **Pass:** Clinical language ("High probability of severe disruption").

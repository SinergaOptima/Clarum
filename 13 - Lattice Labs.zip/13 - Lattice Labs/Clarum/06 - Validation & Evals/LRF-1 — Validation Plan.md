# LRF-1 — Validation Plan

> **Goal:** Prove the model reflects reality.

## 1. Inter-Rater Reliability (IRR)
- **Method:** Give the same Evidence Pack to 3 independent analysts.
- **Metric:** % Agreement on Domain Scores (within +/- 0.5 points).
- **Target:** > 80% Agreement.

## 2. Historical Backtesting
- **Method:** Run the model using *2020 data* for a known failure case (e.g., Russia 2021, or specific supply chain shock).
- **Question:** Did the model flag "A2 Geopolitics" or "A5 Supply Chain" as High Risk *before* the event?
- **Target:** Qualitative confirmation of signal.

## 3. Expert Review Panel
- **Method:** Show the "Mexico EV" dossier to a veteran logistics manager in Mexico.
- **Question:** "Does this match your on-the-ground experience?"
- **Target:** No "red flag" disagreements on facts.

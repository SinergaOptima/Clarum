# Case Study Template (Validation)

## Meta
- **Case:** [Country] - [Sector]
- **Date:**
- **Analyst:**

## Hypothesis
*What did general wisdom say about this market before we modeled it?*

## Model Findings
*What did Clarum find?*
- **Surprises:** (e.g., "Infrastructure was worse than expected.")
- **Confirmations:**

## Expert Feedback
*What did the local expert say?*
- **Accuracy:** X/5
- **Blind spots:** (What did we miss?)

## Result
- [ ] Validated
- [ ] Needs Calibration

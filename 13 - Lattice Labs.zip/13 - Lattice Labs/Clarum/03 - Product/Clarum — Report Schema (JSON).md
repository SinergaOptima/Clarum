# Clarum — Report Schema (JSON)

```json
{
  "meta": {
    "report_id": "RPT-2026-MX-EV-001",
    "generated_at": "2026-02-09T12:00:00Z",
    "version": "LRF-1.0",
    "analyst": "system"
  },
  "context": {
    "country_iso": "MEX",
    "sector_id": "SEC-EV-OEM",
    "role_id": "ROLE-ASSEMBLY"
  },
  "overall": {
    "score": 3.4,
    "confidence": "Medium",
    "summary_markdown": "Mexico offers high proximity value but faces severe A4 (Energy) and A8 (Security) constraints..."
  },
  "domains": [
    {
      "id": "A1",
      "name": "Regulatory Stability",
      "score": 2.8,
      "confidence": "High",
      "rationale": "...",
      "indicators": [
        {
          "id": "IND-A1-REG-001",
          "name": "Regulatory Quality",
          "value_raw": 65.4,
          "value_normalized": 3.1,
          "source": "World Bank WGI 2024"
        }
      ],
      "evidence": [
        {
          "claim": "Permitting delays have increased by 20% since 2023.",
          "tier": "B",
          "citation": "Industry Report X"
        }
      ]
    }
  ]
}
```

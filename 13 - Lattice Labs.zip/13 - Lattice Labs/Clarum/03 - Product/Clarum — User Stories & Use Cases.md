# Clarum — User Stories & Use Cases

## Personas
- **P1: The Strategist.** VP Strategy at an EV OEM. Needs board-ready slides and "gotcha" checks.
- **P2: The Analyst.** Senior Associate at a specialized VC. Needs raw data and methodology defense.
- **P3: The Operator.** Supply Chain Director. Needs infrastructure realities (ports, power).

## Use Cases
### UC-1: The "Longlist" Filter
*As a Strategist, I want to compare Mexico, Vietnam, and India side-by-side so I can eliminate one option immediately.*
- **Requirement:** Comparative view of top-level scores.

### UC-2: The Deep Dive Due Diligence
*As an Operator, I want to know specifically if the grid in Northern Mexico can handle a 500MW factory.*
- **Requirement:** Domain A4 (Infrastructure) deep dive with specific indicators (Grid Reliability, Energy Cost).

### UC-3: The Board Defense
*As a Strategist, I need to prove why we are choosing a "High Risk" country.*
- **Requirement:** Evidence ledger showing "Mitigated" risks vs "Structural" risks.

## User Stories
1.  **US-01:** "As a user, I can see the exact source for the 'Political Instability' score so I can trust it."
2.  **US-02:** "As a user, I can download a PDF that looks professional enough to email to my CEO."
3.  **US-03:** "As a user, I can see when the data was last updated."

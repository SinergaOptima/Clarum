# Clarum — Pricing & Packaging

## Strategy
- **Beta (Phase 1):** High-touch, manual/hybrid delivery. Price for value, not users.
- **SaaS (Phase 2):** Seat-based + Report credits.

## Tiers

### 1. Pilot / Beta (Consulting-lite)
- **Price:** $15k - $25k per engagement.
- **Includes:**
  - 3 Custom Dossiers (Deep dives).
  - 1 Hour Analyst Debrief.
  - Access to raw data tables.
- **Goal:** Validate model, get case studies.

### 2. Platform Standard (SaaS)
- **Price:** $2k / month / seat (Billed Annually).
- **Includes:**
  - Unlimited "Standard" Dossiers (Auto-generated).
  - 5 "Premium" Dossiers (Analyst verified).
  - Monitoring updates (quarterly).

### 3. Enterprise
- **Price:** Custom.
- **Includes:** API Access, Custom Weight Profiles, White-labeling.

## Discounts
- **Academic/NGO:** Free (Brand building).
- **Early Adopter:** 50% off year 1 for feedback partners.

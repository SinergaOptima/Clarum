# Clarum — PRD (Product Requirements Document)

> **Version:** 1.0 (MVP)  
> **Status:** Approved  
> **Scope:** Market Entry Risk Intelligence (Static Dossiers)

## 1. Problem
Market entry teams in high-tech (EV/Semis) rely on fragmented data and "vibes-based" consulting, leading to costly surprises in regulation, infrastructure, and supply chain.

## 2. Solution
**Clarum** is a decision-grade risk engine that ingests authoritative data, applies the LRF-1 methodology, and outputs structured, cited risk dossiers.

## 3. Core Features (MVP)
1.  **Country/Sector Selection:** Users select from pre-defined list (e.g., Mexico x EV OEM).
2.  **Risk Scoring:** 1-5 score across 8 domains (A1-A8).
3.  **Evidence Traceability:** Click-to-source for every key claim.
4.  **Executive Summary:** AI-synthesized (but grounded) narrative of top 3 risks.
5.  **Export:** High-fidelity PDF dossier.

## 4. Non-Goals (v1)
- Real-time news monitoring.
- Interactive scenario simulation.
- User collaboration / comments.
- API access.

## 5. Success Metrics
- **Time-to-Insight:** < 5 mins to read and understand top risks (vs. weeks of research).
- **Trust Score:** 80% of users rate "Evidence" as "High Quality".
- **Conversion:** 5 beta pilots signed.

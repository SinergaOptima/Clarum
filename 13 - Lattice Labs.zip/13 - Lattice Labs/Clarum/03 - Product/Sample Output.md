Clarum, by Lattice Labs

## Market Entry Risk Dossier
### Mexico — EV Battery Assembly

---

## Executive Summary

Mexico offers strong industrial alignment with EV-related manufacturing and proximity to North American demand, but medium-term exposure to trade policy shifts and infrastructure constraints creates material operational risk for battery assembly.

Overall Risk Score: 2.9 / 5 (Moderate)

Confidence: Medium

---

## Category Breakdown

Regulatory Stability: 2.5
Mexico’s industrial regulations are generally navigable for foreign manufacturers, though permitting and enforcement can vary by state and agency timelines.

Geopolitical Exposure: 3.5
Deep integration with US supply chains creates elevated exposure to North American trade policy changes and broader geopolitical spillovers affecting industrial inputs.

Industrial Policy Alignment: 2.0
Policy direction broadly supports manufacturing investment in EV-adjacent sectors, with incentives and clustering effects in established industrial regions.

Infrastructure Readiness: 3.0
Power and grid capacity constraints in high-growth areas can bottleneck scale-up, and logistics performance is uneven depending on corridor.

Supply Chain Fragility: 2.8
Automotive cluster maturity reduces risk, but upstream battery materials and specialized components may remain import-dependent.

Labor & Talent Pool: 2.3
Manufacturing labor availability is strong and improving; specialized battery expertise may require targeted training or cross-border hiring early on.

Capital & Currency Risk: 2.7
Currency volatility is manageable but remains sensitive to global conditions and US monetary cycles; financing is available but pricing varies.

ESG & Compliance Risk: 3.1
Environmental and compliance enforcement can be inconsistent; due diligence and local compliance capacity reduce downside.

---

## Key Risk Flags

- Grid capacity and reliability constraints in key industrial corridors
- Trade policy volatility affecting cross-border inputs/outputs
- State-level permitting variability and timeline uncertainty
- Import dependency for specialized materials/components

---

## Suggested Decision Checkpoints

- Validate power availability and upgrade timelines at shortlisted sites
- Map exposure to tariff and export-control scenarios for key inputs
- Confirm permitting path and state-level enforcement patterns
- Identify domestic supplier candidates and redundancies for critical parts

---

## Outlook (3–5 Years)

Mexico’s EV-adjacent industrial footprint is likely to strengthen, but operational risk depends on whether infrastructure upgrades keep pace with industrial demand and whether trade policy remains stable.

Risk trend: Stable → Slightly improving (conditional)


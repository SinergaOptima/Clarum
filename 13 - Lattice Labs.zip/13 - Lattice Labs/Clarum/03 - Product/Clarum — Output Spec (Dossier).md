# Clarum — Output Spec (Dossier)

## Format
- **Digital:** Web Dashboard (React/Next.js)
- **Print:** PDF (A4, Portrait)

## Structure
### 1. Cover Page
- Title: "Market Entry Risk Assessment: [Country] - [Sector]"
- Date / Version
- "Clarum by Lattice Labs" branding

### 2. Executive Summary (1 Page)
- **Overall Risk Score:** (Big number, 1.0-5.0)
- **The Narrative:** 2 paragraphs summarizing the "Story of the Risk".
- **Top 3 Critical Threats:** Bullet points.
- **Top 3 Strategic Advantages:** Bullet points.

### 3. Risk Radar
- Spider chart of A1-A8 scores.

### 4. Domain Deep Dives (8 Sections)
*For each domain:*
- Score + Trend Arrow.
- "Why this score?" (Rationale).
- Key Indicators Table (Selected 3-5).
- Evidence Ledger (Bullets with citations).

### 5. Appendix
- Full Indicator List.
- Methodology Note (Brief LRF-1 summary).
- Disclaimers.

## Tone Voice
- **Objective:** "Data suggests..." not "We feel..."
- **Direct:** "High risk of delay" not "Potential challenges may arise."
- **Premium:** Concise, no fluff.

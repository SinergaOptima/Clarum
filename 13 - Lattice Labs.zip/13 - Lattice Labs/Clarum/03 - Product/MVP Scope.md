# Clarum (Lattice Labs)

## Objective

Ship a credible, decision-grade market-entry risk dossier generator for country × sector in high-tech industries.

The MVP proves:
- the scoring model is useful
- the explanations are clear
- the evidence trail creates trust
- users would pay to avoid uncertainty

## MVP Includes (v1)

Core:
- country × sector selection
- structured risk scoring across 8 categories
- executive summary + category breakdown
- key risk flags
- 3–5 year “risk trend” outlook statement (non-predictive, exposure-based)
- dossier-style report output (screen + export)

Deliverables:
- web UI (simple)
- PDF export (boardroom-ready)
- stored report history (basic)

## Initial Coverage

Countries (starter set):
- Mexico
- Vietnam
- Indonesia
- India
- Poland

Industries (starter set):
- EV manufacturing (vehicles)
- Battery production (cells/packs)
- Semiconductor assembly/test/packaging

## MVP Excludes (explicitly)

To prevent scope creep, v1 excludes:
- real-time news ingestion and streaming updates
- “agentic” autonomous research systems
- alerts and monitoring
- scenario simulation (future v2)
- API access (future v2)
- team collaboration, roles, and permissions (future v2)
- 200-country coverage
- prediction claims

## Success Criteria (v1)

The MVP succeeds if:
- users say the output is “credible enough to use internally”
- users can quickly identify top risks and mitigation questions
- users export dossiers for discussions
- at least a few users pay for access (even at beta pricing)

## Brand Note

Clarum is the first flagship product by Lattice Labs.
The MVP should visually and verbally support:
- “Clarum, by Lattice Labs”
- a consistent, premium product suite identity (future-proofing)

import json
import re
import shutil
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List

ROOT = Path(__file__).resolve().parents[2]
EXPORT_ROOT = ROOT / "09 - Publishing" / "site_export" / "v1"

REPORTS_DIR = EXPORT_ROOT / "reports"
DOSSIERS_DIR = EXPORT_ROOT / "dossiers"
EVIDENCE_DIR = EXPORT_ROOT / "evidence"
MEMOS_DIR = EXPORT_ROOT / "memos"
MEMOS_RENDERED_DIR = MEMOS_DIR / "rendered"
INDEX_DIR = EXPORT_ROOT / "index"
META_DIR = EXPORT_ROOT / "meta"
SCHEMAS_DIR = EXPORT_ROOT / "schemas"

INDICATOR_CATALOG_PATH = ROOT / "04 - Data & Ontology" / "Ontology" / "_machine" / "indicator_catalog.v1.json"

EVIDENCE_SRC_DIR = ROOT / "02 - Evidence Library"

CASES = [
    {
        "case_id": "GD-HUN-EV-OEM-EXPORT-001",
        "slug": "gd-hun-ev-oem-export-001",
        "report_path": ROOT / "04 - Data & Ontology" / "Ontology" / "_machine" / "reports" / "hungary.ev_oem_export.wp-ev-oem-export-1.1.balanced.report.v1.json",
        "dossier_path": ROOT / "06 - Validation & Evals" / "Gold Dossiers" / "Gold Dossier \u2014 Hungary \u2014 China EV OEM Export Hub (LRF-1).md",
    },
    {
        "case_id": "PD-MEX-EV-OEM-EXPORT-001",
        "slug": "pd-mex-ev-oem-export-001",
        "report_path": ROOT / "04 - Data & Ontology" / "Ontology" / "_machine" / "reports" / "mexico.ev_oem_export.wp-ev-oem-export-1.1.balanced.report.v1.json",
        "dossier_path": ROOT / "06 - Validation & Evals" / "Gold Dossiers" / "Pilot Dossier \u2014 Mexico \u2014 EV OEM Export Hub (USMCA) (LRF-1).md",
    },
    {
        "case_id": "PD-MYS-SEMI-OSAT-EXPORT-001",
        "slug": "pd-mys-semi-osat-export-001",
        "report_path": ROOT / "04 - Data & Ontology" / "Ontology" / "_machine" / "reports" / "malaysia.semi_osat_export.wp-semi-osat-export-1.1.balanced.report.v1.json",
        "dossier_path": ROOT / "06 - Validation & Evals" / "Gold Dossiers" / "Pilot Dossier \u2014 Malaysia \u2014 Semiconductor OSAT Export Hub (LRF-1).md",
    },
]

EV_ID_RE = re.compile(r"EV-\d{4}-\d{3}")

DOMESTIC_REPORT_PATTERNS = [
    ".ev_oem_domestic.",
    ".semi_osat_domestic.",
    ".wp-ev-oem-dom-",
    "-ev-oem-dom-",
    "-ev-oem-domestic-",
    "-semi-osat-dom-",
    "-semi-osat-domestic-",
]
EXPORT_REPORT_PATTERNS = [
    ".ev_oem_export.",
    ".semi_osat_export.",
    ".wp-ev-oem-export-",
    ".wp-semi-osat-export-",
    "-ev-oem-export-",
    "-semi-osat-export-",
]


def infer_track_from_report_filename(filename: str) -> str:
    lower_name = filename.lower()
    if any(pattern in lower_name for pattern in DOMESTIC_REPORT_PATTERNS):
        return "domestic"
    if any(pattern in lower_name for pattern in EXPORT_REPORT_PATTERNS):
        return "export"
    return "unknown"


def load_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def dump_json(path: Path, payload: Any) -> None:
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2, sort_keys=True)
        handle.write("\n")


def load_indicator_catalog() -> Dict[str, Dict[str, Any]]:
    catalog = load_json(INDICATOR_CATALOG_PATH)
    return {entry["id"]: entry for entry in catalog}


def extract_title(dossier_text: str) -> str:
    for line in dossier_text.splitlines():
        if line.startswith("# "):
            return line[2:].strip()
    return ""


def extract_evidence_ids(dossier_text: str) -> List[str]:
    return sorted(set(EV_ID_RE.findall(dossier_text)))


def parse_urls(url_field: Any) -> List[str]:
    if not isinstance(url_field, str):
        return []
    if url_field.strip() in {"", "TODO(URL)"}:
        return []
    parts = [part.strip() for part in url_field.split("|")]
    return [part for part in parts if part]


def indicator_domain(indicator_id: str) -> str:
    parts = indicator_id.split("-")
    return parts[1] if len(parts) > 1 else ""


def build_indicator_payload(
    indicator_id: str,
    indicator_data: Dict[str, Any],
    catalog_entry: Dict[str, Any] | None,
) -> Dict[str, Any]:
    value = indicator_data.get("value")
    url_field = indicator_data.get("url")
    retrieved_date = indicator_data.get("retrieved_date")

    missing_value = value in ("VALUE(TODO)", None)
    missing_url = url_field in ("TODO(URL)", None, "")
    missing_date = retrieved_date in ("DATE(TODO)", None, "")

    return {
        "id": indicator_id,
        "domain": indicator_domain(indicator_id),
        "label": catalog_entry.get("name") if catalog_entry else None,
        "value": value,
        "unit": indicator_data.get("unit"),
        "year": None,
        "source_institution": indicator_data.get("source_institution"),
        "urls": parse_urls(url_field),
        "notes": indicator_data.get("notes", ""),
        "missing_value": missing_value,
        "missing_url": missing_url,
        "missing_date": missing_date,
        "is_complete_strict": not (missing_value or missing_url or missing_date),
    }


def ensure_frontmatter(dossier_text: str, case_id: str, slug: str, generated_at: str) -> str:
    if dossier_text.lstrip().startswith("---"):
        return dossier_text
    frontmatter = (
        "---\n"
        f"case_id: {case_id}\n"
        f"slug: {slug}\n"
        "publish_version: v1\n"
        f"generated_at: {generated_at}\n"
        "---\n\n"
    )
    return frontmatter + dossier_text


def parse_evidence_metadata(evidence_text: str, evidence_id: str) -> Dict[str, Any]:
    def find_field(label: str) -> str | None:
        prefix = f"- **{label}:**"
        for line in evidence_text.splitlines():
            if line.strip().startswith(prefix):
                return line.split(prefix, 1)[1].strip()
        return None

    title = find_field("Title")
    tier = find_field("Tier")
    source_type = find_field("Type")
    year = find_field("Year")
    url_field = find_field("URL/DOI")
    urls = []
    if url_field:
        urls = [part.strip() for part in url_field.split("|") if part.strip()]

    return {
        "id": evidence_id,
        "title": title,
        "tier": tier,
        "source_type": source_type,
        "urls": urls,
        "publication_date": year,
        "added_at": None,
    }


def main() -> None:
    generated_at = datetime.now().isoformat(timespec="seconds")
    indicator_catalog = load_indicator_catalog()

    MEMOS_DIR.mkdir(parents=True, exist_ok=True)
    MEMOS_RENDERED_DIR.mkdir(parents=True, exist_ok=True)

    evidence_ids_all: List[str] = []
    manifest_entries = []
    export_report_name_map = {}
    memo_source_map = {}

    for case in CASES:
        report = load_json(case["report_path"])
        dossier_text = case["dossier_path"].read_text(encoding="utf-8")

        title = extract_title(dossier_text)
        evidence_ids = extract_evidence_ids(dossier_text)
        evidence_ids_all.extend(evidence_ids)

        weight_profile = report["meta"]["methodology"]["weight_profile_id"]
        in_scope = sorted(
            [
                ind_id
                for ind_id, ind_data in report.get("indicators", {}).items()
                if ind_data.get("value") not in ("VALUE(TODO)", None)
            ]
        )

        report_public_name = f"{case['slug']}.report.v1.json"
        dossier_public_name = f"{case['slug']}.dossier.md"
        export_report_name_map[case["report_path"].name] = report_public_name
        memo_source_map[report_public_name] = (
            ROOT
            / "04 - Data & Ontology"
            / "Ontology"
            / "_machine"
            / "memos"
            / f"{case['report_path'].name.rsplit('.report.v1.json', 1)[0]}.memo.v1.json"
        )

        manifest_entries.append(
            {
                "case_id": case["case_id"],
                "slug": case["slug"],
                "title": title,
                "country": report["meta"]["case"]["country"],
                "sector": report["meta"]["case"]["sector"],
                "weight_profile": weight_profile,
                "overlay": report["meta"]["methodology"]["overlay_id"],
                "report_filename_original": case["report_path"].name,
                "report_filename_public": report_public_name,
                "dossier_filename_original": case["dossier_path"].name,
                "dossier_filename_public": dossier_public_name,
                "evidence_ids_used": evidence_ids,
                "indicator_ids_in_scope": in_scope,
                "completeness": {
                    "overall_pct": report["completeness"].get("overall_pct"),
                    "profile_weighted_pct": report["completeness"].get("profile_weighted_pct"),
                    "by_domain": report["completeness"].get("by_domain"),
                },
                "scoring_status": report.get("scores", {}).get("composite", {}).get("reason")
                or "v1 scoring gated",
                "confidence_caps": {
                    "overall": report.get("confidence", {}).get("overall_cap"),
                    "by_domain": report.get("confidence", {}).get("by_domain_cap"),
                },
            }
        )

        report_public_path = REPORTS_DIR / report_public_name
        report_public_path.write_text(
            json.dumps(report, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )

        indicators_payload = []
        for indicator_id, indicator_data in report.get("indicators", {}).items():
            catalog_entry = indicator_catalog.get(indicator_id)
            indicators_payload.append(
                build_indicator_payload(indicator_id, indicator_data, catalog_entry)
            )
        indicators_payload.sort(key=lambda item: item["id"])

        payload = {
            "meta": {
                "case_id": case["case_id"],
                "slug": case["slug"],
                "title": title,
                "country": report["meta"]["case"]["country"],
                "sector": report["meta"]["case"]["sector"],
                "weight_profile": weight_profile,
                "overlay": report["meta"]["methodology"]["overlay_id"],
            },
            "completeness": report.get("completeness"),
            "confidence": report.get("confidence"),
            "scores": report.get("scores"),
            "flags": report.get("flags"),
            "warnings": report.get("warnings"),
            "next_actions": report.get("next_actions"),
            "indicators": indicators_payload,
            "evidence_refs": evidence_ids,
        }
        dump_json(INDEX_DIR / f"{case['slug']}.payload.v1.json", payload)

        dossier_with_frontmatter = ensure_frontmatter(
            dossier_text, case["case_id"], case["slug"], generated_at
        )
        (DOSSIERS_DIR / dossier_public_name).write_text(
            dossier_with_frontmatter, encoding="utf-8"
        )

    reports_src_dir = ROOT / "04 - Data & Ontology" / "Ontology" / "_machine" / "reports"
    domestic_reports = sorted(
        path
        for path in reports_src_dir.glob("*.report.v1.json")
        if infer_track_from_report_filename(path.name) == "domestic"
    )
    for report_path in domestic_reports:
        target_path = REPORTS_DIR / report_path.name
        shutil.copy2(report_path, target_path)
        memo_source_map[report_path.name] = (
            ROOT
            / "04 - Data & Ontology"
            / "Ontology"
            / "_machine"
            / "memos"
            / f"{report_path.name.rsplit('.report.v1.json', 1)[0]}.memo.v1.json"
        )

    index_reports = []
    for report_path in sorted(REPORTS_DIR.glob("*.report.v1.json")):
        report = load_json(report_path)
        report_meta = report.get("meta", {})
        case_meta = report_meta.get("case", {})
        methodology_meta = report_meta.get("methodology", {})
        filename = report_path.name
        track = infer_track_from_report_filename(filename)
        slug = filename.rsplit(".report.v1.json", 1)[0]
        memo_json_name = f"{slug}.memo.v1.json"
        memo_md_name = f"{slug}.memo.v1.md"

        memo_source = memo_source_map.get(filename)
        if memo_source and memo_source.exists():
            memo_dest = MEMOS_DIR / memo_json_name
            shutil.copy2(memo_source, memo_dest)
            rendered_source = (
                memo_source.parent / "rendered" / f"{memo_source.stem}.md"
            )
            if rendered_source.exists():
                rendered_dest = MEMOS_RENDERED_DIR / memo_md_name
                shutil.copy2(rendered_source, rendered_dest)
        index_reports.append(
            {
                "id": slug,
                "track": track,
                "country": case_meta.get("country"),
                "dossier_slug": slug,
                "profile_id": methodology_meta.get("weight_profile_id"),
                "path": f"reports/{filename}",
                "memo_json_path": f"memos/{memo_json_name}",
                "memo_md_path": f"memos/rendered/{memo_md_name}",
                "flags": report.get("flags", {}).get("triggered"),
                "evidence_tier_summary": report_meta.get("evidence_tier_summary"),
            }
        )

    dump_json(INDEX_DIR / "index.reports.v1.json", {"reports": index_reports})

    publish_manifest = {
        "version": "v1",
        "generated_at": generated_at,
        "publish_mode": "option_a",
        "dossiers": sorted(manifest_entries, key=lambda item: item["slug"]),
    }
    dump_json(META_DIR / "publish_manifest.v1.json", publish_manifest)

    evidence_ids_all = sorted(set(evidence_ids_all))
    evidence_index = []

    for evidence_id in evidence_ids_all:
        evidence_src = EVIDENCE_SRC_DIR / f"{evidence_id}.md"
        evidence_text = evidence_src.read_text(encoding="utf-8")
        evidence_dest = EVIDENCE_DIR / f"{evidence_id}.md"
        evidence_dest.write_text(evidence_text, encoding="utf-8")
        evidence_index.append(parse_evidence_metadata(evidence_text, evidence_id))

    dump_json(EVIDENCE_DIR / "evidence_index.v1.json", evidence_index)


if __name__ == "__main__":
    main()

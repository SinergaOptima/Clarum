import json
import sys
from pathlib import Path
from typing import Any, Dict, List, Tuple

ROOT = Path(__file__).resolve().parents[2]
EXPORT_ROOT = ROOT / "09 - Publishing" / "site_export" / "v1"

MANIFEST_PATH = EXPORT_ROOT / "meta" / "publish_manifest.v1.json"
MANIFEST_SCHEMA_PATH = EXPORT_ROOT / "schemas" / "site_index.schema.v1.json"
PAYLOAD_SCHEMA_PATH = EXPORT_ROOT / "schemas" / "site_dossier_payload.schema.v1.json"
REPORT_INDEX_PATH = EXPORT_ROOT / "index" / "index.reports.v1.json"

REPORTS_DIR = EXPORT_ROOT / "reports"
DOSSIERS_DIR = EXPORT_ROOT / "dossiers"
INDEX_DIR = EXPORT_ROOT / "index"
EVIDENCE_DIR = EXPORT_ROOT / "evidence"
MEMOS_DIR = EXPORT_ROOT / "memos"
MEMOS_RENDERED_DIR = MEMOS_DIR / "rendered"


def load_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def is_type(value: Any, expected: str) -> bool:
    if expected == "string":
        return isinstance(value, str)
    if expected == "number":
        return isinstance(value, (int, float))
    if expected == "object":
        return isinstance(value, dict)
    if expected == "array":
        return isinstance(value, list)
    if expected == "boolean":
        return isinstance(value, bool)
    if expected == "null":
        return value is None
    return True


def validate_schema(data: Any, schema: Dict[str, Any], path: str) -> List[str]:
    errors = []
    schema_type = schema.get("type")
    if schema_type and not is_type(data, schema_type):
        errors.append(f"{path}: expected {schema_type}")
        return errors

    if schema_type == "object":
        required = schema.get("required", [])
        for key in required:
            if key not in data:
                errors.append(f"{path}: missing required field '{key}'")
        properties = schema.get("properties", {})
        for key, value in data.items():
            if key in properties:
                errors.extend(validate_schema(value, properties[key], f"{path}.{key}"))
    elif schema_type == "array":
        item_schema = schema.get("items")
        if item_schema:
            for idx, item in enumerate(data):
                errors.extend(validate_schema(item, item_schema, f"{path}[{idx}]"))

    return errors


def load_payloads() -> List[Tuple[Path, Dict[str, Any]]]:
    payloads = []
    for payload_path in sorted(INDEX_DIR.glob("*.payload.v1.json")):
        payloads.append((payload_path, load_json(payload_path)))
    return payloads


def validate_in_scope_indicators(payload: Dict[str, Any], in_scope_ids: List[str]) -> List[str]:
    indicators = {item["id"]: item for item in payload.get("indicators", [])}
    errors = []
    for indicator_id in in_scope_ids:
        indicator = indicators.get(indicator_id)
        if indicator is None:
            errors.append(f"Missing indicator in payload: {indicator_id}")
            continue
        if indicator.get("value") == "VALUE(TODO)":
            errors.append(f"In-scope indicator has VALUE(TODO): {indicator_id}")
    return errors


def main() -> int:
    errors: List[str] = []
    warnings: List[str] = []

    manifest_schema = load_json(MANIFEST_SCHEMA_PATH)
    payload_schema = load_json(PAYLOAD_SCHEMA_PATH)
    manifest = load_json(MANIFEST_PATH)

    errors.extend(validate_schema(manifest, manifest_schema, "manifest"))

    payloads = load_payloads()
    for payload_path, payload in payloads:
        errors.extend(validate_schema(payload, payload_schema, payload_path.name))

    referenced_files = []
    evidence_ids = set()
    memo_files = set()

    for dossier in manifest.get("dossiers", []):
        report_path = REPORTS_DIR / dossier["report_filename_public"]
        dossier_path = DOSSIERS_DIR / dossier["dossier_filename_public"]

        referenced_files.extend([report_path, dossier_path])
        for ev_id in dossier.get("evidence_ids_used", []):
            evidence_ids.add(ev_id)

        slug = dossier["slug"]
        payload_path = INDEX_DIR / f"{slug}.payload.v1.json"
        referenced_files.append(payload_path)

    for file_path in referenced_files:
        if not file_path.exists():
            errors.append(f"Missing referenced file: {file_path}")

    for evidence_id in evidence_ids:
        evidence_path = EVIDENCE_DIR / f"{evidence_id}.md"
        if not evidence_path.exists():
            errors.append(f"Missing evidence file: {evidence_path}")

    evidence_index_path = EVIDENCE_DIR / "evidence_index.v1.json"
    if not evidence_index_path.exists():
        errors.append("Missing evidence index: evidence_index.v1.json")

    for dossier in manifest.get("dossiers", []):
        slug = dossier["slug"]
        payload_path = INDEX_DIR / f"{slug}.payload.v1.json"
        payload = load_json(payload_path)
        errors.extend(validate_in_scope_indicators(payload, dossier.get("indicator_ids_in_scope", [])))

    if not REPORT_INDEX_PATH.exists():
        errors.append(f"Missing report index: {REPORT_INDEX_PATH}")
    else:
        report_index = load_json(REPORT_INDEX_PATH)
        report_entries = report_index.get("reports", []) if isinstance(report_index, dict) else []
        if not isinstance(report_entries, list):
            errors.append("Report index missing 'reports' list")
            report_entries = []

        domestic_reports = [entry for entry in report_entries if entry.get("track") == "domestic"]
        export_reports = [entry for entry in report_entries if entry.get("track") == "export"]
        if len(domestic_reports) != 3:
            errors.append(f"Expected 3 domestic reports; found {len(domestic_reports)}")
        if not export_reports:
            errors.append("No export reports found in report index")

        tierb_domestic_found = False
        for entry in report_entries:
            report_rel_path = entry.get("path")
            if not report_rel_path:
                errors.append("Report index entry missing path")
                continue
            report_path = EXPORT_ROOT / report_rel_path
            if not report_path.exists():
                errors.append(f"Missing report file from index: {report_path}")
                continue
            memo_json_rel = entry.get("memo_json_path")
            memo_md_rel = entry.get("memo_md_path")
            if memo_json_rel:
                memo_json_path = EXPORT_ROOT / memo_json_rel
                memo_files.add(memo_json_path)
                if not memo_json_path.exists():
                    errors.append(f"Missing memo JSON from index: {memo_json_path}")
            if memo_md_rel:
                memo_md_path = EXPORT_ROOT / memo_md_rel
                memo_files.add(memo_md_path)
                if not memo_md_path.exists():
                    errors.append(f"Missing memo markdown from index: {memo_md_path}")
            report = load_json(report_path)
            if "meta" not in report or "flags" not in report:
                errors.append(f"Report missing meta/flags: {report_path}")
                continue
            flags = report.get("flags", {}).get("triggered", [])
            if entry.get("track") == "domestic" and any(
                flag.get("id") == "FLAG-TIERB-PRESENT" for flag in flags if isinstance(flag, dict)
            ):
                tierb_domestic_found = True

        if not tierb_domestic_found:
            warnings.append("No domestic report with FLAG-TIERB-PRESENT found in index")

    if errors:
        print("VALIDATION_FAIL")
        for error in errors:
            print(f"- {error}")
        return 1

    if warnings:
        print("VALIDATION_WARN")
        for warning in warnings:
            print(f"- {warning}")

    print("VALIDATION_PASS")
    print(f"payloads: {len(payloads)}")
    print(f"evidence_files: {len(evidence_ids)}")
    memo_json_count = len([path for path in memo_files if path.suffix == ".json"])
    memo_md_count = len([path for path in memo_files if path.suffix == ".md"])
    print(f"memo_json_files: {memo_json_count}")
    print(f"memo_md_files: {memo_md_count}")
    return 0


if __name__ == "__main__":
    sys.exit(main())

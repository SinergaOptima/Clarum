# WEBSITE GATE — Option A (3 Dossiers)

Date: 2026-02-10
Bundle: 09 - Publishing/site_export/v1/

## Checklist

### Data
- [x] Strict validation passes (HU/MX/MY).
- [x] Site export validation script passes.
- [x] No in-scope TODO indicators in payloads.
- [ ] All URLs in payloads are HTTP 200.
  - Verified during fill sprint; not rechecked here.

### Content
- [x] Each dossier includes executive summary.
- [x] Each dossier includes claims/evidence table.
- [x] Each dossier includes blindspots section ("What would change my view").
- [x] Evidence IDs are resolvable in evidence_index.v1.json.

### Build Readiness
- [x] publish_manifest + payloads + schemas present.
- [x] Stable filenames (ASCII slugs).

## Known Limitations
- Scoring gated (v1 reports have null composite scores).
- Limited publish set (3 dossiers only).
- A5/A6 coverage is limited to SUP-002 and LAB-001.

## Status
- Gate status: PASS (Option A publish set)

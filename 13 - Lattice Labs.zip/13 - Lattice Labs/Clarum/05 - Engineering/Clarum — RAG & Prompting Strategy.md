# Clarum — RAG & Prompting Strategy

## Philosophy
*We do NOT ask the LLM to "assess risk." We ask it to "extract evidence."*

## Pipeline
1.  **Query Generation:** Transform "Regulatory Risk in Mexico" into specific queries: "Mexico permitting delays 2024", "Mexico energy reform AMLO".
2.  **Retrieval:** Fetch top 5 text chunks from Tier B library.
3.  **Synthesis Prompt:**
    > "You are a risk analyst. Using ONLY the provided context, summarize the current status of industrial permitting in Mexico. Cite sources [1], [2]. If no information is found, state 'No data'."
4.  **Verification:** Analyst reviews the generated text against the source chunks.

## Citation Hygiene
- Every generated sentence must append `[Source ID]`.
- Hallucination check: If a claim has no `[ID]`, it is flagged for manual review.

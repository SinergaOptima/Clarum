# Clarum — Security & Compliance Notes

## Data Privacy
- **Client Data:** We do not train on client inputs (project details).
- **Data Residency:** MVP hosted in US-East (AWS/Vercel).
- **Access Control:** Single-tenant logic (Client A cannot see Client B's dossiers).

## AI Safety
- **Model Constraints:** Temperature = 0 for all factual extractions.
- **Human-in-the-Loop:** All "High Risk" scores require manual sign-off before report generation in Beta.

## Disclaimers
- Terms of Service must state: "Information is for reference only. Not legal or investment advice."

# Clarum — System Architecture (MVP)

## High-Level Flow
1.  **Ingest:** Scripts scrape/download Tier A data (CSV/XLS) -> Normalize -> Store in `Postgres`.
2.  **RAG Index:** PDF reports (Tier B) -> Chunking -> Embedding (`OpenAI text-embedding-3-small`) -> Vector DB (`Chroma` local or `Pinecone`).
3.  **App Logic:** `Python` (FastAPI) or `Next.js` API routes.
    - Fetch quantitative data.
    - Retrieve qualitative context via RAG.
    - Calculate scores (Python/Pandas).
4.  **Frontend:** `Next.js` / `React` Dashboard.
5.  **Output:** `Puppeteer` / `React-PDF` to generate Dossier.

## Tech Stack
- **Lang:** Python (Backend analysis), TypeScript (Web).
- **DB:** Postgres (Relational data), JSON (Config).
- **AI:** GPT-4o (Synthesis), Local Embeddings.
- **Hosting:** Vercel (Frontend), Railway/Render (Backend).

## Directory Structure (Codebase)
- `/src/ingest` (Data loaders)
- `/src/models` (Scoring logic)
- `/src/web` (Dashboard)
- `/data/raw` (Source files)

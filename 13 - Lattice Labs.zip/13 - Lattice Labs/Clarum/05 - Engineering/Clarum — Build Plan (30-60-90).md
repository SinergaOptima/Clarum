# Clarum — Build Plan (30/60/90)

## Day 0-30: The "Paper MVP"
- [ ] Finalize LRF-1 Indicator List.
- [ ] Manual collection of data for 1 Pilot Country (Mexico).
- [ ] Create 1 perfect PDF manually (Figma/Word).
- [ ] Validate with 3 friendly experts.

## Day 31-60: The "Engine"
- [ ] Set up Postgres + Ingestion scripts for World Bank/IMF APIs.
- [ ] Build "Score Calculator" (Python script).
- [ ] Generate JSON outputs for 5 countries.

## Day 61-90: The "Interface"
- [ ] Deploy Next.js Dashboard (Read-only).
- [ ] Connect JSON outputs to UI.
- [ ] Implement "Print to PDF" from UI.
- [ ] Launch Beta to waitlist.

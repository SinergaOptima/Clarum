# Country Pack — Malaysia (LRF-1 v1)

> **Status:** Draft (Data capture)  
> **Owner:** Lattice Labs — Research Ops  
> **Applies to:** LRF-1 v1 Indicator Pack  
> **Last Updated:** 2026-02-09

---

## 1) Required Metadata

- Country: Malaysia
- Date: 2026-02-09
- Comparator set: GLOBAL-GDP-10B+
- Profiles in scope (WP-*): WP-SEMI-OSAT-EXPORT-1.1
- Sector scenario assumptions: Semiconductor OSAT export hub
- Data owner: Lattice Labs — Research Ops
- Data retrieval window: DATE(TODO)

---

## 2) A1 Governance & Institutions

| IND ID | Indicator | Value | Unit | Source (institution) | Source link | Retrieved date | Transform output | Notes |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| IND-A1-REG-001 | Regulatory Quality Estimate | VALUE(TODO) | Score (-2.5 to 2.5) | World Bank | TODO(URL) | DATE(TODO) | TRANSFORM(TODO) | |
| IND-A1-REG-002 | Rule of Law Estimate | VALUE(TODO) | Score (-2.5 to 2.5) | World Bank | TODO(URL) | DATE(TODO) | TRANSFORM(TODO) | |
| IND-A1-REG-003 | Contract Enforcement Efficiency | VALUE(TODO) | Days / % of claim | World Bank | TODO(URL) | DATE(TODO) | TRANSFORM(TODO) | |
| IND-A1-REG-004 | Permitting Complexity Index | VALUE(TODO) | Procedures / Days | World Bank / OECD | TODO(URL) | DATE(TODO) | TRANSFORM(TODO) | |
| IND-A1-REG-005 | Regulatory Burden Perception | VALUE(TODO) | Score (1-7) | WEF | TODO(URL) | DATE(TODO) | TRANSFORM(TODO) | |
| IND-A1-REG-006 | Policy Instability Concern | VALUE(TODO) | Index (0-100) | Fund for Peace / PRS | TODO(URL) | DATE(TODO) | TRANSFORM(TODO) | |

Completeness auto-calc (manual): (count with VALUE present) / 6 * 100
Confidence cap: if completeness <50%, cap A1 confidence at Low.

---

## 3) A2 Trade & Market Access

| IND ID | Indicator | Value | Unit | Source (institution) | Source link | Retrieved date | Transform output | Notes |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| IND-A2-GEO-001 | Trade Openness Index | VALUE(TODO) | % of GDP / Tariff % | World Bank / WTO | TODO(URL) | DATE(TODO) | TRANSFORM(TODO) | |
| IND-A2-GEO-002 | Sanctions Alignment Risk | VALUE(TODO) | Alignment (0-1) | UN | TODO(URL) | DATE(TODO) | TRANSFORM(TODO) | FATAL MISSINGNESS |
| IND-A2-GEO-003 | Geopolitical Alignment (Bloc) | VALUE(TODO) | Categorical | Treaty databases | TODO(URL) | DATE(TODO) | TRANSFORM(TODO) | |
| IND-A2-GEO-004 | Conflict Intensity Index | VALUE(TODO) | Score (0-10) | ACLED / UCDP | TODO(URL) | DATE(TODO) | TRANSFORM(TODO) | |
| IND-A2-GEO-005 | High-Tech Export Restrictions | VALUE(TODO) | Binary / Count | US BIS / Wassenaar | TODO(URL) | DATE(TODO) | TRANSFORM(TODO) | FATAL MISSINGNESS |

Completeness auto-calc (manual): (count with VALUE present) / 5 * 100
Confidence cap: if completeness <50%, cap A2 confidence at Low.

---

## 4) A3 Regulatory & Compliance

| IND ID | Indicator | Value | Unit | Source (institution) | Source link | Retrieved date | Transform output | Notes |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| IND-A3-POL-001 | FDI Restrictiveness Index | VALUE(TODO) | Score (0-1) | OECD | TODO(URL) | DATE(TODO) | TRANSFORM(TODO) | |
| IND-A3-POL-002 | Gov't Support for Tech | VALUE(TODO) | Score (1-7) | WEF / ITU | TODO(URL) | DATE(TODO) | TRANSFORM(TODO) | |
| IND-A3-POL-003 | Local Content Requirements | VALUE(TODO) | Binary / Severity | WTO / USTR | TODO(URL) | DATE(TODO) | TRANSFORM(TODO) | |
| IND-A3-POL-004 | SOE Prevalence | VALUE(TODO) | Index | OECD / IMF | TODO(URL) | DATE(TODO) | TRANSFORM(TODO) | |
| IND-A3-POL-005 | Strategic Sector Designation | VALUE(TODO) | Yes/No | National policy docs | TODO(URL) | DATE(TODO) | TRANSFORM(TODO) | |

Completeness auto-calc (manual): (count with VALUE present) / 5 * 100
Confidence cap: if completeness <50%, cap A3 confidence at Low.

---

## 5) A4 Infrastructure & Logistics

| IND ID | Indicator | Value | Unit | Source (institution) | Source link | Retrieved date | Transform output | Notes |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| IND-A4-INF-001 | LPI - Logistics Performance Index | VALUE(TODO) | Score (1-5) | World Bank | TODO(URL) | DATE(TODO) | TRANSFORM(TODO) | |
| IND-A4-INF-002 | Quality of Electricity Supply | VALUE(TODO) | Score (1-7) | WEF | TODO(URL) | DATE(TODO) | TRANSFORM(TODO) | |
| IND-A4-INF-003 | Industrial Electricity Price Volatility | VALUE(TODO) | Variance / CAGR | IEA / National Grid | TODO(URL) | DATE(TODO) | TRANSFORM(TODO) | |
| IND-A4-INF-004 | Port Efficiency / Dwell Time | VALUE(TODO) | Days | IMF PortWatch / UNCTAD | TODO(URL) | DATE(TODO) | TRANSFORM(TODO) | |
| IND-A4-INF-005 | Industrial Internet Quality | VALUE(TODO) | Index | Ookla / ITU | TODO(URL) | DATE(TODO) | TRANSFORM(TODO) | |
| IND-A4-INF-006 | Industrial Land Availability | VALUE(TODO) | Score / Days | World Bank | TODO(URL) | DATE(TODO) | TRANSFORM(TODO) | |

Completeness auto-calc (manual): (count with VALUE present) / 6 * 100
Confidence cap: if completeness <50%, cap A4 confidence at Low.

---

## 6) A5 Supply Chain & Ecosystem

| IND ID | Indicator | Value | Unit | Source (institution) | Source link | Retrieved date | Transform output | Notes |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| IND-A5-SUP-001 | Export Concentration Index | VALUE(TODO) | Score (0-1) | UNCTAD | TODO(URL) | DATE(TODO) | TRANSFORM(TODO) | |
| IND-A5-SUP-002 | Manufacturing Value Added | VALUE(TODO) | % of GDP | World Bank | TODO(URL) | DATE(TODO) | TRANSFORM(TODO) | |
| IND-A5-SUP-003 | Critical Raw Material Production | VALUE(TODO) | % global share | USGS / IEA | TODO(URL) | DATE(TODO) | TRANSFORM(TODO) | |
| IND-A5-SUP-004 | Quality Certification Density | VALUE(TODO) | Count / Ratio | ISO | TODO(URL) | DATE(TODO) | TRANSFORM(TODO) | |
| IND-A5-SUP-005 | Supplier Delivery Time | VALUE(TODO) | Index (50=neutral) | S&P Global | TODO(URL) | DATE(TODO) | TRANSFORM(TODO) | |

Completeness auto-calc (manual): (count with VALUE present) / 5 * 100
Confidence cap: if completeness <50%, cap A5 confidence at Low.

---

## 7) A6 Talent & Labor

| IND ID | Indicator | Value | Unit | Source (institution) | Source link | Retrieved date | Transform output | Notes |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| IND-A6-LAB-001 | Human Capital Index | VALUE(TODO) | Score (0-1) | World Bank | TODO(URL) | DATE(TODO) | TRANSFORM(TODO) | |
| IND-A6-LAB-002 | STEM Graduates | VALUE(TODO) | % of tertiary grads | UNESCO / OECD | TODO(URL) | DATE(TODO) | TRANSFORM(TODO) | |
| IND-A6-LAB-003 | Labor Freedom / Flexibility | VALUE(TODO) | Score (0-100) | Fraser / Heritage | TODO(URL) | DATE(TODO) | TRANSFORM(TODO) | |
| IND-A6-LAB-004 | Strike / Labor Unrest Risk | VALUE(TODO) | Score | Verisk / ACLED | TODO(URL) | DATE(TODO) | TRANSFORM(TODO) | |
| IND-A6-LAB-005 | Ease of Finding Skilled Employees | VALUE(TODO) | Score (1-7) | WEF / ManpowerGroup | TODO(URL) | DATE(TODO) | TRANSFORM(TODO) | |

Completeness auto-calc (manual): (count with VALUE present) / 5 * 100
Confidence cap: if completeness <50%, cap A6 confidence at Low.

---

## 8) A7 Capital & Macro

| IND ID | Indicator | Value | Unit | Source (institution) | Source link | Retrieved date | Transform output | Notes |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| IND-A7-CAP-001 | Exchange Rate Volatility | VALUE(TODO) | % std dev | IMF | TODO(URL) | DATE(TODO) | TRANSFORM(TODO) | |
| IND-A7-CAP-002 | Chinn-Ito Index | VALUE(TODO) | Score (-1.9 to 2.3) | Chinn-Ito | TODO(URL) | DATE(TODO) | TRANSFORM(TODO) | |
| IND-A7-CAP-003 | Inflation Rate (CPI) | VALUE(TODO) | % YoY | IMF / Central Bank | TODO(URL) | DATE(TODO) | TRANSFORM(TODO) | |
| IND-A7-CAP-004 | Sovereign Credit Rating | VALUE(TODO) | Rating | S&P / Moody's / Fitch | TODO(URL) | DATE(TODO) | TRANSFORM(TODO) | |
| IND-A7-CAP-005 | Central Bank Transparency | VALUE(TODO) | Score | Academic / BIS | TODO(URL) | DATE(TODO) | TRANSFORM(TODO) | |

Completeness auto-calc (manual): (count with VALUE present) / 5 * 100
Confidence cap: if completeness <50%, cap A7 confidence at Low.

---

## 9) A8 Integrity, ESG & Security

| IND ID | Indicator | Value | Unit | Source (institution) | Source link | Retrieved date | Transform output | Notes |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| IND-A8-ESG-001 | Corruption Perceptions Index (CPI) | VALUE(TODO) | Score (0-100) | Transparency International | TODO(URL) | DATE(TODO) | TRANSFORM(TODO) | |
| IND-A8-ESG-002 | Environmental Performance Index (EPI) | VALUE(TODO) | Score (0-100) | Yale / Columbia | TODO(URL) | DATE(TODO) | TRANSFORM(TODO) | |
| IND-A8-ESG-003 | Labor Rights Index | VALUE(TODO) | Score (0-100) | Penn State / NGO | TODO(URL) | DATE(TODO) | TRANSFORM(TODO) | |
| IND-A8-ESG-004 | Control of Corruption | VALUE(TODO) | Score (-2.5 to 2.5) | World Bank | TODO(URL) | DATE(TODO) | TRANSFORM(TODO) | |
| IND-A8-ESG-005 | Social License / Protest Risk | VALUE(TODO) | Index | Verisk / ACLED | TODO(URL) | DATE(TODO) | TRANSFORM(TODO) | |

Completeness auto-calc (manual): (count with VALUE present) / 5 * 100
Confidence cap: if completeness <50%, cap A8 confidence at Low.

---

## 10) Data Gaps & Manual Overrides

- Missing required INDs: IND-A1-REG-001..006; IND-A2-GEO-001..005; IND-A3-POL-001..005; IND-A4-INF-001..006; IND-A5-SUP-001..005; IND-A6-LAB-001..005; IND-A7-CAP-001..005; IND-A8-ESG-001..005.
- Fatal missingness INDs: IND-A2-GEO-002, IND-A2-GEO-005.
- Manual override steps (if triggered):
  1) Document reason for missingness.
  2) Add Tier A/B qualitative evidence in dossier.
  3) Set confidence cap per rubric.
  4) Record override in audit fields.

---

## 11) Audit JSON Mapping (field names only)

- country
- case_id
- comparator_set_id
- normalization_method
- indicator_inputs_used
- completeness_scores
- evidence_counts_by_tier
- flags_triggered
- overrides_applied
- weight_profile_id
- overlay_id
- final_scores

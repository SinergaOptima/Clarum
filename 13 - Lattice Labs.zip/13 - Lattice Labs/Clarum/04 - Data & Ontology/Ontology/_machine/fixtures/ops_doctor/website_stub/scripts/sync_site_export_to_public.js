// fixture sync script
console.log("sync")

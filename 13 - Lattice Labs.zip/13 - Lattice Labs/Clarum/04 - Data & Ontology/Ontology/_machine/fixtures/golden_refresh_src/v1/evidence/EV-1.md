evidence text

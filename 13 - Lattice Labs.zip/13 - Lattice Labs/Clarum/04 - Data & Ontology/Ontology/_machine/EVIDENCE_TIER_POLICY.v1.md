# Evidence Tier Policy (v1)

## Tier A (default)
Evidence from authoritative public statistical agencies, major multilaterals, or official government sources. Examples: World Bank, IMF, OECD, UN bodies, national statistical offices, official regulatory sources.

## Tier B
Evidence from executive sentiment surveys, ideologically-coded indices, commercial risk feeds, or other non-official sources that are informative but less authoritative. Examples: WEF survey indices, proprietary risk feeds, commercial sentiment products.

## Enforcement
- Tier B is allowed only when explicitly marked as `evidence_tier: "B"`.
- Missing `evidence_tier` is treated as Tier A.
- Tier B caps per-indicator confidence in reports and triggers a report-level flag.
- Publishing UI must visibly label Tier B-backed claims (future requirement).

## Tier B allowlist enforcement
- Tier B values must match allowlisted source tokens and/or URL domains during strict validation.
- Allowlist: TIERB_ALLOWLIST.v1.json.
- Keep allowlists indicator-specific and minimal.

# Memo: MEX EV OEM domestic

## Executive Summary
This memo summarizes the Mexico EV OEM DOMESTIC report using deterministic rules and cited sources. Data quality is anchored by completeness at 98% with an overall confidence cap of high. Strengths cluster in A1, A2, while A7, A1 warrant closer scrutiny based on available signals. Key takeaways include one structural opportunity, one major risk, and one watch item tied to proxy reliance or missingness. Overall, the evidence base is sufficient for directional insights but should be refreshed as Tier B proxies are replaced with primary sources.

## Key Findings
- A1 indicators show consistent coverage with no major gaps in current artifacts. (confidence 0.6, refs: C-69069da737)
- A2 indicators show consistent coverage with no major gaps in current artifacts. (confidence 0.6, refs: C-74af1f9359)
- A7 signals rely on proxies and should be treated as higher-uncertainty risk indicators. (confidence 0.6, refs: C-37e2a36334)
- A1 signals rely on proxies and should be treated as higher-uncertainty risk indicators. (confidence 0.6, refs: C-69069da737)
- Tier B sources are present; confidence should be capped until primary sources are substituted. (confidence 0.6, refs: none)

## Risk Register
- R-A1 | A1 | severity 0.0 | confidence 0.6 | refs: C-69069da737
- R-A2 | A2 | severity 0.0 | confidence 0.6 | refs: C-74af1f9359
- R-A3 | A3 | severity 0.0 | confidence 0.6 | refs: C-e74473ad52, C-28f9c0e628
- R-A4 | A4 | severity 0.0 | confidence 0.6 | refs: C-5ec7b4235a
- R-A5 | A5 | severity 0.0 | confidence 0.6 | refs: C-127cbe16ce
- R-A6 | A6 | severity 0.0 | confidence 0.6 | refs: C-4052557806
- R-A7 | A7 | severity 20.0 | confidence 0.6 | refs: C-37e2a36334
- R-A8 | A8 | severity 0.0 | confidence 0.6 | refs: C-22aeaa32c8

## Data Quality
- completeness_pct: 97.5 | tier_b_present: True | confidence_caps: ['high']

## Citations
- C-0103a77d10: https://api.worldbank.org/v2/country/MEX/indicator/IC.FRM.DURS?format=json
- C-0166e161d3: snapshot:C:/Users/Melek/Documents/Sinerga-Optima/13 - Lattice Labs/Clarum/08 - Operations/fill_runner/adapters/snapshots/kaopen_2023_export.csv
- C-04233a6ca7: https://api.worldbank.org/v2/country/MEX/indicator/IC.FRM.INNOV.T1?format=json
- C-07eb9a2a45: https://www.itu.int/en/ITU-D/Statistics/Documents/IDI/IDI2023Dataset.xlsx
- C-0a159dfc4e: https://api.worldbank.org/v2/country/MEX/indicator/IC.CNST.PRMT.TM.DY?format=json
- C-127cbe16ce: https://wits.worldbank.org/API/V1/SDMX/V21/datasource/tradestats-trade/reporter/MEX/year/2023/indicator/HH-MKT-CNCNTRTN-NDX?format=JSON
- C-16f218a101: https://api.worldbank.org/v2/country/MEX/indicator/IC.FRM.REG.BUS5?format=json
- C-1810b6e8c7: https://api.worldbank.org/v2/country/MEX/indicator/IC.FRM.OBS.OBST11?format=json
- C-22aeaa32c8: https://raw.githubusercontent.com/datasets/corruption-perceptions-index/main/data/cpi.csv
- C-231af23f87: https://api.worldbank.org/v2/country/MEX/indicator/NV.IND.MANF.ZS?format=json
- C-28f9c0e628: https://goingdigital.oecd.org/api/indicator/74/export?locale=en&s=%7B%22perspectives%22%3A%7B%22sector%22%3A%2243%22%2C%22stacked%22%3Atrue%2C%22symbols%22%3A%5B%5D%2C%22restype%22%3A%22V%22%7D%2C%22countries%22%3A%7B%22highlights%22%3A%5B%5D%2C%22highlightModeExclusive%22%3Afalse%7D%2C%22time%22%3A%7B%22timeseries%22%3Afalse%2C%22start%22%3A2018%2C%22end%22%3A2023%7D%7D&format=zip
- C-2f4a6cf90e: https://api.worldbank.org/v2/country/MEX/indicator/IC.FRM.WRKF.WK10?format=json
- C-34111bd54d: https://api.worldbank.org/v2/country/MEX/indicator/GC.DOD.TOTL.GD.ZS?format=json
- C-37e2a36334: https://api.worldbank.org/v2/country/MEX/indicator/PA.NUS.FCRF?format=json
- C-3c461f89b0: https://api.worldbank.org/v2/country/MEX/indicator/VC.IHR.PSRC.P5?format=json
- C-3e66c49dea: https://www.ecfr.gov/current/title-15/subtitle-B/chapter-VII/subchapter-C/part-740
- C-4052557806: https://api.worldbank.org/v2/country/MEX/indicator/HD.HCI.OVRL?format=json
- C-46afe3b075: https://api.worldbank.org/v2/country/MEX/indicator/IT.NET.BBND.P2?format=json
- C-4a5ab6937f: https://www.bis.gov/regulations/ear
- C-4f83629d1f: https://api.worldbank.org/v2/country/MEX/indicator/SP.POP.SCIE.RD.P6?format=json
- C-51affb3413: https://api.worldbank.org/v2/country/MEX/indicator/EG.ELC.LOSS.ZS?format=json
- C-5a1574bcfc: https://api.worldbank.org/v2/country/MEX/indicator/VA.EST?format=json
- C-5c4cf149eb: https://api.worldbank.org/v2/country/MEX/indicator/IC.CUS.DURS.EX?format=json
- C-5ec7b4235a: https://api.worldbank.org/v2/country/MEX/indicator/LP.LPI.OVRL.XQ?format=json
- C-69069da737: https://api.worldbank.org/v2/country/MEX/indicator/RQ.EST?format=json
- C-74af1f9359: https://api.worldbank.org/v2/country/MEX/indicator/NE.TRD.GNFS.ZS?format=json
- C-75ab4565b0: https://www.state.gov/reports/2025-investment-climate-statements/mexico
- C-7a2f489488: https://ofac.treasury.gov/sanctions-list-service
- C-7d58e11c1c: https://api.worldbank.org/v2/country/MEX/indicator/SL.UEM.TOTL.ZS?format=json
- C-888aebd847: https://api.worldbank.org/v2/country/MEX/indicator/ENF.CONT.DURS.DY?format=json
- C-8f6a3387ef: https://epi.yale.edu/downloads/epi2024results.csv
- C-93803b9c2d: https://api.worldbank.org/v2/country/MEX/indicator/NY.GDP.MINR.RT.ZS?format=json
- C-93dbb3c969: https://api.worldbank.org/v2/country/MEX/indicator/ENF.CONT.COEN.COST.ZS?format=json
- C-a46b8d58d9: https://api.worldbank.org/v2/country/MEX/indicator/CC.EST?format=json
- C-aaf1db2ac2: https://api.worldbank.org/v2/country/MEX/indicator/PV.EST?format=json
- C-aeaaa528b4: https://api.worldbank.org/v2/country/MEX/indicator/GE.EST?format=json
- C-af1e876d2a: https://www.bis.gov/licensing/country-guidance
- C-b32d56527b: https://www.gov.uk/government/publications/the-uk-sanctions-list
- C-ba78106a1d: https://api.worldbank.org/v2/country/MEX/indicator/FP.CPI.TOTL.ZG?format=json
- C-cc0996c5f3: https://api.worldbank.org/v2/country/MEX/indicator/RL.EST?format=json
- C-ce63a5fd08: https://www.oecd.org/content/dam/oecd/en/topics/policy-sub-issues/product-market-regulation/OECD-PMR-Economy-wide-indicator-values_2023-2024.xlsx
- C-d21c30bb9e: https://api.worldbank.org/v2/country/MEX/indicator/IC.CNST.PRMT.PROC.NO?format=json
- C-d87a8a4c8d: https://api.worldbank.org/v2/country/MEX/indicator/LP.LPI.LOGS.XQ?format=json
- C-e2a05c0e84: https://main.un.org/securitycouncil/content/un-sc-consolidated-list
- C-e74473ad52: https://goingdigital.oecd.org/en/indicator/74
- C-f0be8674f4: https://api.worldbank.org/v2/country/MEX/indicator/IC.FRM.WRKF.WK9?format=json

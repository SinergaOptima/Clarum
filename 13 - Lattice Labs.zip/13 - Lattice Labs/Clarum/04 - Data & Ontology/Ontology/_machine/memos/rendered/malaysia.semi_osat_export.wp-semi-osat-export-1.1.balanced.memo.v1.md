# Memo: MYS SEMI OSAT export

## Executive Summary
This memo summarizes the Malaysia SEMI OSAT EXPORT report using deterministic rules and cited sources. Data quality is anchored by completeness at 98% with an overall confidence cap of high. Strengths cluster in A1, A2, while A7, A1 warrant closer scrutiny based on available signals. Key takeaways include one structural opportunity, one major risk, and one watch item tied to proxy reliance or missingness. Overall, the evidence base is sufficient for directional insights but should be refreshed as Tier B proxies are replaced with primary sources.

## Key Findings
- A1 indicators show consistent coverage with no major gaps in current artifacts. (confidence 0.6, refs: C-1ac3407d1d)
- A2 indicators show consistent coverage with no major gaps in current artifacts. (confidence 0.6, refs: C-97648d9762)
- A7 signals rely on proxies and should be treated as higher-uncertainty risk indicators. (confidence 0.6, refs: C-dd810f1a74)
- A1 signals rely on proxies and should be treated as higher-uncertainty risk indicators. (confidence 0.6, refs: C-1ac3407d1d)
- Tier B sources are present; confidence should be capped until primary sources are substituted. (confidence 0.6, refs: none)

## Risk Register
- R-A1 | A1 | severity 0.0 | confidence 0.6 | refs: C-1ac3407d1d
- R-A2 | A2 | severity 0.0 | confidence 0.6 | refs: C-97648d9762
- R-A3 | A3 | severity 0.0 | confidence 0.6 | refs: C-0dbd3dea38
- R-A4 | A4 | severity 0.0 | confidence 0.6 | refs: C-7d43628489
- R-A5 | A5 | severity 0.0 | confidence 0.6 | refs: C-6193222f05
- R-A6 | A6 | severity 0.0 | confidence 0.6 | refs: C-7502943861
- R-A7 | A7 | severity 20.0 | confidence 0.6 | refs: C-dd810f1a74
- R-A8 | A8 | severity 0.0 | confidence 0.6 | refs: C-22aeaa32c8

## Data Quality
- completeness_pct: 97.5 | tier_b_present: True | confidence_caps: ['high']

## Citations
- C-0166e161d3: snapshot:C:/Users/Melek/Documents/Sinerga-Optima/13 - Lattice Labs/Clarum/08 - Operations/fill_runner/adapters/snapshots/kaopen_2023_export.csv
- C-07eb9a2a45: https://www.itu.int/en/ITU-D/Statistics/Documents/IDI/IDI2023Dataset.xlsx
- C-0ae56c6a72: https://api.worldbank.org/v2/country/MYS/indicator/ENF.CONT.COEN.COST.ZS?format=json
- C-0dbd3dea38: https://api.worldbank.org/v2/country/MYS/indicator/BX.KLT.DINV.WD.GD.ZS?format=json
- C-1350a81262: https://api.worldbank.org/v2/country/MYS/indicator/IC.FRM.WRKF.WK10?format=json
- C-1ac3407d1d: https://api.worldbank.org/v2/country/MYS/indicator/RQ.EST?format=json
- C-1be0e7c3f9: https://api.worldbank.org/v2/country/MYS/indicator/NV.IND.MANF.ZS?format=json
- C-1f5c22e933: https://www.state.gov/reports/2025-investment-climate-statements/malaysia
- C-22aeaa32c8: https://raw.githubusercontent.com/datasets/corruption-perceptions-index/main/data/cpi.csv
- C-230a6e4def: https://api.worldbank.org/v2/country/MYS/indicator/LP.LPI.LOGS.XQ?format=json
- C-258c83172c: https://api.worldbank.org/v2/country/MYS/indicator/IC.FRM.DURS?format=json
- C-26e68505a0: https://api.worldbank.org/v2/country/MYS/indicator/IC.CNST.PRMT.PROC.NO?format=json
- C-2c7a0f3eff: https://api.worldbank.org/v2/country/MYS/indicator/IC.FRM.REG.BUS5?format=json
- C-2d2a08bad9: https://api.worldbank.org/v2/country/MYS/indicator/GE.EST?format=json
- C-3902bbc567: https://api.worldbank.org/v2/country/MYS/indicator/RL.EST?format=json
- C-3e66c49dea: https://www.ecfr.gov/current/title-15/subtitle-B/chapter-VII/subchapter-C/part-740
- C-46ba2b0b1c: https://api.worldbank.org/v2/country/MYS/indicator/IC.FRM.OBS.OBST11?format=json
- C-47a35b5996: https://api.worldbank.org/v2/country/MYS/indicator/FP.CPI.TOTL.ZG?format=json
- C-4a5ab6937f: https://www.bis.gov/regulations/ear
- C-532ace9634: https://api.worldbank.org/v2/country/MYS/indicator/ENF.CONT.DURS.DY?format=json
- C-55888771f1: https://api.worldbank.org/v2/country/MYS/indicator/IT.NET.BBND.P2?format=json
- C-5ae725bb45: https://api.worldbank.org/v2/country/MYS/indicator/VC.IHR.PSRC.P5?format=json
- C-6193222f05: https://wits.worldbank.org/API/V1/SDMX/V21/datasource/tradestats-trade/reporter/MYS/year/2023/indicator/HH-MKT-CNCNTRTN-NDX?format=JSON
- C-7108d22ee4: https://api.worldbank.org/v2/country/MYS/indicator/IC.FRM.INNOV.T1?format=json
- C-7502943861: https://api.worldbank.org/v2/country/MYS/indicator/HD.HCI.OVRL?format=json
- C-7a2f489488: https://ofac.treasury.gov/sanctions-list-service
- C-7d43628489: https://api.worldbank.org/v2/country/MYS/indicator/LP.LPI.OVRL.XQ?format=json
- C-84d8d381cb: https://api.worldbank.org/v2/country/MYS/indicator/SP.POP.SCIE.RD.P6?format=json
- C-8a2153d42f: https://api.worldbank.org/v2/country/MYS/indicator/PV.EST?format=json
- C-8f6a3387ef: https://epi.yale.edu/downloads/epi2024results.csv
- C-9149f81e68: https://api.worldbank.org/v2/country/MYS/indicator/VA.EST?format=json
- C-97648d9762: https://api.worldbank.org/v2/country/MY/indicator/NE.TRD.GNFS.ZS?format=json
- C-a0ee76dce3: https://api.worldbank.org/v2/country/MYS/indicator/IC.CUS.DURS.EX?format=json
- C-a1f39ca773: https://api.worldbank.org/v2/country/MYS/indicator/IC.CNST.PRMT.TM.DY?format=json
- C-a6acd1cb15: https://api.worldbank.org/v2/country/MYS/indicator/GC.DOD.TOTL.GD.ZS?format=json
- C-af1e876d2a: https://www.bis.gov/licensing/country-guidance
- C-b2908ccf24: https://api.worldbank.org/v2/country/MYS/indicator/CC.EST?format=json
- C-b32d56527b: https://www.gov.uk/government/publications/the-uk-sanctions-list
- C-cded7ca905: https://api.worldbank.org/v2/country/MYS/indicator/NY.GDP.MINR.RT.ZS?format=json
- C-d358003942: https://api.worldbank.org/v2/country/MYS/indicator/IC.FRM.WRKF.WK9?format=json
- C-dd810f1a74: https://api.worldbank.org/v2/country/MYS/indicator/PA.NUS.FCRF?format=json
- C-e2a05c0e84: https://main.un.org/securitycouncil/content/un-sc-consolidated-list
- C-ea5be5eba3: https://api.worldbank.org/v2/country/MYS/indicator/EG.ELC.LOSS.ZS?format=json
- C-f747d9b5a5: https://api.worldbank.org/v2/country/MYS/indicator/SL.UEM.TOTL.ZS?format=json

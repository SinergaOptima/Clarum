# Memo: HUN EV OEM domestic

## Executive Summary
This memo summarizes the Hungary EV OEM DOMESTIC report using deterministic rules and cited sources. Data quality is anchored by completeness at 98% with an overall confidence cap of high. Strengths cluster in A1, A2, while A7, A1 warrant closer scrutiny based on available signals. Key takeaways include one structural opportunity, one major risk, and one watch item tied to proxy reliance or missingness. Overall, the evidence base is sufficient for directional insights but should be refreshed as Tier B proxies are replaced with primary sources.

## Key Findings
- A1 indicators show consistent coverage with no major gaps in current artifacts. (confidence 0.6, refs: C-49a383e2a8)
- A2 indicators show consistent coverage with no major gaps in current artifacts. (confidence 0.6, refs: C-3e2e9e6a7d)
- A7 signals rely on proxies and should be treated as higher-uncertainty risk indicators. (confidence 0.6, refs: C-5e50681f81)
- A1 signals rely on proxies and should be treated as higher-uncertainty risk indicators. (confidence 0.6, refs: C-49a383e2a8)
- Tier B sources are present; confidence should be capped until primary sources are substituted. (confidence 0.6, refs: none)

## Risk Register
- R-A1 | A1 | severity 0.0 | confidence 0.6 | refs: C-49a383e2a8
- R-A2 | A2 | severity 0.0 | confidence 0.6 | refs: C-3e2e9e6a7d
- R-A3 | A3 | severity 0.0 | confidence 0.6 | refs: C-e74473ad52, C-28f9c0e628
- R-A4 | A4 | severity 0.0 | confidence 0.6 | refs: C-4c632c7cab
- R-A5 | A5 | severity 0.0 | confidence 0.6 | refs: C-a8ba22fbc0
- R-A6 | A6 | severity 0.0 | confidence 0.6 | refs: C-818f51e799
- R-A7 | A7 | severity 20.0 | confidence 0.6 | refs: C-5e50681f81
- R-A8 | A8 | severity 0.0 | confidence 0.6 | refs: C-22aeaa32c8

## Data Quality
- completeness_pct: 97.5 | tier_b_present: True | confidence_caps: ['high']

## Citations
- C-0166e161d3: snapshot:C:/Users/Melek/Documents/Sinerga-Optima/13 - Lattice Labs/Clarum/08 - Operations/fill_runner/adapters/snapshots/kaopen_2023_export.csv
- C-077ba1d7f9: https://api.worldbank.org/v2/country/HUN/indicator/SP.POP.SCIE.RD.P6?format=json
- C-07eb9a2a45: https://www.itu.int/en/ITU-D/Statistics/Documents/IDI/IDI2023Dataset.xlsx
- C-22aeaa32c8: https://raw.githubusercontent.com/datasets/corruption-perceptions-index/main/data/cpi.csv
- C-2459c5b318: https://investmentpolicy.unctad.org/investment-laws/laws/533/hungary-act-lvii-of-2018-on-the-control-of-foreign-investments-detrimental-to-the-security-interests
- C-28f9c0e628: https://goingdigital.oecd.org/api/indicator/74/export?locale=en&s=%7B%22perspectives%22%3A%7B%22sector%22%3A%2243%22%2C%22stacked%22%3Atrue%2C%22symbols%22%3A%5B%5D%2C%22restype%22%3A%22V%22%7D%2C%22countries%22%3A%7B%22highlights%22%3A%5B%5D%2C%22highlightModeExclusive%22%3Afalse%7D%2C%22time%22%3A%7B%22timeseries%22%3Afalse%2C%22start%22%3A2018%2C%22end%22%3A2023%7D%7D&format=zip
- C-2d66262c8f: https://api.worldbank.org/v2/country/HUN/indicator/EG.ELC.LOSS.ZS?format=json
- C-2f289463ff: https://api.worldbank.org/v2/country/HUN/indicator/IC.CNST.PRMT.TM.DY?format=json
- C-36248c3a12: https://api.worldbank.org/v2/country/HUN/indicator/ENF.CONT.DURS.DY?format=json
- C-3e2e9e6a7d: https://api.worldbank.org/v2/country/HU/indicator/NE.TRD.GNFS.ZS?format=json
- C-3e66c49dea: https://www.ecfr.gov/current/title-15/subtitle-B/chapter-VII/subchapter-C/part-740
- C-40a263d461: https://api.worldbank.org/v2/country/HUN/indicator/SL.UEM.TOTL.ZS?format=json
- C-45940f5c26: https://www.state.gov/reports/2025-investment-climate-statements/hungary
- C-49a383e2a8: https://api.worldbank.org/v2/country/HUN/indicator/RQ.EST?format=json
- C-4a5ab6937f: https://www.bis.gov/regulations/ear
- C-4c632c7cab: https://api.worldbank.org/v2/country/HUN/indicator/LP.LPI.OVRL.XQ?format=json
- C-5d790e7bfb: https://api.worldbank.org/v2/country/HUN/indicator/NV.IND.MANF.ZS?format=json
- C-5e50681f81: https://api.worldbank.org/v2/country/HUN/indicator/PA.NUS.FCRF?format=json
- C-6599be8f82: https://api.worldbank.org/v2/country/HUN/indicator/IC.FRM.DURS?format=json
- C-6c61c582de: https://api.worldbank.org/v2/country/HUN/indicator/CC.EST?format=json
- C-6f3091d1d9: https://api.worldbank.org/v2/country/HUN/indicator/IC.FRM.REG.BUS5?format=json
- C-7a2f489488: https://ofac.treasury.gov/sanctions-list-service
- C-818f51e799: https://api.worldbank.org/v2/country/HUN/indicator/HD.HCI.OVRL?format=json
- C-83bb2c96d3: https://api.worldbank.org/v2/country/HUN/indicator/GE.EST?format=json
- C-864b1162ff: https://www.sanctionsmap.eu/
- C-8f6a3387ef: https://epi.yale.edu/downloads/epi2024results.csv
- C-93105d7b91: https://api.worldbank.org/v2/country/HUN/indicator/IC.CUS.DURS.EX?format=json
- C-941951b370: https://api.worldbank.org/v2/country/HUN/indicator/NY.GDP.MINR.RT.ZS?format=json
- C-9d226328e3: https://api.worldbank.org/v2/country/HUN/indicator/GC.DOD.TOTL.GD.ZS?format=json
- C-a235f4ad06: https://api.worldbank.org/v2/country/HUN/indicator/IC.FRM.WRKF.WK10?format=json
- C-a8ba22fbc0: https://wits.worldbank.org/API/V1/SDMX/V21/datasource/tradestats-trade/reporter/HUN/year/2023/indicator/HH-MKT-CNCNTRTN-NDX?format=JSON
- C-a9828811bb: https://api.worldbank.org/v2/country/HUN/indicator/VA.EST?format=json
- C-ad121f008a: https://api.worldbank.org/v2/country/HUN/indicator/FP.CPI.TOTL.ZG?format=json
- C-ae3678f9c8: https://eur-lex.europa.eu/eli/reg/2021/821/oj
- C-bb263937e3: https://api.worldbank.org/v2/country/HUN/indicator/IC.FRM.WRKF.WK9?format=json
- C-c2c7dc7df0: https://api.worldbank.org/v2/country/HUN/indicator/IC.CNST.PRMT.PROC.NO?format=json
- C-cc57c8ed34: https://api.worldbank.org/v2/country/HUN/indicator/RL.EST?format=json
- C-ce63a5fd08: https://www.oecd.org/content/dam/oecd/en/topics/policy-sub-issues/product-market-regulation/OECD-PMR-Economy-wide-indicator-values_2023-2024.xlsx
- C-d030f022cb: https://api.worldbank.org/v2/country/HUN/indicator/PV.EST?format=json
- C-d34342f1a1: https://api.worldbank.org/v2/country/HUN/indicator/IC.FRM.INNOV.T1?format=json
- C-d489133943: https://api.worldbank.org/v2/country/HUN/indicator/LP.LPI.LOGS.XQ?format=json
- C-d82b9b0426: https://api.worldbank.org/v2/country/HUN/indicator/IT.NET.BBND.P2?format=json
- C-d882559034: https://api.worldbank.org/v2/country/HUN/indicator/IC.FRM.OBS.OBST11?format=json
- C-e2270cd825: https://api.worldbank.org/v2/country/HUN/indicator/ENF.CONT.COEN.COST.ZS?format=json
- C-e2a05c0e84: https://main.un.org/securitycouncil/content/un-sc-consolidated-list
- C-e74473ad52: https://goingdigital.oecd.org/en/indicator/74
- C-f30c5d408e: https://api.worldbank.org/v2/country/HUN/indicator/VC.IHR.PSRC.P5?format=json

# LRF-1 Machine Layer

This folder contains machine-readable artifacts derived from the LRF-1 human notes.

## Contents
- indicator_catalog.v1.json
- country_pack.schema.v1.json
- country_pack_template.v1.yaml (JSON-compatible YAML)
- country_packs/*.v1.yaml (JSON-compatible YAML)

## Notes
- The .yaml files are written as JSON (valid YAML) to avoid requiring a YAML library.
- Regenerate outputs with the exporter script in 08 - Operations/scripts/lrf_machine_export.py.
- Validate packs with 08 - Operations/scripts/validate_country_pack.py.

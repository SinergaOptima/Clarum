# Coverage Report

Generated at UTC: 2026-02-12T21:03:47+00:00

## Summary
- Packs: 3
- Reports: 6
- Catalog indicators: 42

## Pack Coverage
| Pack | Country | Filled | Total | Completeness % | Tier A | Tier B | Missing evidence_refs |
|---|---|---:|---:|---:|---:|---:|---:|
| `04 - Data & Ontology/Ontology/_machine/country_packs/hungary.v1.yaml` | Hungary | 42 | 42 | 100.0 | 11 | 15 | 42 |
| `04 - Data & Ontology/Ontology/_machine/country_packs/malaysia.v1.yaml` | Malaysia | 42 | 42 | 100.0 | 11 | 18 | 42 |
| `04 - Data & Ontology/Ontology/_machine/country_packs/mexico.v1.yaml` | Mexico | 42 | 42 | 100.0 | 11 | 18 | 42 |

## Evidence Parity
- evidence_index_count: 24
- evidence_md_count: 24
- orphan_evidence_md: 0
- orphan_evidence_index_entries: 0
- missing_payload_evidence_refs: 0

## Track/Profile Coverage
| Report | Profile | Fatal Missingness | Missing IDs | Confidence Cap |
|---|---|---|---|---|
| `04 - Data & Ontology/Ontology/_machine/reports/hungary.ev_oem_domestic.wp-ev-oem-dom-1.1.balanced.report.v1.json` | WP-EV-OEM-DOM-1.1 | false | - | high |
| `04 - Data & Ontology/Ontology/_machine/reports/hungary.ev_oem_export.wp-ev-oem-export-1.1.balanced.report.v1.json` | WP-EV-OEM-EXPORT-1.1 | false | - | high |
| `04 - Data & Ontology/Ontology/_machine/reports/malaysia.ev_oem_domestic.wp-ev-oem-dom-1.1.balanced.report.v1.json` | WP-EV-OEM-DOM-1.1 | false | - | high |
| `04 - Data & Ontology/Ontology/_machine/reports/malaysia.semi_osat_export.wp-semi-osat-export-1.1.balanced.report.v1.json` | WP-SEMI-OSAT-EXPORT-1.1 | false | - | high |
| `04 - Data & Ontology/Ontology/_machine/reports/mexico.ev_oem_domestic.wp-ev-oem-dom-1.1.balanced.report.v1.json` | WP-EV-OEM-DOM-1.1 | false | - | high |
| `04 - Data & Ontology/Ontology/_machine/reports/mexico.ev_oem_export.wp-ev-oem-export-1.1.balanced.report.v1.json` | WP-EV-OEM-EXPORT-1.1 | false | - | high |


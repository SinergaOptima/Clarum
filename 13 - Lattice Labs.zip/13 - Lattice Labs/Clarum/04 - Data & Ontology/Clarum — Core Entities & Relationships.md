# Clarum — Core Entities & Relationships

## ERD (Conceptual)

```mermaid
erDiagram
    CASE ||--|| WEIGHT_PROFILE : uses
    CASE ||--|{ DOMAIN_SCORE : contains
    CASE }|--|| COUNTRY : targets
    CASE }|--|| SECTOR : targets

    DOMAIN_SCORE ||--|{ INDICATOR_VALUE : aggregates
    DOMAIN_SCORE ||--|{ EVIDENCE_ITEM : supported_by

    INDICATOR_VALUE }|--|| INDICATOR_DEF : instance_of
    INDICATOR_VALUE }|--|| SOURCE : from

    INDICATOR_DEF ||--|| DOMAIN : maps_to
    EVIDENCE_ITEM }|--|| EVIDENCE_SOURCE : from
```

## Entity Definitions
1.  **Case:** A unique analysis instance (e.g., "Mexico - EV OEM - 2026").
2.  **Weight Profile:** A configuration of domain weights (e.g., "Standard EV Profile v1").
3.  **Domain:** The 8 fixed categories (A1-A8).
4.  **Indicator Definition:** The metadata of a metric (Name, ID, Unit, Transformation).
5.  **Indicator Value:** The actual number for a specific country/year (e.g., "65.4" for Mexico Reg Quality 2024).
6.  **Evidence Item:** A text bullet point with a citation.
7.  **Source:** A dataset or report provider (e.g., "World Bank").

# Clarum — Data Quality Flags

## Source Flags
- **FLAG-OFFICIAL:** Direct from gov't or multilateral (Tier A).
- **FLAG-PROXY:** Indicator is an adjacent proxy (e.g., using "General Infrastructure" for "Industrial Grid").
- **FLAG-STALE:** Data > 2 years old.
- **FLAG-ESTIMATE:** Modelled/Imputed data, not observed.

## Confidence Calculation
*Algorithm Logic:*
1.  Start at **100%**.
2.  Subtract **10%** for each missing "Critical" indicator.
3.  Subtract **5%** for each "Stale" indicator.
4.  If Result > 80% -> **High**.
5.  If Result > 50% -> **Medium**.
6.  Else -> **Low**.

# Clarum — Taxonomies

## Regions / Countries (ISO 3166)
*MVP Starter Set*
- **MX:** Mexico
- **VN:** Vietnam
- **IN:** India
- **ID:** Indonesia
- **PL:** Poland
- **HU:** Hungary (Control)
- **MA:** Morocco (Control)

## Sectors
- **SEC-EV-OEM:** Electric Vehicle Assembly (Passenger)
- **SEC-BATT-CELL:** Battery Cell Manufacturing
- **SEC-BATT-MAT:** Battery Cathode/Anode Processing
- **SEC-SEMI-OSAT:** Semiconductor Assembly, Test, Packaging
- **SEC-SEMI-FAB:** Semiconductor Fabrication (Legacy/Analog)

## Roles (Value Chain)
- **ROLE-UPSTREAM:** Extraction / Raw Processing
- **ROLE-MIDSTREAM:** Component Mfg
- **ROLE-DOWNSTREAM:** Assembly / Integration
- **ROLE-SERVICES:** R&D / Logistics

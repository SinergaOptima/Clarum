# Versioning & Changelog Process

## Semantic Versioning for Risk Models
- **v1.0.0:** Major Ontology Change (e.g., adding A9 Domain). *Breaks backward compatibility.*
- **v1.1.0:** Indicator Swap (e.g., changing source for A1.1). *Scores may shift slightly.*
- **v1.1.1:** Data Refresh (New year data). *Scores update, logic stays.*

## Changelog Policy
- Every Dossier must cite the Model Version (e.g., `LRF-1.2`).
- A "Methodology Note" must accompany any v1.x -> v1.y update explaining the shift.

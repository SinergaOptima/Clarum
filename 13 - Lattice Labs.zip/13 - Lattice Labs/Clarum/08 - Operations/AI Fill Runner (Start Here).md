# AI Fill Runner v0 (Start Here)

AI Fill Runner applies deterministic plan-driven updates to country packs, enforces Tier B allowlist checks, runs strict validation, regenerates reports, rebuilds site_export, and writes a runlog.

## Workflow
1) Scaffold a plan
```
python "08 - Operations/fill_runner/fill_runner.py" scaffold-plan \
  --country HUN \
  --domains A6,A8 \
  --pack "04 - Data & Ontology/Ontology/_machine/country_packs/hungary.v1.yaml" \
  --out "04 - Data & Ontology/Ontology/_machine/plans/hun_a6_a8.plan.v1.json"
```

2) Fill the plan with values + sources (AI or human).

3) Validate the plan
```
python "08 - Operations/fill_runner/fill_runner.py" validate-plan --plan "04 - Data & Ontology/Ontology/_machine/plans/hun_a6_a8.plan.v1.json"
```

4) Apply (dry-run)
```
python "08 - Operations/fill_runner/fill_runner.py" apply --plan "04 - Data & Ontology/Ontology/_machine/plans/hun_a6_a8.plan.v1.json" --dry-run
```

5) Apply (live run)
```
python "08 - Operations/fill_runner/fill_runner.py" apply --plan "04 - Data & Ontology/Ontology/_machine/plans/hun_a6_a8.plan.v1.json"
```

## Tier B allowlist enforcement
If any update sets `evidence_tier: B`, the runner checks `TIERB_ALLOWLIST.v1.json`.
If tokens/domains are missing, the run fails with a suggested allowlist entry.

## Plan schema + defaults
- Schema: `08 - Operations/fill_runner/plan_schema.v1.json`
- Default report jobs: `08 - Operations/fill_runner/default_report_jobs.v1.json`

## Notes
- ruamel.yaml is required for safe round-trip edits: `pip install ruamel.yaml`
- Runner stops on any strict validation failure.

# Research Workflow

## Phase 1: Ingestion
1.  **Trigger:** New Country/Sector requested.
2.  **Action:** Run `ingest_tier_a.py`.
3.  **Output:** Raw CSVs in `/data/raw`.

## Phase 2: Synthesis & Scoring
1.  **Analyst:** Review missing data flags.
2.  **System:** Run RAG pipeline for qualitative context.
3.  **Analyst:** Review "Draft Scores".
    - *Check:* Does the score match the evidence?
    - *Check:* Are there contradictions?

## Phase 3: Publication
1.  **Action:** "Approve" dossier.
2.  **System:** Lock version hash.
3.  **Output:** Generate PDF + JSON.

## Phase 4: Monitoring
1.  **Trigger:** Quarterly update or Major Event.
2.  **Action:** Create "Delta Report" (What changed?).

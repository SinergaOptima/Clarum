# Clarum - NEW CHAT HANDOFF (Start Here)

## What Clarum is
Clarum is a vault-first risk-intelligence system that validates country packs, generates deterministic report artifacts, and publishes a site_export bundle consumed by the website.

## Architecture (vault to web)
Vault data -> _machine reports -> site_export/v1 bundle -> website loader reads real-data mode.

## Track status
- Export + domestic tracks are wired; unified report index exists; real-data mode site_export.v1 is in use.

## Completed sprints (latest first)
- Sprint 15.2A (DONE): A8 ESG consistency + evidence hygiene checks completed for HU/MX/MYS. Pack sanity confirmed `IND-A8-ESG-001` + `IND-A8-ESG-002` presence/values/unit/tier; report+memos sanity confirmed across all 6 HU/MX/MY report tracks; warn-only A8 contract guardrail added in pack validator; strict healthcheck remains clean. Healthcheck runlog: 08 - Operations/fill_runner/runlogs/fill_runner_healthcheck_2026-02-11_2247.txt
- Sprint 15.1 (DONE): EPI automated adapter (`yale_epi`) now runs cache-only with ordered URL candidates + optional override, robust CSV/XLSX parsing, and scoped apply for HU/MX/MY on `IND-A8-ESG-002`; reports+memos regenerated; site_export validated. Plan: `08 - Operations/fill_runner/examples/plan.adapters.fill_hu_mx_my_epi_auto_v1.json`. Runlog: 04 - Data & Ontology/Ontology/_machine/runlogs/fill_runner_HUN_2026-02-11_2215.txt
- Sprint 15.0A (DONE): CPI automated adapter (`ti_cpi`) now runs cache-only with ordered URL candidates (no snapshot requirement), robust CSV/XLSX parsing, and scoped apply for HU/MX/MY on `IND-A8-ESG-001`; reports+memos regenerated; site_export validated. Plan: `08 - Operations/fill_runner/examples/plan.adapters.fill_hu_mx_my_cpi_auto_v1.json`. Runlog: 04 - Data & Ontology/Ontology/_machine/runlogs/fill_runner_HUN_2026-02-11_2201.txt
- Sprint 14.3 (DONE): KAOPEN snapshot matching fixed in `chinn_ito` (`ccode`/`cn` support + country-name fallback), snapshot short-circuit path resolved, and HU/MX/MYS fills applied successfully for `IND-A7-CAP-002`; outputs regenerated; site_export validated. Runlog: 04 - Data & Ontology/Ontology/_machine/runlogs/fill_runner_HUN_2026-02-11_2147.txt
- Sprint 14.2: KAOPEN snapshot pipeline + SOP setup complete, but initial scoped apply skipped due to country matching (`kaopen_country_not_found`). Runlog: 04 - Data & Ontology/Ontology/_machine/runlogs/fill_runner_HUN_2026-02-11_2132.txt
- Sprint 14.1: Chinn-Ito live parse hardening; adapter now supports CSV/TSV (wide & long), HTML table, XLSX-zip, and zip-CSV; URL candidates added including OpennessDataR mirror; sniff_payload diagnostic helper added; 15 offline tests pass; live source confirmed as OLE2 .xls (unsupported); snapshot_path strategy recommended. Runlog: 04 - Data & Ontology/Ontology/_machine/runlogs/fill_runner_HUN_2026-02-11_2048.txt
- Sprint 14: Adapter Expansion Pack v1; added 3 new Tier-A adapters (chinn_ito, ti_cpi, yale_epi); registry precedence updated; all 9 adapter tests pass offline; example plan created and validated. Runlog: 04 - Data & Ontology/Ontology/_machine/runlogs/fill_runner_HUN_2026-02-11_2020.txt
- Sprint 13: A6/A8 hardening for HU/MX/MY; Tier B reduced; explicit 0-100 proxy formulas; strict validation still 0 warnings; WB STEM series invalid; GDELT 404; alternatives documented. Runlog: 04 - Data & Ontology/Ontology/_machine/runlogs/flagship_sprint13_a6_a8_hardening_2026-02-11_0410.txt
- Sprint 12.1: strict validation 0 warnings; Tier B warning suppression allowlist; IND-A7-CAP-003 override; reports rerun. Runlog: 04 - Data & Ontology/Ontology/_machine/runlogs/flagship_sprint12_1_strict_warning_cleanup_2026-02-11_1140.txt
- Sprint 12: TODO placeholders removed; Tier B proxies + allowlist; 6 reports; site_export validated. Runlog: 04 - Data & Ontology/Ontology/_machine/runlogs/flagship_sprint12_fill_country_packs_hu_mx_my_2026-02-11_1015.txt

## Fill Runner status
- v0 built (plan schema, safe edits with ruamel.yaml, allowlist checks, runlogs, default_report_jobs).
- v0.1 upgrades: template plan, apply-batch, Enterprise Surveys adapter (4 aliases), memo_spec v1.
- Plan option: run.generate_memos (boolean) runs memo generator per report before site_export; skipped during dry_run.
- scope.indicators: "ALL" expands to the full indicator list from indicator_catalog.v1.json (sorted by ID).
- Adapter fills: optional fills.adapters jobs for cached, deterministic auto-fills (WB/WITS/ITU). Enforced scope guardrails and per-fill runlog provenance.
- Report-only verification plan: 08 - Operations/fill_runner/examples/plan.report_only.verify.v1.json
- Batch export-once: apply-batch --export-once runs multiple plans, then rebuilds+validates site_export once at the end. Use for fill sprints / multiple report-only plans / multi-country updates. If any plan fails, export rebuild is skipped. Memos still generate per plan before the final export.
- Report-only batch plan for export-once testing: 08 - Operations/fill_runner/examples/plan.report_only.verify.b.v1.json
- Location: 08 - Operations/fill_runner/
- Batch runlog: 04 - Data & Ontology/Ontology/_machine/runlogs/fill_runner_batch_2026-02-11_1024.txt

## Memo system status
- Memo Generator v0: rules-based, deterministic, schema validated, optional MD render.
- Memo pipeline v0.1: memos generated for all 6 reports; exported into site_export; report index includes memo_json_path + memo_md_path; validation counts: payloads 3, evidence 24, memos 6 json + 6 md.
- Runlog: 04 - Data & Ontology/Ontology/_machine/runlogs/flagship_memo_pipeline_v0_1_2026-02-11_1455.txt

## Operational rules
- Vault is not a git repo; never use git.
- Strict validation must remain 0 warnings for HU/MX/MY.
- Tier B must be allowlisted; fail early if missing.

## HTTP cache
- Location: 08 - Operations/fill_runner/.cache/http/
- TTL: 30 days default; ttl_days=0 means cache forever.
- Stale-if-error: enabled by default; expired cache can be served if network fails (records stale_used).
- Clear cache: delete 08 - Operations/fill_runner/.cache/http/

## Adapter fills
- Plan section: fills.adapters[] (country_pack, country_iso3, indicator_id, mode=latest, allow_overwrite, expected_evidence_tier).
- Guardrails: indicator must be in scope.indicators (or ALL); Tier B requires allowlist + confidence <= 0.6 + FLAG-TIERB-PRESENT.
- Sources: adapters use http_cache only; no raw network requests.

## WITS hardening
- WITS jobs can set preferred/fallback year and on_http_403 behavior.
- Plan fields (all optional):
  - `preferred_year`: integer - year to try first
  - `fallback_year`: integer - used if preferred fails (empty/no data)
  - `snapshot_path`: string - local JSON/CSV snapshot for offline use
  - `on_http_403`: "skip" | "use_snapshot" | "fail" (default: "skip")
- Behavior for HTTP 403:
  - `skip`: return AdapterSkip with reason "wits_http_403_forbidden"
  - `use_snapshot`: use snapshot if provided, else skip with reason "wits_http_403_snapshot_missing"
  - `fail`: raise exception
- Snapshot workflow:
  - Place snapshots in `08 - Operations/fill_runner/adapters/snapshots/`
  - JSON or CSV format with `year` and `value` columns
  - Compute sha256 for provenance tracking
- All WITS fetches use HTTP cache; runlogs include provenance + skip reason codes.
- Example plan: `08 - Operations/fill_runner/examples/plan.adapters.wits_snapshot.example.v1.json`

## Adapter Expansion Pack v1
- **New adapters added:**
  - `chinn_ito` → IND-A7-CAP-002 (Chinn-Ito KAOPEN capital account openness index)
  - `ti_cpi` → IND-A8-ESG-001 (Transparency International Corruption Perceptions Index)
  - `yale_epi` → IND-A8-ESG-002 (Yale/Columbia Environmental Performance Index)
- **Chinn-Ito live parse hardening (v1.1):**
  - URL candidates: OpennessDataR CSV mirror + pdx.edu .xls/.xlsx/.csv variants
  - Format parsers: CSV/TSV (wide & long), HTML table, XLSX-zip, zip-CSV
  - **Live source diagnosis:** `https://web.pdx.edu/~ito/kaopen_2023.xls` is OLE2 .xls (magic bytes `D0 CF 11 E0...`) — cannot parse with stdlib
  - OpennessDataR mirror (`graebnerc.github.io/OpennessDataR`) uses numeric country codes and only extends to 2019
  - **Recommended path:** Use `snapshot_path` with a pre-exported CSV snapshot of the latest KAOPEN values
  - `sniff_payload()` helper added for diagnostics (debug_sniff option)
- **Note:** CPI and EPI adapters are both validated for cache-only automated applies (Sprint 15.0A and Sprint 15.1).
- **Registry precedence:** Specialized Tier-A adapters (ChinnIto, TransparencyCpi, YaleEpi) now precede WorldBankAdapter to ensure correct indicator mapping.
- **Example plans:**
  - `08 - Operations/fill_runner/examples/plan.adapters.fill_hu_mx_my_adapter_expansion_v1.json`
  - `08 - Operations/fill_runner/examples/plan.adapters.fill_hu_mx_my_chinn_ito_livefix_v1_1.json` (debug_sniff enabled)
- **Exact commands to rerun:**
  ```bash
  # Unit tests (all 15 pass offline)
  python -m unittest "08 - Operations/fill_runner/adapters/tests/test_adapters_smoke.py"
  
  # Validate plan
  python "08 - Operations/fill_runner/fill_runner.py" validate-plan --plan "08 - Operations/fill_runner/examples/plan.adapters.fill_hu_mx_my_chinn_ito_livefix_v1_1.json"
  
  # Apply plan
  python "08 - Operations/fill_runner/fill_runner.py" apply --plan "08 - Operations/fill_runner/examples/plan.adapters.fill_hu_mx_my_chinn_ito_livefix_v1_1.json"
  ```
- **Scope confirmation:** Plan only touches IND-A7-CAP-002 for HU/MX/MY packs; no other indicators modified.

## Sprint 14.2 - KAOPEN snapshot workflow (SOP)
- Status: SOP complete; initial apply skipped due country matching (resolved in Sprint 14.3).
- Canonical KAOPEN source is OLE2 `.xls` and is not parseable with Python stdlib; snapshot workflow is required.
- Snapshot location: `08 - Operations/fill_runner/adapters/snapshots/kaopen_2023_export.csv`
- Refresh snapshot:
  - Open `kaopen_2023.xls` in Excel or LibreOffice.
  - Export/Save As `CSV UTF-8`.
  - Save as `kaopen_2023_export.csv` and replace the file at the snapshot location above.
- Plan path: `08 - Operations/fill_runner/examples/plan.adapters.fill_hu_mx_my_kaopen_snapshot_v1_2.json`
- Rerun commands:
  ```bash
  python "08 - Operations/fill_runner/fill_runner.py" validate-plan --plan "08 - Operations/fill_runner/examples/plan.adapters.fill_hu_mx_my_kaopen_snapshot_v1_2.json"
  python "08 - Operations/fill_runner/fill_runner.py" apply --plan "08 - Operations/fill_runner/examples/plan.adapters.fill_hu_mx_my_kaopen_snapshot_v1_2.json"
  ```

## Sprint 14.3 - KAOPEN snapshot matching fix
- Status: DONE.
- Snapshot path used: `08 - Operations/fill_runner/adapters/snapshots/kaopen_2023_export.csv`
- Identifier matching rule (in order):
  - Match by `ccode`/ISO3 headers first.
  - Else match by `cn` headers using `ISO3_TO_CN` fallback mapping (currently HUN=944, MEX=273, MYS=548).
  - Else match by country name aliases.
- KAOPEN README convention used by adapter logic:
  - `ccode` = ISO Alpha-3 code.
  - `cn` = IMF-World Bank three-digit code.
- Scoped plan rerun: `08 - Operations/fill_runner/examples/plan.adapters.fill_hu_mx_my_kaopen_snapshot_v1_2.json`
- Result: no skips for HU/MX/MYS on `IND-A7-CAP-002`; values applied from snapshot with latest year 2023; reports/memos regenerated; site_export validated.

## Sprint 15.0A - CPI automated adapter (cache-only)
- Status: DONE.
- Indicator scope: `IND-A8-ESG-001` only.
- Plan path: `08 - Operations/fill_runner/examples/plan.adapters.fill_hu_mx_my_cpi_auto_v1.json`
- Commands:
  ```bash
  python "08 - Operations/fill_runner/fill_runner.py" validate-plan --plan "08 - Operations/fill_runner/examples/plan.adapters.fill_hu_mx_my_cpi_auto_v1.json"
  python "08 - Operations/fill_runner/fill_runner.py" apply --plan "08 - Operations/fill_runner/examples/plan.adapters.fill_hu_mx_my_cpi_auto_v1.json"
  ```
- Candidate URL strategy (ordered, deterministic):
  - `https://www.transparency.org/en/cpi/2024`
  - `https://images.transparencycdn.org/images/CPI2024_GlobalTables.xlsx`
  - `https://raw.githubusercontent.com/datasets/corruption-perceptions-index/main/data/cpi.csv`
  - Optional per-plan override: `options.source_url_override` (still cache-only via `http_cache.fetch_bytes`)
- Failure mode:
  - `cpi_source_unavailable` => update candidate list and/or pass `source_url_override` in plan options.
- Apply result:
  - No CPI skips for HU/MX/MYS.
  - `IND-A8-ESG-001` applied for `hungary.v1.yaml`, `mexico.v1.yaml`, `malaysia.v1.yaml`.
  - Outputs regenerated (reports + memos) and site_export validated.

## Sprint 15.1 - EPI automated adapter (cache-only)
- Status: DONE.
- Indicator scope: `IND-A8-ESG-002` only.
- Plan path: `08 - Operations/fill_runner/examples/plan.adapters.fill_hu_mx_my_epi_auto_v1.json`
- Commands:
  ```bash
  python "08 - Operations/fill_runner/fill_runner.py" validate-plan --plan "08 - Operations/fill_runner/examples/plan.adapters.fill_hu_mx_my_epi_auto_v1.json"
  python "08 - Operations/fill_runner/fill_runner.py" apply --plan "08 - Operations/fill_runner/examples/plan.adapters.fill_hu_mx_my_epi_auto_v1.json"
  ```
- Candidate URL strategy (ordered, deterministic):
  - `https://epi.yale.edu/downloads/epi2024results.csv`
  - `https://epi.yale.edu/downloads/epi2024results.xlsx`
  - `https://raw.githubusercontent.com/YaleEPI/environmental-performance-index/main/data/epi_2024.csv`
  - Optional per-plan override: `options.source_url_override` (cache-only via `http_cache.fetch_bytes`)
- Failure modes:
  - `epi_source_unavailable` => update candidates and/or pass `source_url_override` in plan options.
  - `epi_landing_page_html` => replace landing-page URL with direct dataset URL.
  - `epi_score_column_ambiguous` => adjust score-column selection rules for the encountered schema.
- Apply result:
  - No EPI skips for HU/MX/MYS.
  - `IND-A8-ESG-002` applied for `hungary.v1.yaml`, `mexico.v1.yaml`, `malaysia.v1.yaml`.
  - Outputs regenerated (reports + memos) and site_export validated.

## Sprint 15.2A - A8 ESG consistency + evidence hygiene
- Status: DONE.
- Scope: verification + guardrails only (vault-only, no out-of-scope pack edits).
- Pack sanity (HU/MX/MYS):
  - `IND-A8-ESG-001` and `IND-A8-ESG-002` present in all three packs.
  - Values are numeric and in 0-100 range; unit is `Score (0-100)`; tier is `A`.
  - Year is currently represented in indicator notes (pack schema does not require explicit `period`/`confidence` fields).
- Report + memo sanity:
  - Report index: `09 - Publishing/site_export/v1/index/index.reports.v1.json`
  - All 6 HU/MX/MY report JSONs contain both A8 indicators.
  - All linked memo JSON files exist.
- Guardrail added (warn-only):
  - File: `08 - Operations/scripts/validate_country_pack.py`
  - Contract checks for `IND-A8-ESG-001` and `IND-A8-ESG-002`:
    - warn if `evidence_tier != A`
    - warn if `unit != Score (0-100)`
    - warn if missing period signal (no int `period` and no year hint in `notes`)
- Validation run:
  - `python "08 - Operations/fill_runner/fill_runner.py" healthcheck --packs --strict-validate`
  - Runlog: `08 - Operations/fill_runner/runlogs/fill_runner_healthcheck_2026-02-11_2247.txt`
  - Result: PASS (strict validation OK for HU/MX/MYS; site_export validation pass).

## A8 ESG Adapter Contract (CPI/EPI)
- unit: `Score (0-100)`
- range: `0-100` (EPI allows 0-1 input scaling to 0-100 when clearly detected)
- evidence_tier: `A`
- confidence: default `0.85` (adapter-level)
- period: required int year at adapter result level
- EPI year rule: year column preferred; URL-year hint fallback allowed; otherwise `epi_missing_year`
- Deterministic fetch: `http_cache` only; optional `options.source_url_override`

## Current Status / Ready for next chat
- HTTP cache + adapters pipeline: WORKING - all 15 tests pass
- Healthcheck: WORKING - strict validation 0 warnings for HU/MX/MY
- Export-once batching: WORKING - batch runlogs generated correctly
- WITS hardening: COMPLETE
  - Schema updated with preferred_year, fallback_year, snapshot_path, on_http_403
  - WITS adapter handles year selection, snapshot mode, 403 classification
  - Fill runner passes job options and logs skip reasons
  - Snapshot folder + README in place
  - Tests cover preferred/fallback year, 403 skip, 403 use_snapshot
- Adapter Expansion Pack v1: COMPLETE
  - 3 new Tier-A adapters: chinn_ito, ti_cpi, yale_epi
  - Registry precedence updated (specialized adapters before WorldBankAdapter)
  - All tests pass with mocked transport
  - Example plan created and validated
- CPI automation (Sprint 15.0A): COMPLETE
  - Adapter is cache-only in automated mode (no manual snapshot blocker)
  - Candidate failover + CSV/XLSX parsing in place
  - Scoped CPI plan applied for HU/MX/MYS on `IND-A8-ESG-001`
  - Runlog: `04 - Data & Ontology/Ontology/_machine/runlogs/fill_runner_HUN_2026-02-11_2201.txt`
- EPI automation (Sprint 15.1): COMPLETE
  - Adapter is cache-only in automated mode (no snapshot requirement)
  - Candidate failover + CSV/XLSX parsing + landing-page skip handling in place
  - Scoped EPI plan applied for HU/MX/MYS on `IND-A8-ESG-002`
  - Runlog: `04 - Data & Ontology/Ontology/_machine/runlogs/fill_runner_HUN_2026-02-11_2215.txt`
- A8 ESG consistency + hygiene (Sprint 15.2A): COMPLETE
  - Pack-level A8 sanity verified for HU/MX/MYS (`IND-A8-ESG-001`, `IND-A8-ESG-002`)
  - Site export report+memos sanity verified across 6 HU/MX/MY tracks
  - Warn-only A8 contract guardrail added to `validate_country_pack.py`
  - Strict healthcheck remains clean; runlog: `08 - Operations/fill_runner/runlogs/fill_runner_healthcheck_2026-02-11_2247.txt`
- Chinn-Ito live parse hardening: COMPLETE (with OLE2 limitation)
  - URL candidates + multi-format parsers implemented
  - Live source confirmed OLE2; snapshot_path strategy recommended
  - Sprint 14.2: snapshot CSV + plan workflow in place; initial apply skipped on country matching.
  - Sprint 14.3: matching fixed for `ccode`/`cn`; scoped apply successful. Runlog: `04 - Data & Ontology/Ontology/_machine/runlogs/fill_runner_HUN_2026-02-11_2147.txt`

## Determinism & provenance
- Cache key is deterministic (method + normalized URL + headers).
- Runlogs include per-fill URL, sha256, cache_hit, and stale_used for audit.

## Most important file paths
- Country packs: 04 - Data & Ontology/Ontology/_machine/country_packs/*.v1.yaml
- Report outputs: 04 - Data & Ontology/Ontology/_machine/reports/*.report.v1.json
- Site export builder: 09 - Publishing/site_export/build_site_export.py
- Validators: 08 - Operations/scripts/validate_country_pack.py, 09 - Publishing/site_export/validate_site_export.py
- Fill Runner entry: 08 - Operations/fill_runner/fill_runner.py
- Memo generator entry: 08 - Operations/fill_runner/memo_generator/generate_memo.py
- Default jobs: 08 - Operations/fill_runner/default_report_jobs.v1.json
- Plan schema: 08 - Operations/fill_runner/plan_schema.v1.json
- Memo spec: 08 - Operations/fill_runner/memo_spec.v1.json
- Runlogs folder: 04 - Data & Ontology/Ontology/_machine/runlogs/

## Exact commands (quick list)
Site export build + validate:
```
python "09 - Publishing/site_export/build_site_export.py"
python "09 - Publishing/site_export/validate_site_export.py"
```
Healthcheck (packs + strict validate):
```
python "08 - Operations/fill_runner/fill_runner.py" healthcheck --packs --strict-validate
```
Healthcheck (report-only + export-once):
```
python "08 - Operations/fill_runner/fill_runner.py" healthcheck --run-report-only --export-once --json
```
Fill Runner scaffold/apply/apply-batch:
```
python "08 - Operations/fill_runner/fill_runner.py" scaffold-plan --country HUN --domains A6,A8 --pack "04 - Data & Ontology/Ontology/_machine/country_packs/hungary.v1.yaml" --out "04 - Data & Ontology/Ontology/_machine/plans/hun_a6_a8.plan.v1.json"
python "08 - Operations/fill_runner/fill_runner.py" apply --plan "04 - Data & Ontology/Ontology/_machine/plans/hun_a6_a8.plan.v1.json"
python "08 - Operations/fill_runner/fill_runner.py" apply-batch --dir "04 - Data & Ontology/Ontology/_machine/plans" --pattern "*.plan.v1.json"
```
Adapter fill plan example:
```
python "08 - Operations/fill_runner/fill_runner.py" apply --plan "08 - Operations/fill_runner/examples/plan.adapters.fill_minimal_hu_mx_my.v1.json"
```
Memo generator run + smoke test:
```
python "08 - Operations/fill_runner/memo_generator/generate_memo.py" --report "04 - Data & Ontology/Ontology/_machine/reports/hungary.ev_oem_export.wp-ev-oem-export-1.1.balanced.report.v1.json"
python -m unittest "08 - Operations/fill_runner/tests/test_generate_memo_smoke.py"
```
Report-only pipeline verification:
```
python "08 - Operations/fill_runner/fill_runner.py" apply --plan "08 - Operations/fill_runner/examples/plan.report_only.verify.v1.json"
```
Batch export-once dry-run:
```
python "08 - Operations/fill_runner/fill_runner.py" apply-batch --dir "08 - Operations/fill_runner/examples" --pattern "plan.report_only.verify*.v1.json" --dry-run --export-once
```
Batch export-once real run:
```
python "08 - Operations/fill_runner/fill_runner.py" apply-batch --dir "08 - Operations/fill_runner/examples" --pattern "plan.report_only.verify*.v1.json" --export-once
```

## Known issues / network issues
- WB SE.TER.GRAD.SCI.ZS invalid (workaround documented in Sprint 13 notes).
- GDELT API 404; documented proxies used.

## Healthcheck
- What it checks: pack header + parse scan, optional strict validation, optional report-only pipeline runs, site_export validation.
- Never edits packs; report-only plans regenerate reports + memos + export.

## Next milestones (big picture)
- Sprint 15.2B NEXT (manual website check): confirm dossiers surface CPI/EPI cleanly; only then consider a GLM 5 website prompt.
- Add Memo tab to website (if not already implemented) and sync site_export.
- Add 1-2 more adapters (WITS/Comtrade, dataset file adapter).
- Add Memo Writer v0.1 (optional LLM mode) with strict citation rules.
- Scale to +5 new countries using batch plans.
- Add refresh cadence + batch rerun pipeline.

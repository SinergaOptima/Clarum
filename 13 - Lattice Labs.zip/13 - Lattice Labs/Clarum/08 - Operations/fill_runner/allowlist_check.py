from __future__ import annotations

from pathlib import Path

from utils import load_json, url_domains


def _allowlist_path(project_root: Path) -> Path:
    return project_root / "04 - Data & Ontology" / "Ontology" / "_machine" / "TIERB_ALLOWLIST.v1.json"


def _skeleton_entry(indicator_id: str, source_institution: str, domains: list[str]) -> str:
    tokens = [source_institution]
    domains_list = domains or ["example.org"]
    return (
        "{\n"
        f"  \"{indicator_id}\": {{\n"
        f"    \"allowed_source_institution_tokens\": {tokens},\n"
        f"    \"allowed_url_domains\": {domains_list},\n"
        "    \"required_any\": [\"source_institution_token\", \"url_domain\"],\n"
        "    \"notes\": \"Tier B allowlist entry (fill_runner)\"\n"
        "  }\n"
        "}"
    )


def check_tierb_allowlist(project_root: Path, updates: list[dict]):
    allowlist_path = _allowlist_path(project_root)
    payload = load_json(allowlist_path)
    indicators = payload.get("indicators", {}) if isinstance(payload, dict) else {}

    for update in updates:
        set_block = update.get("set", {})
        indicator_id = update.get("indicator_id")
        evidence_tier = set_block.get("evidence_tier", "A")
        if evidence_tier != "B":
            continue

        entry = indicators.get(indicator_id)
        if not entry:
            skeleton = _skeleton_entry(
                indicator_id,
                set_block.get("source_institution", ""),
                url_domains(set_block.get("url", "")),
            )
            raise RuntimeError(
                "Tier B allowlist missing for indicator: "
                f"{indicator_id}. Add to TIERB_ALLOWLIST.v1.json.\nSuggested entry:\n{skeletal}"
                .replace("{skeletal}", skeleton)
            )

        tokens = entry.get("allowed_source_institution_tokens", [])
        domains = entry.get("allowed_url_domains", [])
        required_any = entry.get("required_any") or ["source_institution_token", "url_domain"]

        source = set_block.get("source_institution", "") or ""
        source_lower = source.lower()
        source_ok = any(
            isinstance(token, str) and token.lower() in source_lower for token in tokens
        )

        url_value = set_block.get("url", "") or ""
        url_domains_used = url_domains(url_value)
        domain_ok = any(domain in {d.lower() for d in domains} for domain in url_domains_used)

        required_ok = False
        if "source_institution_token" in required_any and source_ok:
            required_ok = True
        if "url_domain" in required_any and domain_ok:
            required_ok = True

        if not required_ok:
            skeleton = _skeleton_entry(indicator_id, source, url_domains_used)
            raise RuntimeError(
                "Tier B allowlist mismatch for indicator: "
                f"{indicator_id}.\n"
                f"source_institution='{source}'\n"
                f"url_domains={url_domains_used or ['missing']}\n"
                f"allowed_tokens={tokens}\n"
                f"allowed_domains={domains}\n"
                f"Suggested entry:\n{skeleton}"
            )

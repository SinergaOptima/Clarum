import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from adapters.enterprise_surveys import EnterpriseSurveysAdapter


class EnterpriseSurveysAdapterTests(unittest.TestCase):
    def setUp(self):
        self.adapter = EnterpriseSurveysAdapter()

    def test_alias_resolution(self):
        code, definition = self.adapter._resolve_indicator(
            "inadequately_educated_workforce_major_constraint_pct"
        )
        self.assertEqual(code, "IC.FRM.WRKF.WK10")
        self.assertIn("inadequately educated workforce", definition)

    def test_unreachable_error_includes_url(self):
        url = self.adapter._build_url("XXX", "IC.FRM.WRKF.WK10")
        with self.assertRaises(RuntimeError) as context:
            self.adapter._raise_unreachable([url])
        self.assertIn(url, str(context.exception))


if __name__ == "__main__":
    unittest.main()

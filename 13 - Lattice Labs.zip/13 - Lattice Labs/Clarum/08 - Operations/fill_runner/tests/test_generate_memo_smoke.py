import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "memo_generator"))

from generate_memo import build_memo
from memo_validate import validate_memo


class MemoGeneratorSmokeTests(unittest.TestCase):
    def test_build_memo_minimal_report(self):
        report = {
            "meta": {
                "generated_at": "2026-02-11 10:08:25",
                "case": {
                    "case_id": "PD-HUN-EV-OEM-EXPORT-001",
                    "country": "Hungary",
                    "sector": "EV",
                    "role": "OEM",
                    "mode": "EXPORT",
                },
                "methodology": {
                    "weight_profile_id": "WP-EV-OEM-EXPORT-1.1",
                    "overlay_id": "Balanced",
                },
            },
            "completeness": {
                "overall_pct": 80,
                "by_domain": {"A1": 80, "A2": 70},
            },
            "confidence": {"overall_cap": "high"},
            "indicators": {},
        }

        with tempfile.TemporaryDirectory() as temp_dir:
            project_root = Path(temp_dir)
            report_path = project_root / "reports" / "example.report.v1.json"

            memo = build_memo(report, report_path, project_root)
            errors = validate_memo(memo)

        self.assertEqual(errors, [])


if __name__ == "__main__":
    unittest.main()

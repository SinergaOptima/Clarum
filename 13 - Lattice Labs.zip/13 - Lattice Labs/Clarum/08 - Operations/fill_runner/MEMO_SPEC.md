# Memo Spec v1 (Narrative Layer)

This spec defines a structured, citation-forward memo layer that references deterministic report artifacts and evidence. It is not a scoring system and must not introduce uncited claims.

## Purpose
- Summarize dossier findings in a structured, auditable format.
- Tie every claim to evidence references and report artifacts.
- Keep uncertainty explicit with confidence and data quality flags.

## Mapping guidance
- `case.report_artifact_path` points to a report JSON in `_machine/reports`.
- `key_findings[*].evidence_refs` should map to evidence IDs or file paths used in the report.
- `risk_register[*].domain` should be one of A1–A8 and aligned with report domain findings.
- `data_quality.completeness_pct` should reflect report completeness (if available).
- `data_quality.tier_b_present` should be true if report flags Tier B evidence.

## Guardrails
- No uncited assertions. Every claim must have evidence references.
- Use uncertainty-aware language; confidence must be between 0 and 1.
- This spec does not perform scoring; it consumes existing artifacts.

## Files
- Schema: `08 - Operations/fill_runner/memo_spec.v1.json`

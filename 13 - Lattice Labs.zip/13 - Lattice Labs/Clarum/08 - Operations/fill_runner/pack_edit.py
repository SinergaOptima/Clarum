from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from utils import ensure


@dataclass
class FieldChange:
    indicator_id: str
    field: str
    before: Any
    after: Any


FIELD_ORDER = [
    "value",
    "unit",
    "source_institution",
    "url",
    "retrieved_date",
    "notes",
    "evidence_tier",
    "confidence",
]


def _load_ruamel():
    try:
        from ruamel.yaml import YAML
    except Exception as exc:  # pragma: no cover - deterministic failure
        raise RuntimeError(
            "ruamel.yaml is required for safe round-trip edits. Install with: pip install ruamel.yaml"
        ) from exc
    return YAML


def _insert_in_order(mapping, key: str, value: Any):
    if key in mapping:
        mapping[key] = value
        return

    last_index = None
    for idx, existing_key in enumerate(list(mapping.keys())):
        if existing_key in FIELD_ORDER:
            last_index = idx
    if last_index is None:
        mapping[key] = value
        return

    mapping.insert(last_index + 1, key, value)


def _append_year_note(notes: str, year: int | None) -> str:
    if year is None:
        return notes
    suffix = f" year {int(year)}."
    if "year" in notes.lower():
        return notes
    return notes.rstrip() + suffix


def load_pack(pack_path: Path):
    YAML = _load_ruamel()
    yaml = YAML(typ="rt")
    yaml.preserve_quotes = True
    yaml.width = 4096
    yaml.indent(mapping=2, sequence=4, offset=2)

    raw_text = pack_path.read_text(encoding="utf-8")
    data = yaml.load(raw_text)
    return data, yaml, raw_text


def apply_updates(pack_path: Path, updates: list[dict], dry_run: bool) -> list[FieldChange]:
    data, yaml, raw_text = load_pack(pack_path)
    indicators = data.get("indicators")
    ensure(isinstance(indicators, dict), "Pack is missing indicators object.")

    changes: list[FieldChange] = []
    for update in updates:
        ind_id = update["indicator_id"]
        set_block = update["set"]
        entry = indicators.get(ind_id)
        ensure(entry is not None, f"Indicator not found in pack: {ind_id}")

        for key, value in set_block.items():
            if key == "year":
                continue
            if key not in (
                "value",
                "unit",
                "retrieved_date",
                "url",
                "source_institution",
                "notes",
                "evidence_tier",
                "confidence",
            ):
                continue
            before = entry.get(key)
            if key == "notes":
                value = _append_year_note(value or "", set_block.get("year"))
            if before != value:
                changes.append(FieldChange(ind_id, key, before, value))
            _insert_in_order(entry, key, value)

    if dry_run:
        return changes

    if not changes:
        return changes

    if raw_text.lstrip().startswith("{"):
        pack_path.write_text(json.dumps(data, indent=2, ensure_ascii=True) + "\n", encoding="utf-8")
    else:
        with pack_path.open("w", encoding="utf-8") as handle:
            yaml.dump(data, handle)

    return changes

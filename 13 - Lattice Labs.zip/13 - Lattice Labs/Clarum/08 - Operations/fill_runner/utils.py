import json
import os
import sys
import urllib.parse
from datetime import datetime
from pathlib import Path


def load_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def now_iso() -> str:
    return datetime.now().isoformat(timespec="seconds")


def now_stamp() -> str:
    return datetime.now().strftime("%Y-%m-%d_%H%M")


def project_root() -> Path:
    return Path(__file__).resolve().parents[2]


def normalize_path(path_value: str) -> Path:
    path = Path(path_value)
    return path if path.is_absolute() else (project_root() / path).resolve()


def url_domains(url_value: str) -> list[str]:
    if not isinstance(url_value, str) or not url_value:
        return []
    segments = [segment.strip() for segment in url_value.split("|") if segment.strip()]
    domains = []
    for segment in segments:
        parsed = urllib.parse.urlparse(segment)
        if parsed.netloc:
            domains.append(parsed.netloc.lower())
    return domains


def url_domains_summary(url_value: str) -> str:
    domains = url_domains(url_value)
    return ",".join(domains) if domains else "missing"


def run_command(cmd: list[str]) -> tuple[int, str]:
    import subprocess

    proc = subprocess.run(cmd, capture_output=True, text=True)
    output = (proc.stdout or "") + ("\n" + proc.stderr if proc.stderr else "")
    return proc.returncode, output.strip()


def try_git_hash(cwd: Path) -> str | None:
    import subprocess

    try:
        proc = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=str(cwd),
            capture_output=True,
            text=True,
            check=False,
        )
        if proc.returncode != 0:
            return None
        return (proc.stdout or "").strip() or None
    except Exception:
        return None


def ensure(condition: bool, message: str):
    if not condition:
        raise RuntimeError(message)


def log_stdout(message: str):
    sys.stdout.write(message + os.linesep)
    sys.stdout.flush()

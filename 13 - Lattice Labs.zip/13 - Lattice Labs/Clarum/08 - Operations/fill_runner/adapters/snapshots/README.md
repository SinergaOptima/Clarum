# Adapter Snapshots

Use snapshots when upstream sources are unavailable, blocked, or in unsupported formats.

## When to use snapshots

- API returns HTTP 403 (rate limit or block)
- API is temporarily down
- Offline/air-gapped environments
- Reproducible offline runs
- Upstream format unsupported (e.g., OLE2 .xls)

## WITS Snapshots

## Snapshot format

Supported formats:
- JSON: object or list of objects with `year` (or `period`) and `value`
- CSV: headers must include `year` (or `period`) and `value`

Example JSON:
```
{
  "year": 2023,
  "value": 0.08646
}
```

Example CSV:
```
year,value
2022,0.093
2023,0.08646
```

## How to generate a snapshot

1. **Manual export from WITS UI:**
   - Visit https://wits.worldbank.org/
   - Navigate to the indicator and country
   - Export the data as JSON or CSV
   - Save to this folder with a descriptive name (e.g., `wits_a5_sup_001_2023.json`)

2. **Captured API response:**
   - Run the adapter with network enabled
   - Copy the cached response from `08 - Operations/fill_runner/.cache/http/`
   - Or directly capture the API response using curl/browser

## Compute sha256

PowerShell:
```
Get-FileHash "path\to\snapshot.json" -Algorithm SHA256
```

Python one-liner:
```
python -c "import hashlib; print(hashlib.sha256(open('snapshot.json','rb').read()).hexdigest())"
```

## Referencing in plans

Use the snapshot path in a WITS adapter job:
```json
{
  "country_pack": "04 - Data & Ontology/Ontology/_machine/country_packs/hungary.v1.yaml",
  "country_iso3": "HUN",
  "indicator_id": "IND-A5-SUP-001",
  "mode": "latest",
  "allow_overwrite": true,
  "preferred_year": 2023,
  "fallback_year": 2022,
  "on_http_403": "use_snapshot",
  "snapshot_path": "08 - Operations/fill_runner/adapters/snapshots/wits_a5_sup_001_2023.json"
}
```

## Year selection strategy

- **preferred_year**: The year you want to use if available. Set to the most recent expected data year.
- **fallback_year**: Used if preferred_year fails (no data or empty response). Set to a known-good previous year.

Example: For 2024 data collection, set `preferred_year=2023` and `fallback_year=2022`.

## on_http_403 settings

| Value | Behavior |
|-------|----------|
| `skip` (default) | Skip the indicator, record skip reason in runlog |
| `use_snapshot` | Use snapshot if provided, otherwise skip |
| `fail` | Raise an exception, halt the plan |

**Recommended**: Use `use_snapshot` with a snapshot_path for production runs where WITS availability is uncertain.

## Offline mode

If `snapshot_path` is provided and `on_http_403` is NOT set to `use_snapshot`, the adapter will use the snapshot directly without attempting network requests. Use this for fully offline runs.

## Chinn-Ito KAOPEN Snapshots

**Why needed:** The official source (`https://web.pdx.edu/~ito/kaopen_2023.xls`) is in OLE2 .xls format, which cannot be parsed with Python stdlib. A snapshot is the recommended path.

### Snapshot format for KAOPEN

**Wide format (recommended):**
```csv
iso3,kaopen_2021,kaopen_2022,kaopen_2023
HUN,1.23,1.45,1.67
MEX,0.89,0.92,0.95
MYS,1.01,1.12,1.25
```

**Long format (also supported):**
```csv
iso3,year,kaopen
HUN,2023,1.67
MEX,2023,0.95
MYS,2023,1.25
```

**JSON format:**
```json
[
  {"iso3": "HUN", "kaopen_2023": 1.67},
  {"iso3": "MEX", "kaopen_2023": 0.95},
  {"iso3": "MYS", "kaopen_2023": 1.25}
]
```

### How to create a KAOPEN snapshot

1. Open `https://web.pdx.edu/~ito/kaopen_2023.xls` in Excel or LibreOffice
2. Export as CSV (UTF-8)
3. Clean up columns: keep ISO3 column and year columns (e.g., `kaopen_2023`)
4. Save as `kaopen_2023.csv` in this folder

### Referencing in plans

```json
{
  "country_pack": "04 - Data & Ontology/Ontology/_machine/country_packs/hungary.v1.yaml",
  "country_iso3": "HUN",
  "indicator_id": "IND-A7-CAP-002",
  "mode": "latest",
  "allow_overwrite": true,
  "snapshot_path": "08 - Operations/fill_runner/adapters/snapshots/kaopen_2023.csv"
}
```

### Note on OpennessDataR mirror

The adapter tries `https://graebnerc.github.io/OpennessDataR/files/data/openness_data_csv.zip` as a fallback, but this dataset:
- Uses numeric country codes (not ISO3)
- Only extends to 2019 (not 2023)

For 2023 KAOPEN values, a manual snapshot from the official source is required.

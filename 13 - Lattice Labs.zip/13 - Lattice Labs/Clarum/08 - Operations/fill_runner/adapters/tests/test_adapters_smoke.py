import json
import tempfile
import unittest
import zipfile
from io import BytesIO
from pathlib import Path
from unittest.mock import patch

import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from adapters.base import AdapterSkip
from adapters.chinn_ito import ChinnItoAdapter, _KAOPEN_URL_CANDIDATES, sniff_payload
from adapters.itu_idi import ItuIdiAdapter, _IDI_URL
from adapters.transparency_cpi import TransparencyCpiAdapter, _CPI_URL_CANDIDATES
from adapters.wits import WitsAdapter
from adapters.world_bank import WorldBankAdapter
from adapters.yale_epi import YaleEpiAdapter, _EPI_URL_CANDIDATES
from http_cache.http_cache import set_cache_root, set_transport_get


def _build_minimal_xlsx() -> bytes:
    sheet_xml = """
    <worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
      <sheetData>
        <row r="1">
          <c r="A1" t="inlineStr"><is><t>ISO3</t></is></c>
          <c r="B1" t="inlineStr"><is><t>IDI 2023 Score</t></is></c>
        </row>
        <row r="2">
          <c r="A2" t="inlineStr"><is><t>HUN</t></is></c>
          <c r="B2"><v>86.8</v></c>
        </row>
      </sheetData>
    </worksheet>
    """.strip()

    workbook_xml = """
    <workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
      <sheets>
        <sheet name="Sheet1" sheetId="1" r:id="rId1" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"/>
      </sheets>
    </workbook>
    """.strip()

    workbook_rels = """
    <Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
      <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
    </Relationships>
    """.strip()

    content_types = """
    <Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
      <Default Extension="xml" ContentType="application/xml"/>
      <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
      <Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
    </Types>
    """.strip()

    root_rels = """
    <Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
      <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
    </Relationships>
    """.strip()

    buffer = BytesIO()
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("[Content_Types].xml", content_types)
        zf.writestr("_rels/.rels", root_rels)
        zf.writestr("xl/workbook.xml", workbook_xml)
        zf.writestr("xl/_rels/workbook.xml.rels", workbook_rels)
        zf.writestr("xl/worksheets/sheet1.xml", sheet_xml)
    return buffer.getvalue()


def _build_kaopen_xlsx() -> bytes:
    sheet_xml = """
    <worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
      <sheetData>
        <row r="1">
          <c r="A1" t="inlineStr"><is><t>ISO3</t></is></c>
          <c r="B1" t="inlineStr"><is><t>kaopen_2022</t></is></c>
          <c r="C1" t="inlineStr"><is><t>kaopen_2023</t></is></c>
        </row>
        <row r="2">
          <c r="A2" t="inlineStr"><is><t>HUN</t></is></c>
          <c r="B2"><v>1.45</v></c>
          <c r="C2"><v>1.67</v></c>
        </row>
        <row r="3">
          <c r="A3" t="inlineStr"><is><t>MEX</t></is></c>
          <c r="B3"><v>0.92</v></c>
          <c r="C3"><v>0.95</v></c>
        </row>
      </sheetData>
    </worksheet>
    """.strip()

    workbook_xml = """
    <workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
      <sheets>
        <sheet name="Sheet1" sheetId="1" r:id="rId1" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"/>
      </sheets>
    </workbook>
    """.strip()

    workbook_rels = """
    <Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
      <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
    </Relationships>
    """.strip()

    content_types = """
    <Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
      <Default Extension="xml" ContentType="application/xml"/>
      <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
      <Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
    </Types>
    """.strip()

    root_rels = """
    <Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
      <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
    </Relationships>
    """.strip()

    buffer = BytesIO()
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("[Content_Types].xml", content_types)
        zf.writestr("_rels/.rels", root_rels)
        zf.writestr("xl/workbook.xml", workbook_xml)
        zf.writestr("xl/_rels/workbook.xml.rels", workbook_rels)
        zf.writestr("xl/worksheets/sheet1.xml", sheet_xml)
    return buffer.getvalue()


def _build_csv_zip(csv_content: str, filename: str = "openness_data.csv") -> bytes:
    buffer = BytesIO()
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr(filename, csv_content.encode("utf-8"))
    return buffer.getvalue()


class AdapterSmokeTests(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        set_cache_root(Path(self.temp_dir.name))

        wb_url = "https://api.worldbank.org/v2/country/HUN/indicator/EG.ELC.LOSS.ZS?format=json"
        wb_payload = [
            {"page": 1, "pages": 1},
            [
                {"date": "2023", "value": 6.9},
                {"date": "2022", "value": 7.1},
            ],
        ]

        self._wits_sdmx_value = 0.12
        self._wits_response_mode = "ok"
        self._wits_empty_years: set[int] = set()

        itu_bytes = _build_minimal_xlsx()

        responses = {
            wb_url: (
                200,
                {"Content-Type": "application/json"},
                json.dumps(wb_payload).encode("utf-8"),
            ),
            _IDI_URL: (
                200,
                {
                    "Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                },
                itu_bytes,
            ),
        }

        def transport(url: str):
            if "wits.worldbank.org/API/V1/SDMX/V21" in url:
                if self._wits_response_mode == "forbidden":
                    return 403, {"Content-Type": "application/json"}, b"{}"
                import re

                year_match = re.search(r"/year/(\d{4})", url)
                year = int(year_match.group(1)) if year_match else None
                if year and year in self._wits_empty_years:
                    payload = {"dataSets": []}
                    return (
                        200,
                        {"Content-Type": "application/json"},
                        json.dumps(payload).encode("utf-8"),
                    )
                if self._wits_response_mode == "empty":
                    payload = {"dataSets": []}
                    return (
                        200,
                        {"Content-Type": "application/json"},
                        json.dumps(payload).encode("utf-8"),
                    )
                payload = {
                    "dataSets": [
                        {
                            "series": {
                                "0:0:0:0": {
                                    "observations": {"0": [self._wits_sdmx_value]}
                                }
                            }
                        }
                    ]
                }
                return (
                    200,
                    {"Content-Type": "application/json"},
                    json.dumps(payload).encode("utf-8"),
                )
            if url in responses:
                return responses[url]
            raise RuntimeError(f"Unexpected URL in test transport: {url}")

        set_transport_get(transport)

    def tearDown(self):
        set_transport_get(None)
        self.temp_dir.cleanup()

    def test_world_bank_adapter(self):
        adapter = WorldBankAdapter()
        result = adapter.fetch("HUN", "IND-A4-INF-002")
        self.assertEqual(result.evidence_tier, "A")
        self.assertEqual(result.period, "2023")
        self.assertEqual(result.value, 6.9)

    def test_wits_adapter(self):
        adapter = WitsAdapter()
        result = adapter.fetch("HUN", "IND-A5-SUP-001", preferred_year=2023)
        self.assertEqual(result.evidence_tier, "A")
        self.assertAlmostEqual(result.value, 0.12)

    def test_wits_preferred_fallback(self):
        adapter = WitsAdapter()
        self._wits_empty_years = {2022}
        result = adapter.fetch(
            "HUN", "IND-A5-SUP-001", preferred_year=2022, fallback_year=2023
        )
        self.assertEqual(result.period, 2023)
        self.assertIn("fallback year 2023", result.method_note)

    def test_wits_403_skip(self):
        adapter = WitsAdapter()
        self._wits_response_mode = "forbidden"
        result = adapter.fetch(
            "HUN", "IND-A5-SUP-001", preferred_year=2023, on_http_403="skip"
        )
        self.assertIsInstance(result, AdapterSkip)
        self.assertEqual(result.reason, "wits_http_403_forbidden")

    def test_wits_403_use_snapshot(self):
        adapter = WitsAdapter()
        self._wits_response_mode = "forbidden"
        snapshot_path = Path(self.temp_dir.name) / "wits_snapshot.json"
        snapshot_payload = {"year": 2023, "value": 0.33}
        snapshot_path.write_text(json.dumps(snapshot_payload), encoding="utf-8")
        result = adapter.fetch(
            "HUN",
            "IND-A5-SUP-001",
            preferred_year=2023,
            on_http_403="use_snapshot",
            snapshot_path=str(snapshot_path),
        )
        self.assertEqual(result.value, 0.33)
        self.assertTrue(result.sources[0].url.startswith("snapshot:"))

    def test_itu_idi_adapter(self):
        adapter = ItuIdiAdapter()
        result = adapter.fetch("HUN", "IND-A3-POL-002")
        self.assertEqual(result.evidence_tier, "B")
        self.assertAlmostEqual(result.value, 86.8)

    def test_chinn_ito_adapter_tsv_wide(self):
        tsv_content = "ISO3\tcountry\tkaopen_2021\tkaopen_2022\tkaopen_2023\nHUN\tHungary\t1.23\t1.45\t1.67\nMEX\tMexico\t0.89\t0.92\t0.95\nMYS\tMalaysia\t1.01\t1.12\t1.25\n"
        responses = {
            _KAOPEN_URL_CANDIDATES[0]: (
                200,
                {"Content-Type": "text/tab-separated-values"},
                tsv_content.encode("utf-8"),
            )
        }

        def transport(url: str):
            if url in responses:
                return responses[url]
            raise RuntimeError(f"Unexpected URL in test transport: {url}")

        set_transport_get(transport)
        adapter = ChinnItoAdapter()
        result = adapter.fetch("HUN", "IND-A7-CAP-002")
        self.assertEqual(result.evidence_tier, "A")
        self.assertEqual(result.value, 1.67)
        self.assertEqual(result.period, 2023)

    def test_chinn_ito_adapter_csv_long(self):
        csv_content = "iso3,year,kaopen\nHUN,2021,1.23\nHUN,2022,1.45\nHUN,2023,1.67\nMEX,2023,0.95\nMYS,2023,1.25\n"
        responses = {
            _KAOPEN_URL_CANDIDATES[0]: (
                200,
                {"Content-Type": "text/csv"},
                csv_content.encode("utf-8"),
            )
        }

        def transport(url: str):
            if url in responses:
                return responses[url]
            raise RuntimeError(f"Unexpected URL in test transport: {url}")

        set_transport_get(transport)
        adapter = ChinnItoAdapter()
        result = adapter.fetch("HUN", "IND-A7-CAP-002")
        self.assertEqual(result.evidence_tier, "A")
        self.assertEqual(result.value, 1.67)
        self.assertEqual(result.period, 2023)

    def test_chinn_ito_adapter_html_table(self):
        html_content = """<html><body><table>
<tr><th>ISO3</th><th>kaopen_2023</th></tr>
<tr><td>HUN</td><td>1.67</td></tr>
<tr><td>MEX</td><td>0.95</td></tr>
</table></body></html>"""
        responses = {
            _KAOPEN_URL_CANDIDATES[0]: (
                200,
                {"Content-Type": "text/html"},
                html_content.encode("utf-8"),
            )
        }

        def transport(url: str):
            if url in responses:
                return responses[url]
            raise RuntimeError(f"Unexpected URL in test transport: {url}")

        set_transport_get(transport)
        adapter = ChinnItoAdapter()
        result = adapter.fetch("HUN", "IND-A7-CAP-002")
        self.assertEqual(result.evidence_tier, "A")
        self.assertEqual(result.value, 1.67)

    def test_chinn_ito_adapter_xlsx(self):
        xlsx_bytes = _build_kaopen_xlsx()
        responses = {
            _KAOPEN_URL_CANDIDATES[0]: (
                200,
                {
                    "Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                },
                xlsx_bytes,
            )
        }

        def transport(url: str):
            if url in responses:
                return responses[url]
            raise RuntimeError(f"Unexpected URL in test transport: {url}")

        set_transport_get(transport)
        adapter = ChinnItoAdapter()
        result = adapter.fetch("MEX", "IND-A7-CAP-002")
        self.assertEqual(result.evidence_tier, "A")
        self.assertEqual(result.value, 0.95)
        self.assertEqual(result.period, 2023)

    def test_chinn_ito_adapter_zip_csv(self):
        csv_content = "iso3,year,kaopen\nHUN,2023,1.67\nMEX,2023,0.95\nMYS,2023,1.25\n"
        zip_bytes = _build_csv_zip(csv_content)
        responses = {
            _KAOPEN_URL_CANDIDATES[0]: (
                200,
                {"Content-Type": "application/zip"},
                zip_bytes,
            )
        }

        def transport(url: str):
            if url in responses:
                return responses[url]
            raise RuntimeError(f"Unexpected URL in test transport: {url}")

        set_transport_get(transport)
        adapter = ChinnItoAdapter()
        result = adapter.fetch("MYS", "IND-A7-CAP-002")
        self.assertEqual(result.evidence_tier, "A")
        self.assertEqual(result.value, 1.25)

    def test_chinn_ito_snapshot_wide_ccode_headers(self):
        csv_content = (
            "cn,ccode,Country Name,1970,1971,2023\n"
            "944,HUN,Hungary,1.23,1.45,1.67\n"
            "273,MEX,Mexico,0.89,0.92,0.95\n"
            "548,MYS,Malaysia,1.01,1.12,1.25\n"
        )
        snapshot_path = Path(self.temp_dir.name) / "kaopen_wide_ccode.csv"
        snapshot_path.write_text(csv_content, encoding="utf-8")
        adapter = ChinnItoAdapter()

        with patch("adapters.chinn_ito.fetch_bytes") as fetch_mock:
            hun = adapter.fetch("HUN", "IND-A7-CAP-002", snapshot_path=str(snapshot_path))
            mex = adapter.fetch("MEX", "IND-A7-CAP-002", snapshot_path=str(snapshot_path))
            mys = adapter.fetch("MYS", "IND-A7-CAP-002", snapshot_path=str(snapshot_path))
            fetch_mock.assert_not_called()

        self.assertFalse(isinstance(hun, AdapterSkip))
        self.assertEqual(hun.period, 2023)
        self.assertEqual(hun.value, 1.67)
        self.assertFalse(isinstance(mex, AdapterSkip))
        self.assertEqual(mex.period, 2023)
        self.assertEqual(mex.value, 0.95)
        self.assertFalse(isinstance(mys, AdapterSkip))
        self.assertEqual(mys.period, 2023)
        self.assertEqual(mys.value, 1.25)

    def test_chinn_ito_snapshot_wide_cn_only_headers(self):
        csv_content = (
            "cn,Country Name,1970,2023\n"
            "944,Hungary,1.45,1.67\n"
            "273,Mexico,0.92,0.95\n"
            "548,Malaysia,1.12,1.25\n"
        )
        snapshot_path = Path(self.temp_dir.name) / "kaopen_wide_cn_only.csv"
        snapshot_path.write_text(csv_content, encoding="utf-8")
        adapter = ChinnItoAdapter()

        with patch("adapters.chinn_ito.fetch_bytes") as fetch_mock:
            hun = adapter.fetch("HUN", "IND-A7-CAP-002", snapshot_path=str(snapshot_path))
            mex = adapter.fetch("MEX", "IND-A7-CAP-002", snapshot_path=str(snapshot_path))
            mys = adapter.fetch("MYS", "IND-A7-CAP-002", snapshot_path=str(snapshot_path))
            fetch_mock.assert_not_called()

        self.assertFalse(isinstance(hun, AdapterSkip))
        self.assertEqual(hun.period, 2023)
        self.assertEqual(hun.value, 1.67)
        self.assertFalse(isinstance(mex, AdapterSkip))
        self.assertEqual(mex.period, 2023)
        self.assertEqual(mex.value, 0.95)
        self.assertFalse(isinstance(mys, AdapterSkip))
        self.assertEqual(mys.period, 2023)
        self.assertEqual(mys.value, 1.25)

    def test_chinn_ito_adapter_ole2_skip(self):
        ole2_magic = (
            bytes([0xD0, 0xCF, 0x11, 0xE0, 0xA1, 0xB1, 0x1A, 0xE1]) + b"\x00" * 100
        )
        responses = {
            _KAOPEN_URL_CANDIDATES[0]: (
                200,
                {"Content-Type": "application/vnd.ms-excel"},
                ole2_magic,
            )
        }

        def transport(url: str):
            if url in responses:
                return responses[url]
            raise RuntimeError(f"Unexpected URL in test transport: {url}")

        set_transport_get(transport)
        adapter = ChinnItoAdapter()
        result = adapter.fetch("HUN", "IND-A7-CAP-002")
        self.assertIsInstance(result, AdapterSkip)
        self.assertEqual(result.reason, "kaopen_ole2_xls_unsupported")

    def test_sniff_payload(self):
        text_data = b"ISO3,kaopen\nHUN,1.67"
        sniff = sniff_payload(text_data)
        self.assertFalse(sniff["is_zip"])
        self.assertFalse(sniff["is_ole2"])
        self.assertFalse(sniff["is_html"])
        self.assertTrue(sniff["looks_text"])

        ole2_data = (
            bytes([0xD0, 0xCF, 0x11, 0xE0, 0xA1, 0xB1, 0x1A, 0xE1]) + b"\x00" * 24
        )
        sniff = sniff_payload(ole2_data)
        self.assertTrue(sniff["is_ole2"])

        zip_data = b"PK\x03\x04" + b"\x00" * 28
        sniff = sniff_payload(zip_data)
        self.assertTrue(sniff["is_zip"])

    def test_transparency_cpi_adapter_candidate_failover_and_latest_year(self):
        csv_content = (
            "iso3,country,year,cpi_score\n"
            "HUN,Hungary,2023,76\n"
            "HUN,Hungary,2024,77\n"
            "MEX,Mexico,2023,30\n"
            "MEX,Mexico,2024,31\n"
            "MYS,Malaysia,2023,49\n"
            "MYS,Malaysia,2024,50\n"
        )
        calls: list[str] = []

        def transport(url: str):
            calls.append(url)
            if url == _CPI_URL_CANDIDATES[0]:
                return 404, {"Content-Type": "text/plain"}, b"Not Found"
            if url == _CPI_URL_CANDIDATES[1]:
                return 200, {"Content-Type": "text/csv"}, csv_content.encode("utf-8")
            return 404, {"Content-Type": "text/plain"}, b"Not Found"

        set_transport_get(transport)
        adapter = TransparencyCpiAdapter()

        hun = adapter.fetch("HUN", "IND-A8-ESG-001")
        mex = adapter.fetch("MEX", "IND-A8-ESG-001")
        mys = adapter.fetch("MYS", "IND-A8-ESG-001")

        self.assertEqual(hun.evidence_tier, "A")
        self.assertEqual(hun.unit, "Score (0-100)")
        self.assertEqual(hun.period, 2024)
        self.assertEqual(hun.value, 77)

        self.assertEqual(mex.evidence_tier, "A")
        self.assertEqual(mex.unit, "Score (0-100)")
        self.assertEqual(mex.period, 2024)
        self.assertEqual(mex.value, 31)

        self.assertEqual(mys.evidence_tier, "A")
        self.assertEqual(mys.unit, "Score (0-100)")
        self.assertEqual(mys.period, 2024)
        self.assertEqual(mys.value, 50)

        self.assertIn(_CPI_URL_CANDIDATES[0], calls)
        self.assertIn(_CPI_URL_CANDIDATES[1], calls)

    def test_transparency_cpi_adapter_missing_year_skip(self):
        csv_content = "iso3,country,cpi_score\nHUN,Hungary,77\nMEX,Mexico,31\nMYS,Malaysia,50\n"

        def transport(url: str):
            if url == _CPI_URL_CANDIDATES[0]:
                return 404, {"Content-Type": "text/plain"}, b"Not Found"
            if url == _CPI_URL_CANDIDATES[1]:
                return 200, {"Content-Type": "text/csv"}, csv_content.encode("utf-8")
            return 404, {"Content-Type": "text/plain"}, b"Not Found"

        set_transport_get(transport)
        adapter = TransparencyCpiAdapter()
        result = adapter.fetch("HUN", "IND-A8-ESG-001")
        self.assertIsInstance(result, AdapterSkip)
        self.assertEqual(result.reason, "cpi_missing_year")

    def test_yale_epi_adapter_candidate_failover_and_latest_year(self):
        csv_content = (
            "iso3,country,year,overall_score\n"
            "HUN,Hungary,2023,65.2\n"
            "HUN,Hungary,2024,66.4\n"
            "MEX,Mexico,2023,45.8\n"
            "MEX,Mexico,2024,46.2\n"
            "MYS,Malaysia,2023,55.1\n"
            "MYS,Malaysia,2024,56.3\n"
        )
        calls: list[str] = []

        def transport(url: str):
            calls.append(url)
            if url == _EPI_URL_CANDIDATES[0]:
                return 404, {"Content-Type": "text/plain"}, b"Not Found"
            if url == _EPI_URL_CANDIDATES[1]:
                return 200, {"Content-Type": "text/csv"}, csv_content.encode("utf-8")
            return 404, {"Content-Type": "text/plain"}, b"Not Found"

        set_transport_get(transport)
        adapter = YaleEpiAdapter()

        hun = adapter.fetch("HUN", "IND-A8-ESG-002")
        mex = adapter.fetch("MEX", "IND-A8-ESG-002")
        mys = adapter.fetch("MYS", "IND-A8-ESG-002")

        self.assertEqual(hun.evidence_tier, "A")
        self.assertEqual(hun.unit, "Score (0-100)")
        self.assertEqual(hun.period, 2024)
        self.assertEqual(hun.value, 66.4)

        self.assertEqual(mex.evidence_tier, "A")
        self.assertEqual(mex.unit, "Score (0-100)")
        self.assertEqual(mex.period, 2024)
        self.assertEqual(mex.value, 46.2)

        self.assertEqual(mys.evidence_tier, "A")
        self.assertEqual(mys.unit, "Score (0-100)")
        self.assertEqual(mys.period, 2024)
        self.assertEqual(mys.value, 56.3)

        self.assertIn(_EPI_URL_CANDIDATES[0], calls)
        self.assertIn(_EPI_URL_CANDIDATES[1], calls)

    def test_yale_epi_adapter_fractional_scaling(self):
        csv_content = (
            "iso3,country,year,epi_score\n"
            "HUN,Hungary,2024,0.91\n"
            "MEX,Mexico,2024,0.45\n"
            "MYS,Malaysia,2024,0.56\n"
        )

        def transport(url: str):
            if url == _EPI_URL_CANDIDATES[0]:
                return 200, {"Content-Type": "text/csv"}, csv_content.encode("utf-8")
            return 404, {"Content-Type": "text/plain"}, b"Not Found"

        set_transport_get(transport)
        adapter = YaleEpiAdapter()
        result = adapter.fetch("HUN", "IND-A8-ESG-002")
        self.assertEqual(result.period, 2024)
        self.assertEqual(result.unit, "Score (0-100)")
        self.assertAlmostEqual(result.value, 91.0)

    def test_yale_epi_adapter_missing_year_skip(self):
        csv_content = (
            "iso3,country,overall_score\n"
            "HUN,Hungary,66.4\n"
            "MEX,Mexico,46.2\n"
            "MYS,Malaysia,56.3\n"
        )
        override = "https://example.com/epi.csv"

        def transport(url: str):
            if url == override:
                return 200, {"Content-Type": "text/csv"}, csv_content.encode("utf-8")
            return 404, {"Content-Type": "text/plain"}, b"Not Found"

        set_transport_get(transport)
        adapter = YaleEpiAdapter()
        result = adapter.fetch(
            "HUN", "IND-A8-ESG-002", source_url_override=override
        )
        self.assertIsInstance(result, AdapterSkip)
        self.assertEqual(result.reason, "epi_missing_year")

    def test_yale_epi_adapter_landing_page_skip(self):
        override = "https://example.com/epi2024.html"
        html_body = (
            b"<html><head><title>EPI Downloads</title></head>"
            b"<body>Download page</body></html>"
        )

        def transport(url: str):
            if url == override:
                return 200, {"Content-Type": "text/html"}, html_body
            return 404, {"Content-Type": "text/plain"}, b"Not Found"

        set_transport_get(transport)
        adapter = YaleEpiAdapter()
        result = adapter.fetch(
            "MYS", "IND-A8-ESG-002", source_url_override=override
        )
        self.assertIsInstance(result, AdapterSkip)
        self.assertEqual(result.reason, "epi_landing_page_html")


if __name__ == "__main__":
    unittest.main()

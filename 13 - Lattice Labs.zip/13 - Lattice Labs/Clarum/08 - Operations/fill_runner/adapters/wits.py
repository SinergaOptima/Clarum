from __future__ import annotations

import csv
import json
import hashlib
from pathlib import Path
import sys
from typing import Any

from http_cache.http_cache import HttpCacheError

from .base import Adapter, AdapterResult, AdapterSkip, AdapterSource


_SCRIPT_DIR = Path(__file__).resolve().parents[2] / "scripts"
sys.path.insert(0, str(_SCRIPT_DIR))

from wits_helper import (  # noqa: E402
    get_indicator_value_for_year_cached,
    get_indicator_value_latest_cached,
)


class WitsAdapter(Adapter):
    name = "wits"

    _SUPPORTED = {
        "IND-A5-SUP-001": {
            "datasource": "tradestats-trade",
            "indicator_code": "HH-MKT-CNCNTRTN-NDX",
            "unit": "Score (0-1)",
            "name": "TradeStats HH market concentration index",
        }
    }

    def supports(self, indicator_id: str) -> bool:
        return indicator_id in self._SUPPORTED

    def fetch(self, country_iso3: str, indicator_id: str, **kwargs) -> AdapterResult | AdapterSkip:
        if indicator_id not in self._SUPPORTED:
            raise RuntimeError(f"WitsAdapter does not support indicator: {indicator_id}")

        preferred_year = kwargs.get("preferred_year")
        fallback_year = kwargs.get("fallback_year")
        snapshot_path = kwargs.get("snapshot_path")
        on_http_403 = kwargs.get("on_http_403") or "skip"
        snapshot_used = False
        snapshot_fallback_only = bool(snapshot_path and on_http_403 == "use_snapshot")

        if snapshot_path and not snapshot_fallback_only:
            return self._fetch_from_snapshot(
                indicator_id,
                snapshot_path,
                preferred_year=preferred_year,
                fallback_year=fallback_year,
            )

        spec = self._SUPPORTED[indicator_id]
        try:
            year, value, url, provenance, note = self._fetch_with_years(
                spec,
                country_iso3,
                preferred_year=preferred_year,
                fallback_year=fallback_year,
            )
        except HttpCacheError as exc:
            if exc.status == 403:
                if on_http_403 == "fail":
                    raise RuntimeError(
                        "WITS HTTP 403 forbidden; on_http_403=fail."
                    ) from exc
                if on_http_403 == "use_snapshot" and snapshot_path:
                    result = self._fetch_from_snapshot(
                        indicator_id,
                        snapshot_path,
                        preferred_year=preferred_year,
                        fallback_year=fallback_year,
                    )
                    return result
                return AdapterSkip(
                    adapter=self.name,
                    reason="wits_http_403_forbidden",
                    snapshot_attempted=bool(snapshot_path),
                    snapshot_used=snapshot_used,
                )
            raise

        return AdapterResult(
            value=value,
            unit=spec["unit"],
            period=year,
            evidence_tier="A",
            sources=[
                AdapterSource(
                    url=url,
                    retrieved_at=provenance.get("fetched_at", ""),
                    sha256=provenance.get("sha256", ""),
                    citation_note=note,
                    cache_hit=bool(provenance.get("cache_hit")),
                    stale_used=bool(provenance.get("stale_used")),
                )
            ],
            method_note=note,
            confidence=0.85,
            flags=[],
            source_institution="WITS (World Bank)",
        )

    def _fetch_with_years(
        self,
        spec: dict[str, str],
        country_iso3: str,
        *,
        preferred_year: int | None,
        fallback_year: int | None,
    ) -> tuple[int, float, str, dict, str]:
        if preferred_year:
            try:
                year, value, url, provenance = get_indicator_value_for_year_cached(
                    spec["datasource"],
                    country_iso3,
                    spec["indicator_code"],
                    preferred_year,
                    stale_if_error=False,
                )
                note = (
                    "WITS TradeStats API; "
                    f"indicator {spec['indicator_code']} ({spec['name']}); "
                    f"preferred year {preferred_year}."
                )
                return year, value, url, provenance, note
            except Exception as exc:
                if fallback_year is None:
                    raise
                fallback_note = f"preferred year {preferred_year} failed ({exc}). "
                year, value, url, provenance = get_indicator_value_for_year_cached(
                    spec["datasource"],
                    country_iso3,
                    spec["indicator_code"],
                    fallback_year,
                    stale_if_error=False,
                )
                note = (
                    "WITS TradeStats API; "
                    f"{fallback_note}"
                    f"fallback year {fallback_year} used; "
                    f"indicator {spec['indicator_code']} ({spec['name']})."
                )
                return year, value, url, provenance, note

        try:
            year, value, url, provenance = get_indicator_value_latest_cached(
                spec["datasource"],
                country_iso3,
                spec["indicator_code"],
                stale_if_error=False,
            )
            note = (
                "WITS TradeStats API; "
                f"indicator {spec['indicator_code']} ({spec['name']}); year {year}."
            )
            return year, value, url, provenance, note
        except Exception as exc:
            if fallback_year is None:
                raise
            fallback_note = f"latest year lookup failed ({exc}). "
            year, value, url, provenance = get_indicator_value_for_year_cached(
                spec["datasource"],
                country_iso3,
                spec["indicator_code"],
                fallback_year,
                stale_if_error=False,
            )
            note = (
                "WITS TradeStats API; "
                f"{fallback_note}"
                f"fallback year {fallback_year} used; "
                f"indicator {spec['indicator_code']} ({spec['name']})."
            )
            return year, value, url, provenance, note

    def _fetch_from_snapshot(
        self,
        indicator_id: str,
        snapshot_path: str,
        *,
        preferred_year: int | None,
        fallback_year: int | None,
    ) -> AdapterResult | AdapterSkip:
        path = Path(snapshot_path)
        if not path.is_absolute():
            path = Path(__file__).resolve().parents[4] / snapshot_path
        if not path.exists():
            return AdapterSkip(
                adapter=self.name,
                reason="wits_snapshot_missing",
                snapshot_attempted=True,
                snapshot_used=False,
            )

        raw = path.read_bytes()
        sha256 = hashlib.sha256(raw).hexdigest()
        rows = self._parse_snapshot(path, raw)

        year, value = self._select_snapshot_value(
            rows,
            preferred_year=preferred_year,
            fallback_year=fallback_year,
        )
        if year is None:
            return AdapterSkip(
                adapter=self.name,
                reason="wits_snapshot_no_match",
                snapshot_attempted=True,
                snapshot_used=False,
            )

        spec = self._SUPPORTED[indicator_id]
        note = f"WITS snapshot (offline): {path.as_posix()}"
        return AdapterResult(
            value=value,
            unit=spec["unit"],
            period=year,
            evidence_tier="A",
            sources=[
                AdapterSource(
                    url=f"snapshot:{path.as_posix()}",
                    retrieved_at="",
                    sha256=sha256,
                    citation_note=note,
                    cache_hit=True,
                    stale_used=False,
                )
            ],
            method_note=note,
            confidence=0.85,
            flags=[],
            source_institution="WITS (World Bank)",
        )

    def _parse_snapshot(self, path: Path, raw: bytes) -> list[dict[str, Any]]:
        if path.suffix.lower() == ".json":
            payload = json.loads(raw.decode("utf-8"))
            if isinstance(payload, dict):
                return [payload]
            if isinstance(payload, list):
                return [row for row in payload if isinstance(row, dict)]
            raise RuntimeError("WITS snapshot JSON must be an object or list of objects.")

        if path.suffix.lower() == ".csv":
            text = raw.decode("utf-8")
            reader = csv.DictReader(text.splitlines())
            return [row for row in reader]

        raise RuntimeError("WITS snapshot must be .json or .csv")

    def _select_snapshot_value(
        self,
        rows: list[dict[str, Any]],
        *,
        preferred_year: int | None,
        fallback_year: int | None,
    ) -> tuple[int | None, float | None]:
        parsed = []
        for row in rows:
            year = row.get("year") or row.get("period") or row.get("Year")
            value = row.get("value") or row.get("Value")
            if year is None or value is None:
                continue
            try:
                year_int = int(year)
                value_float = float(value)
            except (TypeError, ValueError):
                continue
            parsed.append((year_int, value_float))

        if not parsed:
            return None, None

        if preferred_year is not None:
            for year_int, value_float in parsed:
                if year_int == preferred_year:
                    return year_int, value_float
            if fallback_year is not None:
                for year_int, value_float in parsed:
                    if year_int == fallback_year:
                        return year_int, value_float
            return None, None

        parsed.sort(key=lambda pair: pair[0], reverse=True)
        return parsed[0]

from __future__ import annotations

from .base import Adapter
from .chinn_ito import ChinnItoAdapter
from .transparency_cpi import TransparencyCpiAdapter
from .yale_epi import YaleEpiAdapter
from .enterprise_surveys import EnterpriseSurveysAdapter
from .itu_idi import ItuIdiAdapter
from .wits import WitsAdapter
from .world_bank import WorldBankAdapter


_ADAPTERS: list[Adapter] = [
    ChinnItoAdapter(),
    TransparencyCpiAdapter(),
    YaleEpiAdapter(),
    WorldBankAdapter(),
    WitsAdapter(),
    ItuIdiAdapter(),
    EnterpriseSurveysAdapter(),
]


def resolve(indicator_id: str) -> Adapter | None:
    for adapter in _ADAPTERS:
        if adapter.supports(indicator_id):
            return adapter
    return None

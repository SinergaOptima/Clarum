from __future__ import annotations

from .base import Adapter, AdapterResult


class WorldBankAdapter(Adapter):
    """Stub adapter for World Bank API (legacy)."""

    name = "worldbank"

    def fetch(self, *args, **kwargs) -> AdapterResult:  # pragma: no cover - stub
        raise NotImplementedError("WorldBankAdapter is a stub in v0; use plan values.")

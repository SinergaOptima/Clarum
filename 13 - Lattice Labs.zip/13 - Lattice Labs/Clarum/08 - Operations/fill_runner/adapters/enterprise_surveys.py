from __future__ import annotations

from datetime import date

from http_cache.http_cache import fetch_json

from .base import Adapter, AdapterResult, AdapterSource


class EnterpriseSurveysAdapter(Adapter):
    """Enterprise Surveys adapter (v0.1)."""

    name = "enterprise_surveys"

    _ALIAS_MAP = {
        "political_instability_major_constraint_pct": (
            "IC.FRM.OBS.OBST11",
            "% firms naming political instability as biggest obstacle",
        ),
        "licensing_permits_major_constraint_pct": (
            "IC.FRM.REG.BUS5",
            "% firms identifying business licensing/permits as major constraint",
        ),
        "inadequately_educated_workforce_major_constraint_pct": (
            "IC.FRM.WRKF.WK10",
            "% firms identifying inadequately educated workforce as major constraint",
        ),
        "quality_certification_share_pct": (
            "IC.FRM.INNOV.T1",
            "% firms with internationally recognized quality certification",
        ),
    }

    def _resolve_indicator(self, query: str) -> tuple[str, str]:
        if query in self._ALIAS_MAP:
            return self._ALIAS_MAP[query]
        return query, "Enterprise Surveys indicator"

    def _build_url(self, iso3: str, indicator_code: str) -> str:
        return (
            f"https://api.worldbank.org/v2/country/{iso3}/indicator/{indicator_code}?format=json"
        )

    def _raise_unreachable(self, urls: list[str], error: Exception | None = None):
        details = f"Enterprise Surveys unreachable. Attempted URLs: {', '.join(urls)}"
        if error:
            details = f"{details}. Error: {error}"
        raise RuntimeError(details)

    def fetch(self, country_iso3: str, query: str, **kwargs) -> AdapterResult:
        indicator_code, definition = self._resolve_indicator(query)
        url = self._build_url(country_iso3, indicator_code)

        try:
            result = fetch_json(url)
            payload = result["data"]
            provenance = result["provenance"]
        except Exception as exc:
            self._raise_unreachable([url], exc)

        if not isinstance(payload, list) or len(payload) < 2:
            self._raise_unreachable([url])

        value = None
        year = None
        for item in payload[1]:
            if item.get("value") is not None:
                value = item.get("value")
                year = item.get("date")
                break

        if value is None:
            self._raise_unreachable([url])

        retrieved_date = provenance.get("fetched_at") or date.today().isoformat()
        if year:
            notes = f"Enterprise Surveys: {definition}; year {year}."
        else:
            notes = (
                f"Enterprise Surveys: {definition}; year not provided by endpoint; "
                "treated as latest available from ES source."
            )

        return AdapterResult(
            value=value,
            unit="Percent of firms",
            period=year,
            evidence_tier="B",
            sources=[
                AdapterSource(
                    url=url,
                    retrieved_at=retrieved_date,
                    sha256=provenance.get("sha256", ""),
                    citation_note=notes,
                    cache_hit=bool(provenance.get("cache_hit")),
                    stale_used=bool(provenance.get("stale_used")),
                )
            ],
            method_note=notes,
            confidence=0.6,
            flags=["FLAG-TIERB-PRESENT"],
            source_institution="World Bank Enterprise Surveys",
        )

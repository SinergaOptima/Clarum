from __future__ import annotations

import re
import zipfile
from io import BytesIO
from typing import Any
import xml.etree.ElementTree as ET

from http_cache.http_cache import fetch_bytes

from .base import Adapter, AdapterResult, AdapterSource


_IDI_URL = "https://www.itu.int/en/ITU-D/Statistics/Documents/IDI/IDI2023Dataset.xlsx"


def _parse_shared_strings(xml_text: str) -> list[str]:
    root = ET.fromstring(xml_text)
    strings = []
    for si in root.findall(".//{http://schemas.openxmlformats.org/spreadsheetml/2006/main}si"):
        parts = []
        for t in si.findall(".//{http://schemas.openxmlformats.org/spreadsheetml/2006/main}t"):
            if t.text:
                parts.append(t.text)
        strings.append("".join(parts))
    return strings


def _column_index(cell_ref: str) -> int:
    letters = "".join(ch for ch in cell_ref if ch.isalpha())
    total = 0
    for ch in letters:
        total = total * 26 + (ord(ch.upper()) - ord("A") + 1)
    return total - 1


def _cell_value(cell: ET.Element, shared_strings: list[str]) -> Any:
    value_node = cell.find("{http://schemas.openxmlformats.org/spreadsheetml/2006/main}v")
    inline_node = cell.find("{http://schemas.openxmlformats.org/spreadsheetml/2006/main}is")
    cell_type = cell.get("t")

    if cell_type == "s" and value_node is not None and value_node.text:
        idx = int(value_node.text)
        return shared_strings[idx] if idx < len(shared_strings) else ""

    if cell_type == "inlineStr" and inline_node is not None:
        text_node = inline_node.find("{http://schemas.openxmlformats.org/spreadsheetml/2006/main}t")
        return text_node.text if text_node is not None else ""

    if value_node is not None and value_node.text is not None:
        return value_node.text

    return ""


def _read_first_sheet_rows(xlsx_bytes: bytes) -> list[list[Any]]:
    with zipfile.ZipFile(BytesIO(xlsx_bytes)) as zf:
        shared_strings = []
        if "xl/sharedStrings.xml" in zf.namelist():
            shared_xml = zf.read("xl/sharedStrings.xml").decode("utf-8")
            shared_strings = _parse_shared_strings(shared_xml)

        sheet_name = "xl/worksheets/sheet1.xml"
        if sheet_name not in zf.namelist():
            raise RuntimeError("Unable to find sheet1.xml in ITU IDI dataset.")

        sheet_xml = zf.read(sheet_name).decode("utf-8")
        root = ET.fromstring(sheet_xml)
        rows = []
        for row in root.findall(".//{http://schemas.openxmlformats.org/spreadsheetml/2006/main}row"):
            cells = {}
            for cell in row.findall("{http://schemas.openxmlformats.org/spreadsheetml/2006/main}c"):
                cell_ref = cell.get("r", "")
                if not cell_ref:
                    continue
                idx = _column_index(cell_ref)
                cells[idx] = _cell_value(cell, shared_strings)
            if not cells:
                continue
            max_idx = max(cells)
            row_values = [""] * (max_idx + 1)
            for idx, value in cells.items():
                row_values[idx] = value
            rows.append(row_values)
        return rows


def _normalize_header(value: str) -> str:
    return re.sub(r"\s+", " ", value.strip().lower())


def _find_idi_value(rows: list[list[Any]], country_iso3: str) -> tuple[float, str | None]:
    header_row = None
    header_idx = {}

    for row in rows:
        headers = [_normalize_header(str(cell)) for cell in row]
        if "iso3" in headers or "country code" in headers:
            header_row = headers
            header_idx = {name: idx for idx, name in enumerate(headers) if name}
            break

    if not header_row:
        raise RuntimeError("ITU IDI dataset headers not found.")

    iso_col = header_idx.get("iso3")
    if iso_col is None:
        iso_col = header_idx.get("country code")
    if iso_col is None:
        raise RuntimeError("ITU IDI dataset ISO3 column not found.")

    value_col = None
    for name, idx in header_idx.items():
        if "idi" in name and "score" in name:
            value_col = idx
            break
    if value_col is None:
        for name, idx in header_idx.items():
            if "idi" in name and re.search(r"\b20\d{2}\b", name):
                value_col = idx
                break
    if value_col is None:
        for name, idx in header_idx.items():
            if name == "idi":
                value_col = idx
                break
    if value_col is None:
        raise RuntimeError("ITU IDI dataset value column not found.")

    year_match = None
    for name in header_idx:
        match = re.search(r"\b(20\d{2})\b", name)
        if match:
            year_match = match.group(1)
            break

    for row in rows[1:]:
        if len(row) <= max(iso_col, value_col):
            continue
        iso_value = str(row[iso_col]).strip().upper()
        if iso_value != country_iso3.upper():
            continue
        raw_value = row[value_col]
        try:
            return float(raw_value), year_match
        except (TypeError, ValueError):
            raise RuntimeError(f"ITU IDI value not numeric for {country_iso3}: {raw_value}")

    raise RuntimeError(f"ITU IDI dataset missing ISO3 entry for {country_iso3}.")


class ItuIdiAdapter(Adapter):
    name = "itu_idi"

    _SUPPORTED = {"IND-A3-POL-002"}

    def supports(self, indicator_id: str) -> bool:
        return indicator_id in self._SUPPORTED

    def fetch(self, country_iso3: str, indicator_id: str, **kwargs) -> AdapterResult:
        if indicator_id not in self._SUPPORTED:
            raise RuntimeError(f"ItuIdiAdapter does not support indicator: {indicator_id}")

        result = fetch_bytes(_IDI_URL)
        rows = _read_first_sheet_rows(result["data"])
        value, year = _find_idi_value(rows, country_iso3)

        note = (
            "ITU IDI dataset (IDI2023Dataset.xlsx); "
            f"value from latest available IDI score column; year {year or 'unknown'}."
        )
        return AdapterResult(
            value=value,
            unit="Score (1-7)",
            period=year,
            evidence_tier="B",
            sources=[
                AdapterSource(
                    url=_IDI_URL,
                    retrieved_at=result["provenance"].get("fetched_at", ""),
                    sha256=result["provenance"].get("sha256", ""),
                    citation_note=note,
                    cache_hit=bool(result["provenance"].get("cache_hit")),
                    stale_used=bool(result["provenance"].get("stale_used")),
                )
            ],
            method_note=note,
            confidence=0.6,
            flags=["FLAG-TIERB-PRESENT"],
            source_institution="ITU",
        )

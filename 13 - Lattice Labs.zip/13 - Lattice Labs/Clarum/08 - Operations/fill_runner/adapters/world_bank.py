from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from http_cache.http_cache import fetch_json

from .base import Adapter, AdapterResult, AdapterSource


@dataclass(frozen=True)
class _SeriesSpec:
    indicator_id: str
    series_code: str
    unit: str
    name: str


@dataclass(frozen=True)
class _FallbackSeriesSpec:
    indicator_id: str
    primary_series: str
    fallback_series: str
    unit_primary: str
    unit_fallback: str
    name: str


_SERIES_MAP = {
    "IND-A4-INF-002": _SeriesSpec(
        indicator_id="IND-A4-INF-002",
        series_code="EG.ELC.LOSS.ZS",
        unit="Percentage",
        name="electric power transmission and distribution losses % of output",
    ),
    "IND-A4-INF-005": _SeriesSpec(
        indicator_id="IND-A4-INF-005",
        series_code="IT.NET.BBND.P2",
        unit="Per 100 people",
        name="fixed broadband subscriptions per 100 people",
    ),
    "IND-A6-LAB-001": _SeriesSpec(
        indicator_id="IND-A6-LAB-001",
        series_code="HD.HCI.OVRL",
        unit="Score (0-1)",
        name="Human Capital Index",
    ),
}

_FALLBACK_SERIES_MAP = {
    "IND-A6-LAB-002": _FallbackSeriesSpec(
        indicator_id="IND-A6-LAB-002",
        primary_series="SE.TER.GRAD.SCI.ZS",
        fallback_series="SP.POP.SCIE.RD.P6",
        unit_primary="Percent",
        unit_fallback="Researchers per million people",
        name="tertiary graduates in science (fallback to researchers per million)",
    )
}


def _build_url(country_iso3: str, series_code: str) -> str:
    return (
        f"https://api.worldbank.org/v2/country/{country_iso3}/indicator/{series_code}?format=json"
    )


def _select_latest(payload: Any) -> tuple[Any, str | None]:
    if not isinstance(payload, list) or len(payload) < 2:
        return None, None
    data = payload[1]
    if not isinstance(data, list):
        return None, None

    rows = []
    for item in data:
        if not isinstance(item, dict):
            continue
        value = item.get("value")
        year = item.get("date")
        if value is None or year is None:
            continue
        rows.append((str(year), value))

    if not rows:
        return None, None

    rows.sort(key=lambda pair: pair[0], reverse=True)
    year, value = rows[0]
    return value, year


class WorldBankAdapter(Adapter):
    name = "world_bank"

    def supports(self, indicator_id: str) -> bool:
        return indicator_id in _SERIES_MAP or indicator_id in _FALLBACK_SERIES_MAP

    def fetch(self, country_iso3: str, indicator_id: str, **kwargs) -> AdapterResult:
        if indicator_id in _SERIES_MAP:
            spec = _SERIES_MAP[indicator_id]
            url = _build_url(country_iso3, spec.series_code)
            result = fetch_json(url)
            payload = result["data"]
            provenance = result["provenance"]
            value, year = _select_latest(payload)
            if value is None:
                raise RuntimeError(f"No non-null values for {indicator_id} ({spec.series_code}).")
            note = f"World Bank API; indicator {spec.series_code} ({spec.name}); year {year}."
            return AdapterResult(
                value=value,
                unit=spec.unit,
                period=year,
                evidence_tier="A",
                sources=[
                    AdapterSource(
                        url=url,
                        retrieved_at=provenance.get("fetched_at", ""),
                        sha256=provenance.get("sha256", ""),
                        citation_note=note,
                        cache_hit=bool(provenance.get("cache_hit")),
                        stale_used=bool(provenance.get("stale_used")),
                    )
                ],
                method_note=note,
                confidence=0.85,
                flags=[],
                source_institution="World Bank",
            )

        if indicator_id in _FALLBACK_SERIES_MAP:
            spec = _FALLBACK_SERIES_MAP[indicator_id]
            primary_url = _build_url(country_iso3, spec.primary_series)
            primary_result = fetch_json(primary_url)
            primary_payload = primary_result["data"]
            primary_prov = primary_result["provenance"]
            value, year = _select_latest(primary_payload)

            used_series = spec.primary_series
            unit = spec.unit_primary
            provenance = primary_prov
            url = primary_url
            fallback_note = ""

            if value is None:
                fallback_url = _build_url(country_iso3, spec.fallback_series)
                fallback_result = fetch_json(fallback_url)
                fallback_payload = fallback_result["data"]
                fallback_prov = fallback_result["provenance"]
                value, year = _select_latest(fallback_payload)
                if value is None:
                    raise RuntimeError(
                        "No non-null values for primary or fallback series "
                        f"for {indicator_id} ({spec.primary_series}/{spec.fallback_series})."
                    )
                used_series = spec.fallback_series
                unit = spec.unit_fallback
                provenance = fallback_prov
                url = fallback_url
                fallback_note = (
                    f"Primary series {spec.primary_series} missing; used {spec.fallback_series}. "
                )

            note = (
                "World Bank API; "
                f"{fallback_note}indicator {used_series} ({spec.name}); year {year}."
            )
            return AdapterResult(
                value=value,
                unit=unit,
                period=year,
                evidence_tier="A",
                sources=[
                    AdapterSource(
                        url=url,
                        retrieved_at=provenance.get("fetched_at", ""),
                        sha256=provenance.get("sha256", ""),
                        citation_note=note,
                        cache_hit=bool(provenance.get("cache_hit")),
                        stale_used=bool(provenance.get("stale_used")),
                    )
                ],
                method_note=note,
                confidence=0.85,
                flags=[],
                source_institution="World Bank",
            )

        raise RuntimeError(f"WorldBankAdapter does not support indicator: {indicator_id}")

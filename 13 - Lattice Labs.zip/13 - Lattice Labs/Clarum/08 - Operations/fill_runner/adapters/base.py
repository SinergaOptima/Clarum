from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass
class AdapterSource:
    url: str
    retrieved_at: str
    sha256: str
    citation_note: str
    cache_hit: bool = False
    stale_used: bool = False


@dataclass
class AdapterResult:
    value: Any
    unit: str | None
    period: str | int | None
    evidence_tier: str
    sources: list[AdapterSource]
    method_note: str
    confidence: float
    flags: list[str]
    source_institution: str


@dataclass
class AdapterSkip:
    adapter: str
    reason: str
    snapshot_attempted: bool = False
    snapshot_used: bool = False


class Adapter:
    """Base adapter interface (stub)."""

    name = "base"

    def supports(self, indicator_id: str) -> bool:  # pragma: no cover - stub
        return False

    def fetch(
        self, country_iso3: str, indicator_id: str, **kwargs
    ) -> AdapterResult | AdapterSkip:  # pragma: no cover - stub
        raise NotImplementedError

from __future__ import annotations

import csv
import re
import zipfile
from io import BytesIO
from typing import Any
import xml.etree.ElementTree as ET

from http_cache.http_cache import fetch_bytes

from .base import Adapter, AdapterResult, AdapterSource, AdapterSkip


_CPI_URL_CANDIDATES = [
    "https://www.transparency.org/en/cpi/2024",
    "https://images.transparencycdn.org/images/CPI2024_GlobalTables.xlsx",
    "https://raw.githubusercontent.com/datasets/corruption-perceptions-index/main/data/cpi.csv",
]


_COUNTRY_NAME_MAP = {
    "HUN": {"hungary"},
    "MEX": {"mexico"},
    "MYS": {"malaysia"},
}

_ISO3_HEADER_CANDIDATES = (
    "iso3",
    "ccode",
    "country_code",
    "alpha_3",
    "iso_alpha3",
    "iso_alpha_3",
)

_COUNTRY_HEADER_CANDIDATES = (
    "country",
    "country_name",
    "name",
    "jurisdiction",
)

_YEAR_HEADER_CANDIDATES = (
    "year",
    "time",
    "period",
)

_SCORE_HEADER_CANDIDATES = (
    "cpi",
    "score",
    "cpi_score",
    "value",
    "index",
    "points",
)


def _parse_shared_strings(xml_text: str) -> list[str]:
    root = ET.fromstring(xml_text)
    strings = []
    for si in root.findall(
        ".//{http://schemas.openxmlformats.org/spreadsheetml/2006/main}si"
    ):
        parts = []
        for t in si.findall(
            ".//{http://schemas.openxmlformats.org/spreadsheetml/2006/main}t"
        ):
            if t.text:
                parts.append(t.text)
        strings.append("".join(parts))
    return strings


def _column_index(cell_ref: str) -> int:
    letters = "".join(ch for ch in cell_ref if ch.isalpha())
    total = 0
    for ch in letters:
        total = total * 26 + (ord(ch.upper()) - ord("A") + 1)
    return total - 1


def _cell_value(cell: ET.Element, shared_strings: list[str]) -> Any:
    value_node = cell.find(
        "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}v"
    )
    inline_node = cell.find(
        "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}is"
    )
    cell_type = cell.get("t")

    if cell_type == "s" and value_node is not None and value_node.text:
        idx = int(value_node.text)
        return shared_strings[idx] if idx < len(shared_strings) else ""

    if cell_type == "inlineStr" and inline_node is not None:
        text_node = inline_node.find(
            "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}t"
        )
        return text_node.text if text_node is not None else ""

    if value_node is not None and value_node.text is not None:
        return value_node.text

    return ""


def _read_xlsx_sheet_rows(xlsx_bytes: bytes) -> list[list[Any]]:
    with zipfile.ZipFile(BytesIO(xlsx_bytes)) as zf:
        shared_strings = []
        if "xl/sharedStrings.xml" in zf.namelist():
            shared_xml = zf.read("xl/sharedStrings.xml").decode("utf-8")
            shared_strings = _parse_shared_strings(shared_xml)

        sheet_name = "xl/worksheets/sheet1.xml"
        if sheet_name not in zf.namelist():
            raise RuntimeError("Unable to find sheet1.xml in XLSX dataset.")

        sheet_xml = zf.read(sheet_name).decode("utf-8")
        root = ET.fromstring(sheet_xml)
        rows = []
        for row in root.findall(
            ".//{http://schemas.openxmlformats.org/spreadsheetml/2006/main}row"
        ):
            cells = {}
            for cell in row.findall(
                "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}c"
            ):
                cell_ref = cell.get("r", "")
                if not cell_ref:
                    continue
                idx = _column_index(cell_ref)
                cells[idx] = _cell_value(cell, shared_strings)
            if not cells:
                continue
            max_idx = max(cells)
            row_values = [""] * (max_idx + 1)
            for idx, value in cells.items():
                row_values[idx] = value
            rows.append(row_values)
        return rows


def _parse_csv_text(raw_bytes: bytes) -> list[list[str]]:
    text = None
    for encoding in ("utf-8", "latin-1", "cp1252"):
        try:
            text = raw_bytes.decode(encoding)
            break
        except UnicodeDecodeError:
            continue
    if text is None:
        raise RuntimeError("Unable to decode CSV data as text.")

    lines = text.strip().splitlines()
    reader = csv.reader(lines)
    return [row for row in reader]


def _normalize_header(value: str) -> str:
    text = str(value or "").replace("\ufeff", "").strip().lower()
    text = re.sub(r"\s+", "_", text)
    text = text.replace("-", "_")
    return re.sub(r"[^a-z0-9_]+", "", text)


def _first_matching_column(
    header_idx: dict[str, int], candidates: tuple[str, ...]
) -> int | None:
    for name in candidates:
        if name in header_idx:
            return header_idx[name]
    return None


def _cell_text(row: list[Any], idx: int | None) -> str:
    if idx is None or idx < 0 or idx >= len(row):
        return ""
    value = row[idx]
    return "" if value is None else str(value).strip()


def _normalize_country_name(value: str) -> str:
    text = str(value or "").lower()
    text = re.sub(r"[^a-z0-9]+", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def _parse_year(value: str) -> int | None:
    match = re.search(r"\b(19\d{2}|20\d{2})\b", str(value))
    if not match:
        return None
    return int(match.group(1))


def _parse_score(value: str) -> float | None:
    text = str(value or "").strip().replace(",", "")
    if not text:
        return None
    try:
        return float(text)
    except (TypeError, ValueError):
        return None


def _resolve_score_column(header_idx: dict[str, int]) -> int | None:
    score_col = _first_matching_column(header_idx, _SCORE_HEADER_CANDIDATES)
    if score_col is not None:
        return score_col
    for name, idx in header_idx.items():
        if "cpi" in name or "corruption" in name:
            return idx
    return None


def _resolve_year_columns(header_idx: dict[str, int]) -> dict[int, int]:
    year_cols: dict[int, int] = {}
    for name, idx in header_idx.items():
        if re.fullmatch(r"(19\d{2}|20\d{2})", name):
            year_cols[int(name)] = idx
    return year_cols


def _match_country_mode(
    row: list[Any],
    iso_col: int | None,
    country_col: int | None,
    country_iso3: str,
) -> str | None:
    iso_target = country_iso3.upper()
    if iso_col is not None and _cell_text(row, iso_col).upper() == iso_target:
        return "iso3"

    if country_col is not None:
        aliases = _COUNTRY_NAME_MAP.get(iso_target, set())
        country_value = _normalize_country_name(_cell_text(row, country_col))
        if country_value in aliases:
            return "name"

    return None


def _extract_cpi_value(
    rows: list[list[Any]], country_iso3: str
) -> tuple[tuple[float, int, str] | None, str | None]:
    if not rows:
        return None, "cpi_unparseable_format"

    headers = [_normalize_header(cell) for cell in rows[0]]
    header_idx = {name: idx for idx, name in enumerate(headers) if name}
    if not header_idx:
        return None, "cpi_unparseable_format"

    iso_col = _first_matching_column(header_idx, _ISO3_HEADER_CANDIDATES)
    country_col = _first_matching_column(header_idx, _COUNTRY_HEADER_CANDIDATES)
    if iso_col is None and country_col is None:
        return None, "cpi_country_not_found"

    year_col = _first_matching_column(header_idx, _YEAR_HEADER_CANDIDATES)
    score_col = _resolve_score_column(header_idx)
    wide_year_cols = _resolve_year_columns(header_idx)
    if year_col is None and not wide_year_cols:
        return None, "cpi_missing_year"

    matched_any = False
    out_of_range = False

    # Long format: explicit year + score columns.
    if year_col is not None and score_col is not None:
        best: tuple[int, float, str] | None = None
        for row in rows[1:]:
            mode = _match_country_mode(row, iso_col, country_col, country_iso3)
            if mode is None:
                continue
            matched_any = True
            year = _parse_year(_cell_text(row, year_col))
            if year is None:
                continue
            score = _parse_score(_cell_text(row, score_col))
            if score is None:
                continue
            if score < 0 or score > 100:
                out_of_range = True
                continue
            if best is None or year > best[0]:
                best = (year, score, mode)
        if best is not None:
            year, score, mode = best
            return (score, year, mode), None
        if matched_any and out_of_range:
            return None, "cpi_score_out_of_range"

    # Wide format: years in header columns.
    if wide_year_cols:
        ordered_years = sorted(wide_year_cols.items(), key=lambda item: item[0], reverse=True)
        for row in rows[1:]:
            mode = _match_country_mode(row, iso_col, country_col, country_iso3)
            if mode is None:
                continue
            matched_any = True
            for year, idx in ordered_years:
                score = _parse_score(_cell_text(row, idx))
                if score is None:
                    continue
                if score < 0 or score > 100:
                    out_of_range = True
                    continue
                return (score, year, mode), None
        if matched_any and out_of_range:
            return None, "cpi_score_out_of_range"

    if matched_any:
        return None, "cpi_country_not_found"
    return None, "cpi_country_not_found"


def _extract_csv_from_zip(zip_bytes: bytes) -> bytes:
    with zipfile.ZipFile(BytesIO(zip_bytes)) as zf:
        for name in zf.namelist():
            if name.lower().endswith(".csv"):
                return zf.read(name)
    raise RuntimeError("No CSV file found in archive.")


def _parse_payload(raw_bytes: bytes) -> tuple[list[list[Any]], str]:
    if raw_bytes[:2] == b"PK":
        try:
            return _read_xlsx_sheet_rows(raw_bytes), "xlsx"
        except Exception:
            csv_bytes = _extract_csv_from_zip(raw_bytes)
            return _parse_csv_text(csv_bytes), "zip_csv"
    return _parse_csv_text(raw_bytes), "csv"


class TransparencyCpiAdapter(Adapter):
    name = "ti_cpi"

    _SUPPORTED = {"IND-A8-ESG-001"}

    def supports(self, indicator_id: str) -> bool:
        return indicator_id in self._SUPPORTED

    def fetch(
        self, country_iso3: str, indicator_id: str, **kwargs
    ) -> AdapterResult | AdapterSkip:
        if indicator_id not in self._SUPPORTED:
            raise RuntimeError(
                f"TransparencyCpiAdapter does not support indicator: {indicator_id}"
            )

        source_url_override = kwargs.get("source_url_override")
        candidates: list[str] = []
        if isinstance(source_url_override, str) and source_url_override.strip():
            candidates.append(source_url_override.strip())
        for url in _CPI_URL_CANDIDATES:
            if url not in candidates:
                candidates.append(url)

        fetched_any = False
        last_reason = "cpi_source_unavailable"

        for url in candidates:
            try:
                result = fetch_bytes(url, ttl_days=3650, stale_if_error=True)
            except Exception:
                continue

            fetched_any = True
            raw_bytes = result.get("data", b"")
            try:
                rows, parse_method = _parse_payload(raw_bytes)
            except Exception:
                last_reason = "cpi_unparseable_format"
                continue

            extracted, reason = _extract_cpi_value(rows, country_iso3)
            if extracted is None:
                last_reason = reason or "cpi_country_not_found"
                continue

            value, year, match_mode = extracted
            note = (
                f"cache-only fetch; candidate URL selected: {url}; "
                f"matched by {match_mode}; selected latest year {year}; "
                f"parse={parse_method}."
            )
            provenance = result.get("provenance", {})
            return AdapterResult(
                value=value,
                unit="Score (0-100)",
                period=year,
                evidence_tier="A",
                sources=[
                    AdapterSource(
                        url=url,
                        retrieved_at=provenance.get("fetched_at", ""),
                        sha256=provenance.get("sha256", ""),
                        citation_note=f"Transparency International CPI (year {year})",
                        cache_hit=bool(provenance.get("cache_hit")),
                        stale_used=bool(provenance.get("stale_used")),
                    )
                ],
                method_note=note,
                confidence=0.85,
                flags=[],
                source_institution="Transparency International",
            )

        if not fetched_any:
            return AdapterSkip(adapter=self.name, reason="cpi_source_unavailable")
        return AdapterSkip(adapter=self.name, reason=last_reason)

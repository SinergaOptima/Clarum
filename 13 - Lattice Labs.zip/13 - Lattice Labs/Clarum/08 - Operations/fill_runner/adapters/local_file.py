from __future__ import annotations

from .base import Adapter, AdapterResult


class LocalFileAdapter(Adapter):
    """Stub adapter for local/manual value plans."""

    name = "local_file"

    def fetch(self, *args, **kwargs) -> AdapterResult:  # pragma: no cover - stub
        raise NotImplementedError("LocalFileAdapter is a stub in v0; use plan values.")

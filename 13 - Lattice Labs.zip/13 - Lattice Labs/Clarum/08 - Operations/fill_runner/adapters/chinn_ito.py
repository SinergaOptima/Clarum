from __future__ import annotations

import csv
import hashlib
import json
import re
import zipfile
from io import BytesIO
from pathlib import Path
from typing import Any
import xml.etree.ElementTree as ET

from http_cache.http_cache import fetch_bytes

from .base import Adapter, AdapterResult, AdapterSource, AdapterSkip


_KAOPEN_URL_CANDIDATES = [
    "https://graebnerc.github.io/OpennessDataR/files/data/openness_data_csv.zip",
    "https://web.pdx.edu/~ito/kaopen_2023.xls",
    "https://web.pdx.edu/~ito/kaopen_2023.xlsx",
    "https://web.pdx.edu/~ito/kaopen_2023.csv",
    "https://web.pdx.edu/~ito/kaopen_2023.dta",
]

# KAOPEN README convention:
# - ccode: ISO Alpha-3 country code
# - cn: IMF-World Bank three-digit code
# Expand as needed.
ISO3_TO_CN = {
    "HUN": "944",
    "MEX": "273",
    "MYS": "548",
}

ISO3_TO_COUNTRY_ALIASES = {
    "HUN": {"hungary"},
    "MEX": {"mexico"},
    "MYS": {"malaysia"},
}

_ISO3_HEADER_CANDIDATES = (
    "ccode",
    "iso3",
    "iso alpha3",
    "iso alpha 3",
    "iso alpha 3 code",
    "iso3 code",
)

_CN_HEADER_CANDIDATES = (
    "cn",
    "imf world bank code",
    "imf wb code",
    "imf world bank three digit code",
    "imfcode",
    "wbcode",
)

_COUNTRY_NAME_HEADER_CANDIDATES = (
    "country",
    "country name",
    "name",
)

_KAOPEN_VALUE_HEADER_CANDIDATES = (
    "kaopen",
    "ka open",
    "chinn ito",
    "chinn ito normed",
    "kaopen index",
)


def sniff_payload(body: bytes) -> dict:
    return {
        "magic_hex32": body[:32].hex() if len(body) >= 32 else body.hex(),
        "length": len(body),
        "is_zip": body[:2] == b"PK",
        "is_ole2": body[:8] == b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1",
        "is_html": body.lstrip()[:1] == b"<" and b"<table" in body[:4096].lower(),
        "looks_text": _try_decode_text(body[:8192]) is not None,
    }


def _try_decode_text(data: bytes) -> str | None:
    for encoding in ("utf-8", "latin-1", "cp1252"):
        try:
            return data.decode(encoding)
        except UnicodeDecodeError:
            continue
    return None


def _parse_shared_strings(xml_text: str) -> list[str]:
    root = ET.fromstring(xml_text)
    strings = []
    for si in root.findall(
        ".//{http://schemas.openxmlformats.org/spreadsheetml/2006/main}si"
    ):
        parts = []
        for t in si.findall(
            ".//{http://schemas.openxmlformats.org/spreadsheetml/2006/main}t"
        ):
            if t.text:
                parts.append(t.text)
        strings.append("".join(parts))
    return strings


def _column_index(cell_ref: str) -> int:
    letters = "".join(ch for ch in cell_ref if ch.isalpha())
    total = 0
    for ch in letters:
        total = total * 26 + (ord(ch.upper()) - ord("A") + 1)
    return total - 1


def _cell_value(cell: ET.Element, shared_strings: list[str]) -> Any:
    value_node = cell.find(
        "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}v"
    )
    inline_node = cell.find(
        "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}is"
    )
    cell_type = cell.get("t")

    if cell_type == "s" and value_node is not None and value_node.text:
        idx = int(value_node.text)
        return shared_strings[idx] if idx < len(shared_strings) else ""

    if cell_type == "inlineStr" and inline_node is not None:
        text_node = inline_node.find(
            "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}t"
        )
        return text_node.text if text_node is not None else ""

    if value_node is not None and value_node.text is not None:
        return value_node.text

    return ""


def _read_xlsx_sheet_rows(
    xlsx_bytes: bytes, max_rows: int = 5000, max_cols: int = 80
) -> list[list[Any]]:
    with zipfile.ZipFile(BytesIO(xlsx_bytes)) as zf:
        shared_strings = []
        if "xl/sharedStrings.xml" in zf.namelist():
            shared_xml = zf.read("xl/sharedStrings.xml").decode("utf-8")
            shared_strings = _parse_shared_strings(shared_xml)

        sheet_name = "xl/worksheets/sheet1.xml"
        if sheet_name not in zf.namelist():
            raise RuntimeError("Unable to find sheet1.xml in XLSX dataset.")

        sheet_xml = zf.read(sheet_name).decode("utf-8")
        root = ET.fromstring(sheet_xml)
        rows = []
        for row in root.findall(
            ".//{http://schemas.openxmlformats.org/spreadsheetml/2006/main}row"
        ):
            if len(rows) >= max_rows:
                break
            cells = {}
            for cell in row.findall(
                "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}c"
            ):
                cell_ref = cell.get("r", "")
                if not cell_ref:
                    continue
                idx = _column_index(cell_ref)
                if idx >= max_cols:
                    continue
                cells[idx] = _cell_value(cell, shared_strings)
            if not cells:
                continue
            max_idx = min(max(cells), max_cols - 1)
            row_values = [""] * (max_idx + 1)
            for idx, value in cells.items():
                row_values[idx] = value
            rows.append(row_values)
        return rows


def _detect_delimiter(text: str) -> str:
    first_line = text.split("\n", 1)[0] if "\n" in text else text
    tab_count = first_line.count("\t")
    comma_count = first_line.count(",")
    if tab_count > comma_count:
        return "\t"
    return ","


def _parse_tabular_text(raw_bytes: bytes) -> list[list[str]]:
    text = _try_decode_text(raw_bytes)
    if text is None:
        raise RuntimeError("Unable to decode tabular data as text.")

    delimiter = _detect_delimiter(text)
    lines = text.strip().splitlines()
    reader = csv.reader(lines, delimiter=delimiter)
    return [row for row in reader]


def _parse_html_table(raw_bytes: bytes) -> list[list[str]]:
    text = _try_decode_text(raw_bytes)
    if text is None:
        raise RuntimeError("Unable to decode HTML as text.")

    rows = []
    current_row = []
    current_cell = ""

    in_table = False
    in_row = False
    in_cell = False
    cell_tag = None

    i = 0
    while i < len(text):
        if text[i : i + 6].lower() == "<table":
            in_table = True
            i += 6
            continue
        if text[i : i + 7].lower() == "</table":
            break
        if not in_table:
            i += 1
            continue

        if text[i : i + 3].lower() == "<tr":
            in_row = True
            current_row = []
            i += 3
            continue
        if text[i : i + 4].lower() == "</tr":
            if current_row:
                rows.append(current_row)
            in_row = False
            i += 4
            continue
        if not in_row:
            i += 1
            continue

        if text[i : i + 3].lower() in ("<td", "<th"):
            in_cell = True
            cell_tag = text[i : i + 3].lower()
            current_cell = ""
            i += 3
            while i < len(text) and text[i] != ">":
                i += 1
            i += 1
            continue

        if in_cell and text[i : i + 4].lower() in ("</td", "</th"):
            current_row.append(current_cell.strip())
            in_cell = False
            i += 4
            while i < len(text) and text[i] != ">":
                i += 1
            i += 1
            continue

        if in_cell:
            if text[i] == "<":
                while i < len(text) and text[i] != ">":
                    i += 1
                i += 1
                continue
            current_cell += text[i]
        i += 1

    return rows


def _extract_csv_from_zip(zip_bytes: bytes) -> bytes:
    with zipfile.ZipFile(BytesIO(zip_bytes)) as zf:
        for name in zf.namelist():
            if name.lower().endswith(".csv"):
                return zf.read(name)
        raise RuntimeError("No CSV file found in zip archive.")


def _normalize_header(value: str) -> str:
    text = str(value or "").replace("\ufeff", "").replace("\xa0", " ")
    text = re.sub(r"[\u200b\u200c\u200d\u2060]", "", text)
    text = text.strip().lower()
    text = text.replace("_", " ").replace("-", " ")
    return re.sub(r"\s+", " ", text)


def _normalize_country_name(value: Any) -> str:
    text = str(value or "").strip().lower()
    text = re.sub(r"[^a-z0-9]+", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def _normalize_cn_code(value: Any) -> str:
    text = str(value or "").strip()
    if not text:
        return ""
    match = re.fullmatch(r"([0-9]+)(?:\.0+)?", text)
    if match:
        return f"{int(match.group(1)):03d}"
    digits = re.sub(r"\D", "", text)
    if not digits:
        return ""
    return f"{int(digits):03d}"


def _parse_float(value: Any) -> float | None:
    text = str(value or "").strip()
    if not text:
        return None
    text = text.replace(",", "")
    try:
        return float(text)
    except (TypeError, ValueError):
        return None


def _cell_text(row: list[Any], idx: int) -> str:
    if idx < 0 or idx >= len(row):
        return ""
    value = row[idx]
    return "" if value is None else str(value)


def _first_column(header_idx: dict[str, int], candidates: tuple[str, ...]) -> int | None:
    for candidate in candidates:
        if candidate in header_idx:
            return header_idx[candidate]
    return None


def _build_country_matcher(header_idx: dict[str, int], country_iso3: str):
    iso3 = country_iso3.upper()

    iso_col = _first_column(header_idx, _ISO3_HEADER_CANDIDATES)
    if iso_col is not None:
        return lambda row: _cell_text(row, iso_col).strip().upper() == iso3

    cn_col = _first_column(header_idx, _CN_HEADER_CANDIDATES)
    if cn_col is not None:
        target_cn = ISO3_TO_CN.get(iso3, "")
        if not target_cn:
            return None
        return lambda row: _normalize_cn_code(_cell_text(row, cn_col)) == target_cn

    name_col = _first_column(header_idx, _COUNTRY_NAME_HEADER_CANDIDATES)
    if name_col is not None:
        aliases = {
            _normalize_country_name(alias)
            for alias in ISO3_TO_COUNTRY_ALIASES.get(iso3, set())
        }
        if not aliases:
            return None
        return lambda row: _normalize_country_name(_cell_text(row, name_col)) in aliases

    return None


def _extract_year_columns(header_idx: dict[str, int]) -> dict[int, int]:
    year_cols: dict[int, int] = {}
    for name, idx in header_idx.items():
        match = re.fullmatch(r"(19\d{2}|20\d{2})", name) or re.search(
            r"(19\d{2}|20\d{2})", name
        )
        if match:
            year_cols[int(match.group(1))] = idx
    return year_cols


def _resolve_long_columns(header_idx: dict[str, int]) -> tuple[int | None, int | None]:
    year_col = _first_column(header_idx, ("year", "yr"))
    kaopen_col = _first_column(header_idx, _KAOPEN_VALUE_HEADER_CANDIDATES)
    if kaopen_col is None:
        for name, idx in header_idx.items():
            if "kaopen" in name or "chinn" in name:
                kaopen_col = idx
                break
    return year_col, kaopen_col


def _find_kaopen_value_wide(
    rows: list[list[Any]], country_match, year_cols: dict[int, int]
) -> tuple[float, int] | None:
    if not year_cols:
        return None

    best: tuple[int, float] | None = None
    for row in rows[1:]:
        if not row:
            continue
        if not country_match(row):
            continue
        for year, idx in year_cols.items():
            value = _parse_float(_cell_text(row, idx))
            if value is None:
                continue
            if best is None or year > best[0]:
                best = (year, value)

    if best is None:
        return None
    return best[1], best[0]


def _find_kaopen_value_long(
    rows: list[list[Any]], country_match, year_col: int | None, kaopen_col: int | None
) -> tuple[float, int] | None:
    if kaopen_col is None:
        return None

    best: tuple[int, float] | None = None
    for row in rows[1:]:
        if not row:
            continue
        if not country_match(row):
            continue
        value = _parse_float(_cell_text(row, kaopen_col))
        if value is None:
            continue
        year = 0
        if year_col is not None:
            year_text = _cell_text(row, year_col).strip()
            year_match = re.search(r"(19\d{2}|20\d{2})", year_text)
            if year_match:
                year = int(year_match.group(1))
        if best is None or year > best[0]:
            best = (year, value)

    if best is None:
        return None

    best_year, best_value = best
    return best_value, best_year if best_year > 0 else 2023


def _looks_like_header_row(headers: list[str]) -> bool:
    if not headers:
        return False
    has_country_col = any(
        h
        in (
            _ISO3_HEADER_CANDIDATES
            + _CN_HEADER_CANDIDATES
            + _COUNTRY_NAME_HEADER_CANDIDATES
        )
        for h in headers
    )
    has_value_col = any(
        (
            re.search(r"(19\d{2}|20\d{2})", h) is not None
            or h in _KAOPEN_VALUE_HEADER_CANDIDATES
            or h in {"year", "yr"}
            or "kaopen" in h
            or "chinn" in h
        )
        for h in headers
    )
    return has_country_col and has_value_col


def _find_kaopen_value(rows: list[list[Any]], country_iso3: str) -> tuple[float, int]:
    header_idx = {}

    for row in rows:
        headers = [_normalize_header(str(cell)) for cell in row]
        if _looks_like_header_row(headers):
            header_idx = {name: idx for idx, name in enumerate(headers) if name}
            break

    if not header_idx:
        raise RuntimeError("KAOPEN dataset headers not found.")

    country_match = _build_country_matcher(header_idx, country_iso3)
    if country_match is None:
        raise RuntimeError(f"KAOPEN country identifier column not found for {country_iso3}.")

    year_cols = _extract_year_columns(header_idx)
    year_col, kaopen_col = _resolve_long_columns(header_idx)
    has_wide = bool(year_cols)
    has_long = year_col is not None and kaopen_col is not None

    # Prefer the explicit long form (year + kaopen columns), otherwise wide.
    if has_long and not has_wide:
        result = _find_kaopen_value_long(rows, country_match, year_col, kaopen_col)
        if result:
            return result

    if has_wide and not has_long:
        result = _find_kaopen_value_wide(rows, country_match, year_cols)
        if result:
            return result

    result = _find_kaopen_value_long(rows, country_match, year_col, kaopen_col)
    if result:
        return result

    result = _find_kaopen_value_wide(rows, country_match, year_cols)
    if result:
        return result

    raise RuntimeError(f"KAOPEN dataset missing entry for {country_iso3}.")


def _resolve_snapshot_path(snapshot_path: str) -> Path:
    path = Path(snapshot_path)
    if path.is_absolute():
        return path
    clarum_root = Path(__file__).resolve().parents[3]
    repo_root = Path(__file__).resolve().parents[4]
    candidates = [
        Path.cwd() / path,
        clarum_root / path,
        repo_root / path,
    ]
    for candidate in candidates:
        if candidate.exists():
            return candidate
    return clarum_root / path


class ChinnItoAdapter(Adapter):
    name = "chinn_ito"

    _SUPPORTED = {"IND-A7-CAP-002"}

    def supports(self, indicator_id: str) -> bool:
        return indicator_id in self._SUPPORTED

    def fetch(
        self, country_iso3: str, indicator_id: str, **kwargs
    ) -> AdapterResult | AdapterSkip:
        if indicator_id not in self._SUPPORTED:
            raise RuntimeError(
                f"ChinnItoAdapter does not support indicator: {indicator_id}"
            )

        debug_sniff = kwargs.get("debug_sniff", False)
        snapshot_path = kwargs.get("snapshot_path")

        successful_url = None
        result = None
        sniff_info = None
        raw_bytes = None

        if isinstance(snapshot_path, str) and snapshot_path.strip():
            snapshot_file = _resolve_snapshot_path(snapshot_path.strip())
            if not snapshot_file.exists():
                return AdapterSkip(
                    adapter=self.name,
                    reason="kaopen_snapshot_missing",
                    snapshot_attempted=True,
                    snapshot_used=False,
                )
            raw_bytes = snapshot_file.read_bytes()
            successful_url = f"snapshot:{snapshot_file.as_posix()}"
            result = {
                "provenance": {
                    "fetched_at": "",
                    "sha256": hashlib.sha256(raw_bytes).hexdigest(),
                    "cache_hit": True,
                    "stale_used": False,
                }
            }
        else:
            for url in _KAOPEN_URL_CANDIDATES:
                try:
                    result = fetch_bytes(url, ttl_days=3650, stale_if_error=True)
                    successful_url = url
                    raw_bytes = result["data"]
                    break
                except Exception:
                    continue

            if result is None or raw_bytes is None:
                return AdapterSkip(
                    adapter=self.name,
                    reason="kaopen_all_sources_unavailable",
                )

        if debug_sniff:
            sniff_info = sniff_payload(raw_bytes)

        rows = None
        parse_method = None

        if raw_bytes[:2] == b"PK":
            try:
                csv_bytes = _extract_csv_from_zip(raw_bytes)
                rows = _parse_tabular_text(csv_bytes)
                parse_method = "zip_csv"
            except Exception:
                pass

            if rows is None:
                try:
                    rows = _read_xlsx_sheet_rows(raw_bytes)
                    parse_method = "xlsx"
                except Exception:
                    pass

        if rows is None and raw_bytes[:8] == b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1":
            return AdapterSkip(
                adapter=self.name,
                reason="kaopen_ole2_xls_unsupported",
            )

        if (
            rows is None
            and raw_bytes.lstrip()[:1] == b"<"
            and b"<table" in raw_bytes[:4096].lower()
        ):
            try:
                rows = _parse_html_table(raw_bytes)
                parse_method = "html"
            except Exception:
                pass

        if rows is None:
            try:
                rows = _parse_tabular_text(raw_bytes)
                parse_method = "tsv" if b"\t" in raw_bytes[:1000] else "csv"
            except Exception:
                pass

        if rows is None:
            return AdapterSkip(
                adapter=self.name,
                reason="kaopen_unparseable_format",
            )

        try:
            value, year = _find_kaopen_value(rows, country_iso3)
        except RuntimeError as exc:
            return AdapterSkip(
                adapter=self.name,
                reason="kaopen_country_not_found",
            )

        note = (
            f"Chinn-Ito KAOPEN index dataset; {parse_method} parse; "
            f"source URL: {successful_url}; latest year {year} for {country_iso3}."
        )

        if debug_sniff and sniff_info:
            note += f" [debug_sniff: {json.dumps(sniff_info, separators=(',', ':'))}]"

        confidence = (
            0.9
            if successful_url.startswith("snapshot:") or "graebnerc" not in successful_url
            else 0.85
        )

        return AdapterResult(
            value=value,
            unit="Score (-1.9 to 2.3)",
            period=year,
            evidence_tier="A",
            sources=[
                AdapterSource(
                    url=successful_url,
                    retrieved_at=result["provenance"].get("fetched_at", ""),
                    sha256=result["provenance"].get("sha256", ""),
                    citation_note="Chinn-Ito KAOPEN index dataset (latest year)",
                    cache_hit=bool(result["provenance"].get("cache_hit")),
                    stale_used=bool(result["provenance"].get("stale_used")),
                )
            ],
            method_note=note,
            confidence=confidence,
            flags=[],
            source_institution="Chinn-Ito",
        )

from __future__ import annotations

from .base import Adapter, AdapterResult


class FredAdapter(Adapter):
    """Stub adapter for FRED (v0 uses external plan values)."""

    name = "fred"

    def fetch(self, *args, **kwargs) -> AdapterResult:  # pragma: no cover - stub
        raise NotImplementedError("FredAdapter is a stub in v0; use plan values.")

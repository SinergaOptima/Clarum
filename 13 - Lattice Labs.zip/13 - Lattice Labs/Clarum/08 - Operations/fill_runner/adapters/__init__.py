from .base import Adapter, AdapterResult, AdapterSkip, AdapterSource
from .enterprise_surveys import EnterpriseSurveysAdapter
from .fred import FredAdapter
from .itu_idi import ItuIdiAdapter
from .local_file import LocalFileAdapter
from .registry import resolve
from .wits import WitsAdapter
from .world_bank import WorldBankAdapter

__all__ = [
    "Adapter",
    "AdapterResult",
    "AdapterSkip",
    "AdapterSource",
    "WorldBankAdapter",
    "WitsAdapter",
    "ItuIdiAdapter",
    "LocalFileAdapter",
    "EnterpriseSurveysAdapter",
    "FredAdapter",
    "resolve",
]

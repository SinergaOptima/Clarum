from __future__ import annotations

import argparse
import json
import shlex
import shutil
import sys
from pathlib import Path

from adapters.base import AdapterSkip
from adapters.enterprise_surveys import EnterpriseSurveysAdapter
from adapters.registry import resolve as resolve_adapter
from allowlist_check import check_tierb_allowlist
from pack_edit import apply_updates, load_pack
from runlog import AdapterFillRow, RunlogPayload, UpdateRow, write_runlog
from utils import (
    ensure,
    load_json,
    log_stdout,
    normalize_path,
    now_iso,
    now_stamp,
    project_root,
    run_command,
    url_domains_summary,
)


def _schema_path() -> Path:
    return Path(__file__).resolve().parent / "plan_schema.v1.json"


def _default_jobs_path() -> Path:
    return Path(__file__).resolve().parent / "default_report_jobs.v1.json"


def _machine_dir() -> Path:
    return project_root() / "04 - Data & Ontology" / "Ontology" / "_machine"


def _canonical_pack_dir() -> Path:
    return _machine_dir() / "country_packs"


def _indicator_catalog() -> list[dict]:
    catalog_path = _machine_dir() / "indicator_catalog.v1.json"
    payload = load_json(catalog_path)
    return payload if isinstance(payload, list) else []


def normalize_plan(plan: dict) -> tuple[dict, str | None]:
    scope = plan.get("scope", {})
    indicators = scope.get("indicators")
    if indicators == "ALL":
        catalog = _indicator_catalog()
        ids = sorted({entry.get("id") for entry in catalog if entry.get("id")})
        scope["indicators"] = ids
        plan["scope"] = scope
        return plan, f"scope.indicators expanded from ALL: {len(ids)} indicators"
    return plan, None


def resolve_scope(plan: dict) -> list[str]:
    scope = plan.get("scope", {})
    indicators = scope.get("indicators") or []
    domains = scope.get("domains") or []

    if indicators:
        return sorted(set(indicators))

    if domains:
        catalog = _indicator_catalog()
        resolved = [
            entry.get("id")
            for entry in catalog
            if entry.get("domain") in domains and entry.get("id")
        ]
        return sorted(set(resolved))

    return []


def _adapter_jobs(plan: dict) -> list[dict]:
    fills = plan.get("fills", {})
    jobs = fills.get("adapters") if isinstance(fills, dict) else None
    return jobs if isinstance(jobs, list) else []


def _is_todo_value(value: object) -> bool:
    if value is None:
        return True
    if isinstance(value, str) and value.strip().upper() in {"", "TODO", "TBD"}:
        return True
    return False


def validate_plan(plan: dict, plan_path: Path) -> tuple[list[str], list[str]]:
    errors = []
    warnings = []

    if plan.get("plan_version") != "plan.v1":
        errors.append("plan_version must be 'plan.v1'")

    if not isinstance(plan.get("created_at"), str):
        errors.append("created_at must be an ISO datetime string")

    iso = plan.get("country_iso3")
    if not isinstance(iso, str) or len(iso) != 3:
        errors.append("country_iso3 must be a 3-letter ISO code")

    pack_path = plan.get("target_pack_path")
    if not isinstance(pack_path, str) or not pack_path:
        errors.append("target_pack_path is required")
    else:
        resolved = normalize_path(pack_path)
        placeholder = "xxx.v1.yaml" in pack_path and plan.get("country_iso3") == "XXX"
        if not placeholder and not resolved.exists():
            errors.append(f"target_pack_path does not exist: {resolved}")

    scope_list = resolve_scope(plan)
    if not scope_list:
        errors.append("scope.indicators or scope.domains must resolve to indicators")

    updates = plan.get("updates")
    if updates is None:
        updates = []
    if not isinstance(updates, list):
        errors.append("updates must be an array")
        return errors, warnings

    adapter_jobs = _adapter_jobs(plan)
    report_only = len(updates) == 0 and not adapter_jobs
    if report_only:
        return errors, warnings

    scope_indicators = plan.get("scope", {}).get("indicators") or []
    if not scope_indicators:
        errors.append("scope.indicators must list all indicators being updated")

    seen = set()
    for update in updates:
        if not isinstance(update, dict):
            errors.append("update entries must be objects")
            continue
        indicator_id = update.get("indicator_id")
        if not indicator_id:
            errors.append("update.indicator_id is required")
            continue
        if indicator_id in seen:
            errors.append(f"duplicate update indicator_id: {indicator_id}")
        seen.add(indicator_id)

        if scope_indicators and indicator_id not in scope_indicators:
            errors.append(
                f"update indicator_id not in scope.indicators: {indicator_id}"
            )
        elif scope_list and indicator_id not in scope_list:
            errors.append(f"update indicator_id not in resolved scope: {indicator_id}")

        set_block = update.get("set")
        if not isinstance(set_block, dict):
            errors.append(f"update.set required for {indicator_id}")
            continue

        for key in ["value", "retrieved_date", "url", "source_institution"]:
            if key not in set_block:
                errors.append(f"update.set.{key} missing for {indicator_id}")

        tier = set_block.get("evidence_tier", "A")
        notes = set_block.get("notes", "")
        if tier == "B" and not notes:
            errors.append(f"notes required for Tier B update {indicator_id}")

        if update.get("transform") and not notes:
            errors.append(f"notes required for transformed update {indicator_id}")

    for job in adapter_jobs:
        if not isinstance(job, dict):
            errors.append("fills.adapters entries must be objects")
            continue
        indicator_id = job.get("indicator_id")
        country_pack = job.get("country_pack")
        country_iso3 = job.get("country_iso3")
        mode = job.get("mode")
        if not indicator_id:
            errors.append("fills.adapters.indicator_id is required")
            continue
        if not country_pack:
            errors.append(f"fills.adapters.country_pack missing for {indicator_id}")
        if not country_iso3:
            errors.append(f"fills.adapters.country_iso3 missing for {indicator_id}")
        if mode != "latest":
            errors.append(f"fills.adapters.mode must be 'latest' for {indicator_id}")
        if scope_indicators and indicator_id not in scope_indicators:
            errors.append(
                f"fills.adapters.indicator_id not in scope.indicators: {indicator_id}"
            )
        elif scope_list and indicator_id not in scope_list:
            errors.append(
                f"fills.adapters.indicator_id not in resolved scope: {indicator_id}"
            )

        expected_tier = job.get("expected_evidence_tier")
        if expected_tier and expected_tier not in {"A", "B"}:
            errors.append(
                f"fills.adapters.expected_evidence_tier invalid for {indicator_id}"
            )

        preferred_year = job.get("preferred_year")
        fallback_year = job.get("fallback_year")
        if preferred_year is not None and not isinstance(preferred_year, int):
            errors.append(
                f"fills.adapters.preferred_year must be int for {indicator_id}"
            )
        if fallback_year is not None and not isinstance(fallback_year, int):
            errors.append(
                f"fills.adapters.fallback_year must be int for {indicator_id}"
            )

        snapshot_path = job.get("snapshot_path")
        if snapshot_path is not None and not isinstance(snapshot_path, str):
            errors.append(
                f"fills.adapters.snapshot_path must be string for {indicator_id}"
            )

        on_http_403 = job.get("on_http_403")
        if on_http_403 and on_http_403 not in {"skip", "use_snapshot", "fail"}:
            errors.append(f"fills.adapters.on_http_403 invalid for {indicator_id}")

    run_cfg = plan.get("run", {})
    if run_cfg.get("strict") is not True:
        errors.append("run.strict must be true")

    reports_cfg = run_cfg.get("reports")
    if reports_cfg is None:
        errors.append("run.reports is required")
    elif isinstance(reports_cfg, str):
        if reports_cfg != "all_six":
            errors.append("run.reports must be 'all_six' or a list of job IDs")
    elif isinstance(reports_cfg, list):
        if not reports_cfg:
            errors.append("run.reports list cannot be empty")
    else:
        errors.append("run.reports must be 'all_six' or a list of job IDs")

    return errors, warnings


def load_plan(plan_path: Path) -> dict:
    return json.loads(plan_path.read_text(encoding="utf-8"))


def print_validation(plan: dict, plan_path: Path):
    normalized, _ = normalize_plan(plan)
    errors, warnings = validate_plan(normalized, plan_path)
    if errors:
        log_stdout("PLAN_VALIDATION_FAILED")
        for err in errors:
            log_stdout(f"- {err}")
        sys.exit(1)

    pack_path = normalize_path(normalized["target_pack_path"])
    scope_list = resolve_scope(normalized)
    log_stdout("PLAN_VALIDATION_OK")
    log_stdout(f"- plan_path: {plan_path}")
    log_stdout(f"- target_pack_path: {pack_path}")
    log_stdout(f"- indicator_count: {len(scope_list)}")


def scaffold_plan(
    country_iso3: str, domains: list[str], out_path: Path, pack_path: str
):
    plan = {
        "plan_version": "plan.v1",
        "created_at": now_iso(),
        "country_iso3": country_iso3.upper(),
        "target_pack_path": pack_path,
        "scope": {
            "domains": domains,
            "indicators": [],
        },
        "updates": [],
        "run": {
            "strict": True,
            "reports": "all_six",
            "rebuild_site_export": True,
            "generate_memos": True,
            "dry_run": False,
        },
    }

    scope_ids = resolve_scope(plan)
    plan["scope"]["indicators"] = scope_ids
    for ind_id in scope_ids:
        plan["updates"].append(
            {
                "indicator_id": ind_id,
                "set": {
                    "value": None,
                    "year": None,
                    "retrieved_date": "YYYY-MM-DD",
                    "url": "",
                    "source_institution": "",
                    "notes": "",
                    "evidence_tier": "A",
                },
            }
        )

    out_path.write_text(json.dumps(plan, indent=2), encoding="utf-8")
    log_stdout(f"PLAN_SCAFFOLDED: {out_path}")


def _build_command(*parts: str) -> list[str]:
    return [part for part in parts if part]


def _cmd_to_str(cmd: list[str]) -> str:
    return shlex.join(cmd)


def _is_relative_to(path: Path, base: Path) -> bool:
    try:
        path.relative_to(base)
        return True
    except ValueError:
        return False


def _healthcheck_runlog_path() -> Path:
    return (
        project_root()
        / "08 - Operations"
        / "fill_runner"
        / "runlogs"
        / f"fill_runner_healthcheck_{now_stamp()}.txt"
    )


def _healthcheck_summary_path(stamp: str) -> Path:
    return (
        project_root()
        / "08 - Operations"
        / "fill_runner"
        / "runlogs"
        / f"fill_runner_healthcheck_{stamp}.summary.json"
    )


def _first_non_ws_char(raw: bytes) -> str | None:
    data = raw
    if data.startswith(b"\xef\xbb\xbf"):
        data = data[3:]
    for byte in data:
        char = chr(byte)
        if char.isspace():
            continue
        return char
    return None


def _scan_packs(pack_dir: Path) -> list[dict]:
    results = []
    for pack_path in sorted(pack_dir.glob("*.v1.yaml")):
        raw = pack_path.read_bytes()[:256]
        first = _first_non_ws_char(raw)
        header_corrupt = False
        header_hint = ""
        if first is None:
            header_corrupt = True
            header_hint = "Pack header corruption: empty file."
        elif first == "Z":
            header_corrupt = True
            header_hint = (
                "Pack header corruption: unexpected leading char(s). "
                "Likely stray `Z` prefix. Fix by removing leading `Z`."
            )
        elif first not in ("{", "-", "?", "%", "["):
            header_corrupt = True
            header_hint = (
                "Pack header corruption: unexpected leading char(s). "
                f"First non-whitespace char '{first}'. Expected '{{' or a YAML token. "
                "Likely stray `Z` prefix. Fix by removing leading `Z`."
            )

        parse_ok = True
        parse_error = ""
        text = pack_path.read_text(encoding="utf-8")
        try:
            json.loads(text)
        except json.JSONDecodeError:
            try:
                import yaml  # type: ignore

                yaml.safe_load(text)
            except Exception as exc:
                parse_ok = False
                parse_error = str(exc)

        results.append(
            {
                "pack": str(pack_path),
                "header_corrupt": header_corrupt,
                "header_hint": header_hint,
                "parse_ok": parse_ok,
                "parse_error": parse_error,
            }
        )
    return results


def _parse_batch_counts(runlog_path: Path) -> dict:
    summary = {
        "reports": 0,
        "memo_json": 0,
        "memo_md": 0,
        "export_status": "",
        "export_counts": "",
    }
    for line in runlog_path.read_text(encoding="utf-8").splitlines():
        if line.startswith("Reports generated:"):
            summary["reports"] = int(line.split(":", 1)[1].strip())
        if line.startswith("Memos generated (JSON):"):
            summary["memo_json"] = int(line.split(":", 1)[1].strip())
        if line.startswith("Memos generated (MD):"):
            summary["memo_md"] = int(line.split(":", 1)[1].strip())
        if line.startswith("Final site export:"):
            summary["export_status"] = line.split(":", 1)[1].strip()
        if line.startswith("Final export counts:"):
            summary["export_counts"] = line.split(":", 1)[1].strip()
    return summary


def _report_paths_for_plan(plan: dict) -> list[str]:
    run_cfg = plan.get("run", {})
    reports_cfg = run_cfg.get("reports")
    if not reports_cfg:
        return []
    jobs_payload = load_json(_default_jobs_path())
    jobs = jobs_payload.get("jobs", []) if isinstance(jobs_payload, dict) else []
    jobs_by_id = {job.get("id"): job for job in jobs}
    job_ids = (
        [job.get("id") for job in jobs] if reports_cfg == "all_six" else reports_cfg
    )
    report_files = []
    for job_id in job_ids:
        job = jobs_by_id.get(job_id)
        if not job:
            continue
        out_path = (job.get("args") or {}).get("out")
        if out_path:
            report_files.append(out_path)
    return report_files


def compute_memo_uniques_and_collisions(
    report_files: list[str],
) -> tuple[set[str], set[str], list[dict]]:
    memo_json_paths: set[str] = set()
    memo_md_paths: set[str] = set()
    collisions = []
    seen_json = {}
    seen_md = {}
    for report_rel in report_files:
        report_name = Path(report_rel).name
        suffix = ".report.v1.json"
        if report_name.endswith(suffix):
            base = report_name[: -len(suffix)]
        else:
            base = Path(report_name).stem
        memo_base = f"{base}.memo.v1"
        memo_json = f"04 - Data & Ontology/Ontology/_machine/memos/{memo_base}.json"
        memo_md = (
            f"04 - Data & Ontology/Ontology/_machine/memos/rendered/{memo_base}.md"
        )

        if memo_json in memo_json_paths:
            if seen_json.get(memo_json) != report_rel:
                collisions.append(
                    {
                        "memo_path": memo_json,
                        "kind": "json",
                        "first_report": seen_json.get(memo_json),
                        "second_report": report_rel,
                    }
                )
        else:
            memo_json_paths.add(memo_json)
            seen_json[memo_json] = report_rel

        if memo_md in memo_md_paths:
            if seen_md.get(memo_md) != report_rel:
                collisions.append(
                    {
                        "memo_path": memo_md,
                        "kind": "md",
                        "first_report": seen_md.get(memo_md),
                        "second_report": report_rel,
                    }
                )
        else:
            memo_md_paths.add(memo_md)
            seen_md[memo_md] = report_rel

    return memo_json_paths, memo_md_paths, collisions


def _memo_parity(project: Path) -> dict:
    vault_memo_json = list(
        (project / "04 - Data & Ontology" / "Ontology" / "_machine" / "memos").glob(
            "*.memo.v1.json"
        )
    )
    vault_memo_md = list(
        (
            project
            / "04 - Data & Ontology"
            / "Ontology"
            / "_machine"
            / "memos"
            / "rendered"
        ).glob("*.memo.v1.md")
    )
    export_root = project / "09 - Publishing" / "site_export" / "v1"
    export_memo_json = (
        list((export_root / "memos").glob("*.memo.v1.json"))
        if export_root.exists()
        else []
    )
    export_memo_md = (
        list((export_root / "memos" / "rendered").glob("*.memo.v1.md"))
        if export_root.exists()
        else []
    )

    index_path = export_root / "index" / "index.reports.v1.json"
    index_json = load_json(index_path) if index_path.exists() else {}
    report_entries = (
        index_json.get("reports", []) if isinstance(index_json, dict) else []
    )
    index_json_refs = sum(1 for entry in report_entries if entry.get("memo_json_path"))
    index_md_refs = sum(1 for entry in report_entries if entry.get("memo_md_path"))

    diagnosis = "ok"
    if len(vault_memo_json) > len(export_memo_json) or len(vault_memo_md) > len(
        export_memo_md
    ):
        diagnosis = "export copy/sync missing memos"
    if len(export_memo_json) > index_json_refs or len(export_memo_md) > index_md_refs:
        diagnosis = "index not referencing memos"
    if index_json_refs > len(export_memo_json) or index_md_refs > len(export_memo_md):
        diagnosis = "index paths point to missing files"

    return {
        "vault_memo_json": len(vault_memo_json),
        "vault_memo_md": len(vault_memo_md),
        "export_memo_json": len(export_memo_json),
        "export_memo_md": len(export_memo_md),
        "index_memo_json_refs": index_json_refs,
        "index_memo_md_refs": index_md_refs,
        "diagnosis": diagnosis,
    }


def _resolve_adapter_updates(plan: dict) -> None:
    adapter = EnterpriseSurveysAdapter()
    iso3 = plan.get("country_iso3", "")
    for update in plan.get("updates", []):
        provenance = update.get("provenance") or {}
        adapter_name = provenance.get("adapter")
        query = provenance.get("query")
        if adapter_name != "enterprise_surveys" or not query:
            continue
        result = adapter.fetch(iso3, query)
        source_urls = [source.url for source in result.sources if source.url]
        source_url = " | ".join(source_urls)
        retrieved_date = (
            result.sources[0].retrieved_at
            if result.sources
            else now_iso().split("T")[0]
        )
        if "T" in retrieved_date:
            retrieved_date = retrieved_date.split("T")[0]
        if "T" in retrieved_date:
            retrieved_date = retrieved_date.split("T")[0]
        set_block = update.get("set", {})
        set_block["value"] = result.value
        if result.unit is not None:
            set_block["unit"] = result.unit
        set_block["url"] = source_url
        set_block["retrieved_date"] = retrieved_date
        set_block["source_institution"] = result.source_institution
        set_block["notes"] = result.method_note
        set_block.setdefault("evidence_tier", result.evidence_tier)
        update["set"] = set_block


def _build_adapter_updates(
    plan: dict,
    scope_list: list[str],
    canonical_dir: Path,
) -> tuple[dict[Path, list[dict]], list[AdapterFillRow]]:
    updates_by_pack: dict[Path, list[dict]] = {}
    fill_rows: list[AdapterFillRow] = []
    for job in _adapter_jobs(plan):
        indicator_id = job.get("indicator_id")
        country_iso3 = job.get("country_iso3")
        pack_rel = job.get("country_pack")
        allow_overwrite = bool(job.get("allow_overwrite", False))
        expected_tier = job.get("expected_evidence_tier")
        preferred_year = job.get("preferred_year")
        fallback_year = job.get("fallback_year")
        snapshot_path = job.get("snapshot_path")
        on_http_403 = job.get("on_http_403") or "skip"
        job_options = job.get("options") or {}

        if not indicator_id or not pack_rel or not country_iso3:
            continue
        if scope_list and indicator_id not in scope_list:
            raise RuntimeError(f"Adapter fill indicator outside scope: {indicator_id}")

        pack_path = normalize_path(pack_rel)
        ensure(pack_path.exists(), f"Adapter fill pack not found: {pack_path}")
        ensure(
            _is_relative_to(pack_path.resolve(), canonical_dir),
            f"country_pack must be under {canonical_dir}",
        )

        data, _, _ = load_pack(pack_path)
        indicators = data.get("indicators") if isinstance(data, dict) else None
        entry = indicators.get(indicator_id) if isinstance(indicators, dict) else None
        ensure(entry is not None, f"Indicator not found in pack: {indicator_id}")

        old_value = entry.get("value")
        if not allow_overwrite and not _is_todo_value(old_value):
            adapter = resolve_adapter(indicator_id)
            adapter_name = adapter.name if adapter else "unknown"
            fill_rows.append(
                AdapterFillRow(
                    indicator_id=indicator_id,
                    country_iso3=country_iso3,
                    country_pack=pack_rel,
                    adapter_name=adapter_name,
                    action="skipped",
                    old_value=str(old_value),
                    new_value="(unchanged)",
                    evidence_tier=expected_tier or "A",
                    source_url="",
                    sha256="",
                    cache_hit=False,
                    stale_used=False,
                    method_note="Skipped (allow_overwrite=false; existing value present).",
                    skip_reason="allow_overwrite_false_existing_value",
                )
            )
            continue

        adapter = resolve_adapter(indicator_id)
        ensure(
            adapter is not None, f"No adapter registered for indicator: {indicator_id}"
        )
        adapter_name = adapter.name
        result = adapter.fetch(
            country_iso3,
            indicator_id,
            preferred_year=preferred_year,
            fallback_year=fallback_year,
            snapshot_path=snapshot_path,
            on_http_403=on_http_403,
            **job_options,
        )

        if isinstance(result, AdapterSkip):
            fill_rows.append(
                AdapterFillRow(
                    indicator_id=indicator_id,
                    country_iso3=country_iso3,
                    country_pack=pack_rel,
                    adapter_name=result.adapter,
                    action="skipped",
                    old_value=str(old_value),
                    new_value="(unchanged)",
                    evidence_tier=expected_tier or "A",
                    source_url="",
                    sha256="",
                    cache_hit=False,
                    stale_used=False,
                    method_note="Adapter skipped",
                    skip_reason=result.reason,
                    snapshot_attempted=result.snapshot_attempted,
                    snapshot_used=result.snapshot_used,
                )
            )
            continue

        if result is None:
            fill_rows.append(
                AdapterFillRow(
                    indicator_id=indicator_id,
                    country_iso3=country_iso3,
                    country_pack=pack_rel,
                    adapter_name=adapter_name,
                    action="skipped",
                    old_value=str(old_value),
                    new_value="(unchanged)",
                    evidence_tier=expected_tier or "A",
                    source_url="",
                    sha256="",
                    cache_hit=False,
                    stale_used=False,
                    method_note="Adapter returned no result",
                    skip_reason="adapter_returned_none",
                    snapshot_attempted=bool(snapshot_path),
                    snapshot_used=False,
                )
            )
            continue

        if expected_tier and result.evidence_tier != expected_tier:
            raise RuntimeError(
                "Adapter evidence tier mismatch for "
                f"{indicator_id}: expected {expected_tier}, got {result.evidence_tier}"
            )

        if result.evidence_tier == "B":
            if result.confidence > 0.6:
                raise RuntimeError(
                    f"Tier B confidence must be <= 0.6 for {indicator_id}."
                )
            if "FLAG-TIERB-PRESENT" not in result.flags:
                raise RuntimeError(
                    f"Tier B result missing FLAG-TIERB-PRESENT for {indicator_id}."
                )

        sources = result.sources or []
        source_urls = [source.url for source in sources if source.url]
        source_url = " | ".join(source_urls)
        retrieved_date = sources[0].retrieved_at if sources else now_iso().split("T")[0]
        if "T" in retrieved_date:
            retrieved_date = retrieved_date.split("T")[0]
        notes = result.method_note
        if job.get("note"):
            notes = f"{notes} {job['note']}".strip()

        set_block = {
            "value": result.value,
            "retrieved_date": retrieved_date,
            "url": source_url,
            "source_institution": result.source_institution,
            "notes": notes,
            "evidence_tier": result.evidence_tier,
        }
        if result.unit is not None:
            set_block["unit"] = result.unit
        if "confidence" in entry:
            set_block["confidence"] = result.confidence

        updates_by_pack.setdefault(pack_path, []).append(
            {"indicator_id": indicator_id, "set": set_block}
        )

        primary_source = sources[0] if sources else None
        fill_rows.append(
            AdapterFillRow(
                indicator_id=indicator_id,
                country_iso3=country_iso3,
                country_pack=pack_rel,
                adapter_name=adapter_name,
                action="applied",
                old_value=str(old_value),
                new_value=str(result.value),
                evidence_tier=result.evidence_tier,
                source_url=primary_source.url if primary_source else source_url,
                sha256=primary_source.sha256 if primary_source else "",
                cache_hit=bool(primary_source.cache_hit) if primary_source else False,
                stale_used=bool(primary_source.stale_used) if primary_source else False,
                method_note=result.method_note,
                snapshot_attempted=bool(snapshot_path),
                snapshot_used=primary_source.url.startswith("snapshot:")
                if primary_source
                else False,
            )
        )

    return updates_by_pack, fill_rows


def _count_runlog_outputs(runlog_path: Path | None) -> tuple[int, int, int]:
    if runlog_path is None or not runlog_path.exists():
        return 0, 0, 0
    section = None
    reports = 0
    memo_json = 0
    memo_md = 0
    for line in runlog_path.read_text(encoding="utf-8").splitlines():
        if line == "- Reports:":
            section = "reports"
            continue
        if line == "- Memos (JSON):":
            section = "memo_json"
            continue
        if line == "- Memos (MD):":
            section = "memo_md"
            continue
        if line.startswith("-") and not line.startswith("  - "):
            section = None
        if line.startswith("  - "):
            if section == "reports":
                reports += 1
            elif section == "memo_json":
                memo_json += 1
            elif section == "memo_md":
                memo_md += 1
    return reports, memo_json, memo_md


def apply_plan(
    plan_path: Path,
    dry_run: bool | None = None,
    plan_override: dict | None = None,
) -> Path | None:
    plan = plan_override if plan_override is not None else load_plan(plan_path)
    plan, scope_note = normalize_plan(plan)
    errors, _ = validate_plan(plan, plan_path)
    if errors:
        log_stdout("PLAN_VALIDATION_FAILED")
        for err in errors:
            log_stdout(f"- {err}")
        raise RuntimeError("Plan validation failed")

    run_cfg = plan["run"]
    if dry_run is None:
        dry_run = bool(run_cfg.get("dry_run"))

    updates = plan.get("updates") or []
    adapter_jobs = _adapter_jobs(plan)
    report_only = len(updates) == 0 and not adapter_jobs

    pack_path = normalize_path(plan["target_pack_path"])
    project = project_root()
    canonical_dir = _canonical_pack_dir().resolve()
    if not report_only:
        ensure(
            _is_relative_to(pack_path.resolve(), canonical_dir),
            f"target_pack_path must be under {canonical_dir}",
        )

    adapter_fill_rows: list[AdapterFillRow] = []
    updates_by_pack: dict[Path, list[dict]] = {}

    if not report_only:
        scope_indicators = plan.get("scope", {}).get("indicators") or []
        ensure(
            scope_indicators,
            "scope.indicators must list all indicators being updated",
        )
        update_ids = [update.get("indicator_id") for update in updates]
        extra = [ind_id for ind_id in update_ids if ind_id not in scope_indicators]
        ensure(not extra, f"Updates exceed scope.indicators: {', '.join(extra)}")

        _resolve_adapter_updates(plan)

        if updates:
            updates_by_pack[pack_path] = updates

        scope_list = resolve_scope(plan)
        adapter_updates, adapter_fill_rows = _build_adapter_updates(
            plan, scope_list, canonical_dir
        )
        for path, adapter_updates_list in adapter_updates.items():
            updates_by_pack.setdefault(path, []).extend(adapter_updates_list)

        for pack_updates in updates_by_pack.values():
            check_tierb_allowlist(project, pack_updates)

        if updates_by_pack:
            all_changes = []
            for pack_target, pack_updates in updates_by_pack.items():
                changes = apply_updates(pack_target, pack_updates, dry_run=dry_run)
                all_changes.extend(changes)
                if dry_run:
                    log_stdout(f"DRY_RUN_DIFF ({pack_target})")
                    if not changes:
                        log_stdout("- no changes detected")
                    for change in changes:
                        log_stdout(
                            f"- {change.indicator_id} | {change.field}: {change.before} -> {change.after}"
                        )
            if dry_run:
                return None
    elif dry_run:
        log_stdout("DRY_RUN_REPORT_ONLY")
        return None

    commands: list[str] = []
    python = sys.executable
    strict_out = ""

    if not report_only:
        schema_path = (
            project
            / "04 - Data & Ontology"
            / "Ontology"
            / "_machine"
            / "country_pack.schema.v1.json"
        )
        validator = project / "08 - Operations" / "scripts" / "validate_country_pack.py"

        pack_targets = list(updates_by_pack.keys()) or [pack_path]
        strict_outputs = []
        for target in pack_targets:
            strict_cmd = _build_command(
                python,
                str(validator),
                str(schema_path),
                str(target),
            )
            commands.append(_cmd_to_str(strict_cmd))
            code, strict_out = run_command(strict_cmd)
            strict_outputs.append(strict_out.strip())
            if code != 0:
                log_stdout("STRICT_VALIDATION_FAILED")
                log_stdout(strict_out)
                raise RuntimeError("Strict validation failed")
        strict_out = "\n".join(output for output in strict_outputs if output)

    report_files = []
    memo_json_files = []
    memo_md_files = []
    memo_json_unique = set()
    memo_md_unique = set()
    memo_collisions = []
    reports_cfg = run_cfg.get("reports")
    if reports_cfg:
        jobs_payload = load_json(_default_jobs_path())
        jobs = jobs_payload.get("jobs", []) if isinstance(jobs_payload, dict) else []
        jobs_by_id = {job.get("id"): job for job in jobs}

        job_ids = (
            [job.get("id") for job in jobs] if reports_cfg == "all_six" else reports_cfg
        )
        for job_id in job_ids:
            job = jobs_by_id.get(job_id)
            ensure(job is not None, f"Report job not found: {job_id}")
            args = job.get("args", {})
            cmd = _build_command(
                python,
                str(
                    project
                    / "08 - Operations"
                    / "scripts"
                    / "generate_report_artifact.py"
                ),
                "--country-pack",
                args.get("country_pack", ""),
                "--case-id",
                args.get("case_id", ""),
                "--country",
                args.get("country", ""),
                "--sector",
                args.get("sector", ""),
                "--role",
                args.get("role", ""),
                "--mode",
                args.get("mode", ""),
                "--weight-profile",
                args.get("weight_profile", ""),
                "--overlay",
                args.get("overlay", ""),
                "--out",
                args.get("out", ""),
            )
            commands.append(_cmd_to_str(cmd))
            code, output = run_command(cmd)
            if code != 0:
                log_stdout(output)
                raise RuntimeError(f"Report job failed: {job_id}")
            if args.get("out"):
                report_files.append(args["out"])

    if run_cfg.get("generate_memos") and not dry_run:
        memo_script = (
            project
            / "08 - Operations"
            / "fill_runner"
            / "memo_generator"
            / "generate_memo.py"
        )
        for report_rel in report_files:
            report_path = project / report_rel
            ensure(
                report_path.exists(),
                f"Report file not found for memo generation: {report_path}",
            )
            cmd = _build_command(
                python,
                str(memo_script),
                "--report",
                str(report_path),
            )
            commands.append(_cmd_to_str(cmd))
            code, output = run_command(cmd)
            if code != 0:
                log_stdout(output)
                raise RuntimeError(f"Memo generation failed for {report_rel}")

            report_name = Path(report_rel).name
            suffix = ".report.v1.json"
            if report_name.endswith(suffix):
                base = report_name[: -len(suffix)]
            else:
                base = Path(report_name).stem
            memo_base = f"{base}.memo.v1"
            memo_json_files.append(
                f"04 - Data & Ontology/Ontology/_machine/memos/{memo_base}.json"
            )
            memo_md_files.append(
                f"04 - Data & Ontology/Ontology/_machine/memos/rendered/{memo_base}.md"
            )

    memo_json_unique, memo_md_unique, memo_collisions = (
        compute_memo_uniques_and_collisions(report_files)
    )

    site_export_summary = None
    if run_cfg.get("rebuild_site_export"):
        build_cmd = _build_command(
            python,
            str(project / "09 - Publishing" / "site_export" / "build_site_export.py"),
        )
        commands.append(_cmd_to_str(build_cmd))
        code, output = run_command(build_cmd)
        if code != 0:
            log_stdout(output)
            raise RuntimeError("site_export build failed")

        validate_cmd = _build_command(
            python,
            str(
                project / "09 - Publishing" / "site_export" / "validate_site_export.py"
            ),
        )
        commands.append(_cmd_to_str(validate_cmd))
        code, output = run_command(validate_cmd)
        if code != 0:
            log_stdout(output)
            raise RuntimeError("site_export validate failed")

        payloads = None
        evidence = None
        for line in output.splitlines():
            if line.startswith("payloads:"):
                payloads = line.split(":", 1)[1].strip()
            if line.startswith("evidence_files:"):
                evidence = line.split(":", 1)[1].strip()
        if payloads or evidence:
            site_export_summary = f"payloads: {payloads or 'unknown'} | evidence_files: {evidence or 'unknown'}"
        else:
            site_export_summary = output.strip() or "VALIDATION_PASS"

    update_rows = []
    for update in updates:
        set_block = update["set"]
        transform = update.get("transform") or {}
        update_rows.append(
            UpdateRow(
                indicator_id=update["indicator_id"],
                evidence_tier=set_block.get("evidence_tier", "A"),
                value=str(set_block.get("value")),
                url=set_block.get("url", ""),
                retrieved_date=set_block.get("retrieved_date", ""),
                notes=set_block.get("notes", ""),
                transform=transform.get("formula"),
            )
        )

    runlog_payload = RunlogPayload(
        plan_path=plan_path,
        country_iso3=plan.get("country_iso3", "UNK"),
        working_dir=project,
        strict_status="SKIPPED_REPORT_ONLY" if report_only else "OK",
        strict_output=strict_out,
        report_only=report_only,
        scope_expansion_note=scope_note,
        commands=commands,
        report_files=report_files,
        memo_json_files=memo_json_files,
        memo_md_files=memo_md_files,
        memo_json_unique_count=len(memo_json_unique),
        memo_md_unique_count=len(memo_md_unique),
        memo_collisions=memo_collisions,
        site_export_summary=site_export_summary,
        updates=update_rows,
        adapter_fills=adapter_fill_rows,
    )

    runlog_path = write_runlog(runlog_payload, _machine_dir())
    log_stdout(f"RUNLOG_WRITTEN: {runlog_path}")
    return runlog_path


def apply_batch(
    plans_dir: Path,
    pattern: str,
    continue_on_error: bool,
    dry_run: bool,
    export_once: bool,
) -> Path:
    plans = sorted(plans_dir.glob(pattern))
    commands = []
    results = []
    ok = 0
    fail = 0
    total_reports = 0
    total_memo_json = 0
    total_memo_md = 0
    batch_report_files: list[str] = []
    batch_memo_collisions: list[dict] = []
    export_summary = ""
    export_status = "SKIPPED"

    for plan_path in plans:
        validate_cmd = _cmd_to_str(
            _build_command(
                sys.executable,
                str(Path(__file__).resolve()),
                "validate-plan",
                "--plan",
                str(plan_path),
            )
        )
        apply_cmd = _cmd_to_str(
            _build_command(
                sys.executable,
                str(Path(__file__).resolve()),
                "apply",
                "--plan",
                str(plan_path),
                "--dry-run" if dry_run else "",
            )
        )
        commands.extend([validate_cmd, apply_cmd])

        plan = load_plan(plan_path)
        plan, _ = normalize_plan(plan)
        errors, _ = validate_plan(plan, plan_path)
        if errors:
            fail += 1
            results.append((plan_path, "FAIL", "; ".join(errors)))
            break

        if export_once:
            run_cfg = plan.get("run", {})
            if isinstance(run_cfg, dict):
                run_cfg["rebuild_site_export"] = False
                plan["run"] = run_cfg

        try:
            runlog_path = apply_plan(
                plan_path,
                dry_run=dry_run,
                plan_override=plan if export_once else None,
            )
            ok += 1
            results.append((plan_path, "OK", ""))
            if runlog_path:
                rep_count, memo_json_count, memo_md_count = _count_runlog_outputs(
                    runlog_path
                )
                total_reports += rep_count
                total_memo_json += memo_json_count
                total_memo_md += memo_md_count
            batch_report_files.extend(_report_paths_for_plan(plan))
        except Exception as exc:
            fail += 1
            results.append((plan_path, "FAIL", str(exc)))
            if not continue_on_error:
                break

    if export_once and not dry_run and fail == 0 and ok > 0:
        project = project_root()
        build_cmd = _build_command(
            sys.executable,
            str(project / "09 - Publishing" / "site_export" / "build_site_export.py"),
        )
        commands.append(_cmd_to_str(build_cmd))
        code, output = run_command(build_cmd)
        if code != 0:
            export_status = "BUILD_FAILED"
        else:
            validate_cmd = _build_command(
                sys.executable,
                str(
                    project
                    / "09 - Publishing"
                    / "site_export"
                    / "validate_site_export.py"
                ),
            )
            commands.append(_cmd_to_str(validate_cmd))
            code, output = run_command(validate_cmd)
            if code != 0:
                export_status = "VALIDATE_FAILED"
            else:
                export_status = "VALIDATION_PASS"
            payloads = None
            evidence = None
            memo_json = None
            memo_md = None
            for line in output.splitlines():
                if line.startswith("payloads:"):
                    payloads = line.split(":", 1)[1].strip()
                if line.startswith("evidence_files:"):
                    evidence = line.split(":", 1)[1].strip()
                if line.startswith("memo_json_files:"):
                    memo_json = line.split(":", 1)[1].strip()
                if line.startswith("memo_md_files:"):
                    memo_md = line.split(":", 1)[1].strip()
            if payloads or evidence or memo_json or memo_md:
                export_summary = (
                    f"payloads: {payloads or 'unknown'} | evidence_files: {evidence or 'unknown'} | "
                    f"memo_json_files: {memo_json or 'unknown'} | memo_md_files: {memo_md or 'unknown'}"
                )
    elif export_once:
        export_status = "SKIPPED"

    runlog_path = _machine_dir() / "runlogs" / f"fill_runner_batch_{now_stamp()}.txt"
    lines = []
    lines.append("AI Fill Runner Batch Runlog")
    lines.append(f"Working directory: {project_root()}")
    lines.append(f"Plans dir: {plans_dir}")
    lines.append(f"Pattern: {pattern}")
    lines.append(f"Export once: {str(export_once).lower()}")
    lines.append("")
    lines.append("Plans processed")
    if not results:
        lines.append("- none")
    for plan_path, status, details in results:
        suffix = f" | {details}" if details else ""
        lines.append(f"- {plan_path} | {status}{suffix}")
    lines.append("")
    lines.append(f"Totals: ok={ok} fail={fail}")
    memo_json_unique, memo_md_unique, batch_memo_collisions = (
        compute_memo_uniques_and_collisions(batch_report_files)
    )
    lines.append(f"Reports generated: {total_reports}")
    lines.append(f"Memos generated (JSON, unique): {len(memo_json_unique)}")
    lines.append(f"Memos generated (MD, unique): {len(memo_md_unique)}")
    if batch_memo_collisions:
        lines.append("Memo collisions (first 10):")
        for collision in batch_memo_collisions[:10]:
            lines.append(
                "- "
                f"[{collision.get('kind')}] {collision.get('memo_path')} <- "
                f"{collision.get('first_report')} & {collision.get('second_report')}"
            )
    else:
        lines.append("Memo collisions: none")
    if export_once:
        lines.append(f"Final site export: {export_status}")
        if export_summary:
            lines.append(f"Final export counts: {export_summary}")
    lines.append("")
    lines.append("Commands executed")
    for cmd in commands:
        lines.append(f"- {cmd}")

    runlog_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return runlog_path


def healthcheck(
    packs: bool,
    strict_validate: bool,
    run_report_only: bool,
    plans: list[str] | None,
    export_once: bool,
    fail_fast: bool,
    json_summary: bool,
) -> int:
    project = project_root()
    runlog_path = _healthcheck_runlog_path()
    runlog_path.parent.mkdir(parents=True, exist_ok=True)
    stamp = runlog_path.stem.split("fill_runner_healthcheck_", 1)[-1]
    summary_path = _healthcheck_summary_path(stamp)

    pack_results = []
    strict_results = []
    report_only_result = {}
    memo_parity = {}
    memo_collisions: list[dict] = []
    export_validation = {}
    failures = []

    if packs:
        pack_dir = (
            project / "04 - Data & Ontology" / "Ontology" / "_machine" / "country_packs"
        )
        pack_results = _scan_packs(pack_dir)
        header_failures = [res for res in pack_results if res["header_corrupt"]]
        parse_failures = [res for res in pack_results if not res["parse_ok"]]
        if header_failures:
            failures.append("pack_header_corruption")
        if parse_failures:
            failures.append("pack_parse_failure")

    if strict_validate:
        schema_path = (
            project
            / "04 - Data & Ontology"
            / "Ontology"
            / "_machine"
            / "country_pack.schema.v1.json"
        )
        validator = project / "08 - Operations" / "scripts" / "validate_country_pack.py"
        for res in pack_results:
            pack_path = res["pack"]
            cmd = [sys.executable, str(validator), str(schema_path), pack_path]
            code, output = run_command(cmd)
            status = "OK" if code == 0 else "FAIL"
            tail = "\n".join(output.splitlines()[-5:]) if output else ""
            strict_results.append(
                {
                    "pack": pack_path,
                    "status": status,
                    "tail": tail,
                }
            )
            if code != 0:
                failures.append(f"strict_validate_failed:{pack_path}")
                if fail_fast:
                    break

    if run_report_only and (not failures or not fail_fast):
        if plans:
            plan_paths = [normalize_path(path) for path in plans]
        else:
            plan_paths = [
                normalize_path(
                    "08 - Operations/fill_runner/examples/plan.report_only.verify.v1.json"
                ),
                normalize_path(
                    "08 - Operations/fill_runner/examples/plan.report_only.verify.b.v1.json"
                ),
            ]

        report_only_result["plans"] = [str(path) for path in plan_paths]
        report_files = []
        for plan_path in plan_paths:
            plan = load_plan(plan_path)
            plan, _ = normalize_plan(plan)
            report_files.extend(_report_paths_for_plan(plan))
        memo_json_paths, memo_md_paths, memo_collisions = (
            compute_memo_uniques_and_collisions(report_files)
        )
        if export_once and len(plan_paths) > 1:
            temp_dir = (
                project
                / "04 - Data & Ontology"
                / "Ontology"
                / "_machine"
                / "cache"
                / f"healthcheck_plans_{stamp}"
            )
            temp_dir.mkdir(parents=True, exist_ok=True)
            for path in plan_paths:
                shutil.copy2(path, temp_dir / path.name)
            runlog = apply_batch(
                temp_dir,
                "*.json",
                continue_on_error=not fail_fast,
                dry_run=False,
                export_once=True,
            )
            report_only_result["batch_runlog"] = str(runlog)
            report_only_result.update(_parse_batch_counts(runlog))
            report_only_result["memo_json"] = len(memo_json_paths)
            report_only_result["memo_md"] = len(memo_md_paths)
            if report_only_result.get("export_status") != "VALIDATION_PASS":
                failures.append("report_only_export_failed")
        else:
            total_reports = 0
            total_memo_json = 0
            total_memo_md = 0
            export_status = "SKIPPED"
            export_counts = ""
            plan_runlogs = []
            for path in plan_paths:
                runlog = apply_plan(path, dry_run=False)
                plan_runlogs.append(str(runlog) if runlog else "")
                rep_count, memo_json, memo_md = _count_runlog_outputs(runlog)
                total_reports += rep_count
                total_memo_json += memo_json
                total_memo_md += memo_md
                if fail_fast and runlog is None:
                    failures.append("report_only_failed")
                    break
            report_only_result.update(
                {
                    "plan_runlogs": plan_runlogs,
                    "reports": total_reports,
                    "memo_json": len(memo_json_paths),
                    "memo_md": len(memo_md_paths),
                    "export_status": export_status,
                    "export_counts": export_counts,
                }
            )
        if report_only_result:
            memo_parity = _memo_parity(project)

    export_root = project / "09 - Publishing" / "site_export" / "v1"
    if export_root.exists():
        validate_cmd = [
            sys.executable,
            str(
                project / "09 - Publishing" / "site_export" / "validate_site_export.py"
            ),
        ]
        code, output = run_command(validate_cmd)
        export_validation = {
            "status": "VALIDATION_PASS" if code == 0 else "VALIDATION_FAIL",
            "output": output,
        }
        if code != 0:
            failures.append("site_export_validate_failed")
    else:
        export_validation = {"status": "SKIPPED", "output": "site_export not found"}

    lines = []
    lines.append("AI Fill Runner Healthcheck")
    lines.append(f"Timestamp: {stamp}")
    lines.append(f"Working directory: {project}")
    lines.append("Config")
    lines.append(f"- packs: {str(packs).lower()}")
    lines.append(f"- strict_validate: {str(strict_validate).lower()}")
    lines.append(f"- run_report_only: {str(run_report_only).lower()}")
    lines.append(f"- export_once: {str(export_once).lower()}")
    lines.append(f"- fail_fast: {str(fail_fast).lower()}")
    lines.append("")

    if packs:
        header_corrupt = [res for res in pack_results if res["header_corrupt"]]
        parse_failures = [res for res in pack_results if not res["parse_ok"]]
        lines.append("Pack scan summary")
        lines.append(f"- total_packs: {len(pack_results)}")
        lines.append(f"- header_corrupt: {len(header_corrupt)}")
        lines.append(f"- parse_failures: {len(parse_failures)}")
        if header_corrupt:
            lines.append("- header_corrupt_files:")
            for res in header_corrupt:
                lines.append(f"  - {res['pack']}: {res['header_hint']}")
        if parse_failures:
            lines.append("- parse_fail_files:")
            for res in parse_failures:
                lines.append(f"  - {res['pack']}: {res['parse_error']}")
        lines.append("")

    if strict_validate:
        lines.append("Strict validation")
        for res in strict_results:
            lines.append(f"- {res['pack']}: {res['status']}")
            if res["status"] != "OK" and res["tail"]:
                for line in res["tail"].splitlines():
                    lines.append(f"  {line}")
        lines.append("")

    if run_report_only:
        lines.append("Report-only pipeline")
        for plan in report_only_result.get("plans", []):
            lines.append(f"- plan: {plan}")
        if report_only_result.get("batch_runlog"):
            lines.append(f"- batch_runlog: {report_only_result['batch_runlog']}")
        for key in (
            "reports",
            "memo_json",
            "memo_md",
            "export_status",
            "export_counts",
        ):
            if key in report_only_result:
                lines.append(f"- {key}: {report_only_result[key]}")
        if memo_collisions:
            lines.append("- memo_collisions: detected")
            lines.append(
                "- warning: Memo path collisions detected; counts reflect unique outputs."
            )
            for collision in memo_collisions:
                lines.append(
                    "  - "
                    f"[{collision.get('kind')}] {collision.get('memo_path')} <- "
                    f"{collision.get('first_report')} & {collision.get('second_report')}"
                )
        else:
            lines.append("- memo_collisions: none")
        lines.append("")
        if memo_parity:
            lines.append("Memo parity")
            lines.append(f"- vault_memo_json: {memo_parity['vault_memo_json']}")
            lines.append(f"- vault_memo_md: {memo_parity['vault_memo_md']}")
            lines.append(f"- export_memo_json: {memo_parity['export_memo_json']}")
            lines.append(f"- export_memo_md: {memo_parity['export_memo_md']}")
            lines.append(
                f"- index_memo_json_refs: {memo_parity['index_memo_json_refs']}"
            )
            lines.append(f"- index_memo_md_refs: {memo_parity['index_memo_md_refs']}")
            lines.append(f"- diagnosis: {memo_parity['diagnosis']}")
            lines.append("")

    lines.append("Site export validation")
    lines.append(f"- status: {export_validation.get('status')}")
    if export_validation.get("output"):
        for line in export_validation["output"].splitlines()[-6:]:
            lines.append(f"  {line}")
    lines.append("")

    final_status = "PASS" if not failures else "FAIL"
    lines.append(f"FINAL_STATUS: {final_status}")
    if failures:
        lines.append("Failures")
        for failure in failures:
            lines.append(f"- {failure}")

    runlog_path.write_text("\n".join(lines) + "\n", encoding="utf-8")

    if json_summary:
        payload = {
            "config": {
                "packs": packs,
                "strict_validate": strict_validate,
                "run_report_only": run_report_only,
                "export_once": export_once,
                "fail_fast": fail_fast,
            },
            "pack_scan": pack_results,
            "strict_validation": strict_results,
            "report_only": report_only_result,
            "memo_parity": memo_parity,
            "memo_collisions": memo_collisions,
            "site_export_validation": export_validation,
            "final_status": final_status,
            "failures": failures,
        }
        summary_path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")

    log_stdout(f"HEALTHCHECK_RUNLOG: {runlog_path}")
    if json_summary:
        log_stdout(f"HEALTHCHECK_SUMMARY_JSON: {summary_path}")

    return 0 if final_status == "PASS" else 1


def main():
    parser = argparse.ArgumentParser(description="AI Fill Runner v0")
    sub = parser.add_subparsers(dest="command", required=True)

    validate_parser = sub.add_parser("validate-plan", help="Validate plan file")
    validate_parser.add_argument("--plan", required=True)

    scaffold_parser = sub.add_parser("scaffold-plan", help="Create a plan scaffold")
    scaffold_parser.add_argument("--country", required=True)
    scaffold_parser.add_argument("--domains", required=True)
    scaffold_parser.add_argument("--out", required=True)
    scaffold_parser.add_argument(
        "--pack",
        required=True,
        help="Target pack path (required, pack filenames are not ISO-mapped).",
    )

    apply_parser = sub.add_parser("apply", help="Apply plan")
    apply_parser.add_argument("--plan", required=True)
    apply_parser.add_argument("--dry-run", action="store_true")

    batch_parser = sub.add_parser("apply-batch", help="Apply all plans in a directory")
    batch_parser.add_argument("--dir", required=True)
    batch_parser.add_argument("--pattern", default="*.plan.v1.json")
    batch_parser.add_argument("--continue-on-error", action="store_true")
    batch_parser.add_argument("--dry-run", action="store_true")
    batch_parser.add_argument("--export-once", action="store_true")

    health_parser = sub.add_parser("healthcheck", help="Run pipeline health checks")
    health_parser.add_argument("--packs", action="store_true")
    health_parser.add_argument("--no-packs", action="store_true")
    health_parser.add_argument("--strict-validate", action="store_true")
    health_parser.add_argument("--run-report-only", action="store_true")
    health_parser.add_argument("--plans", nargs="*")
    health_parser.add_argument("--export-once", action="store_true")
    health_parser.add_argument("--no-export-once", action="store_true")
    health_parser.add_argument("--fail-fast", action="store_true")
    health_parser.add_argument("--json", action="store_true")

    args = parser.parse_args()

    if args.command == "validate-plan":
        plan_path = normalize_path(args.plan)
        plan = load_plan(plan_path)
        print_validation(plan, plan_path)
        return

    if args.command == "scaffold-plan":
        out_path = normalize_path(args.out)
        domains = [d.strip() for d in args.domains.split(",") if d.strip()]
        scaffold_plan(args.country, domains, out_path, args.pack)
        return

    if args.command == "apply":
        plan_path = normalize_path(args.plan)
        try:
            apply_plan(plan_path, dry_run=args.dry_run)
        except Exception as exc:
            log_stdout(str(exc))
            sys.exit(1)
        return

    if args.command == "apply-batch":
        plans_dir = normalize_path(args.dir)
        ensure(plans_dir.exists(), f"Plans dir not found: {plans_dir}")
        try:
            runlog_path = apply_batch(
                plans_dir,
                args.pattern,
                args.continue_on_error,
                args.dry_run,
                args.export_once,
            )
        except Exception as exc:
            log_stdout(str(exc))
            sys.exit(1)
        log_stdout(f"BATCH_RUNLOG_WRITTEN: {runlog_path}")
        return

    if args.command == "healthcheck":
        packs = True if args.packs else not args.no_packs
        export_once = True if args.run_report_only else False
        if args.export_once:
            export_once = True
        if args.no_export_once:
            export_once = False
        exit_code = healthcheck(
            packs=packs,
            strict_validate=args.strict_validate,
            run_report_only=args.run_report_only,
            plans=args.plans,
            export_once=export_once,
            fail_fast=args.fail_fast,
            json_summary=args.json,
        )
        sys.exit(exit_code)


if __name__ == "__main__":
    main()

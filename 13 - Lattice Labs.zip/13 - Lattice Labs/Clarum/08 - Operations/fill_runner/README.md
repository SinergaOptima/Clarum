# AI Fill Runner v0

A deterministic, auditable runner that applies explicit plan-driven updates to country packs, enforces Tier B allowlist checks, runs strict validation, regenerates reports, and rebuilds site_export.

## Philosophy
- Plans are authored by humans or AI outside the runner.
- The runner applies only explicit updates from the plan.
- No hidden calls or silent data changes.

## Requirements
- Python 3.11+ (repo uses a local venv).
- ruamel.yaml for safe round-trip edits:
  - `pip install ruamel.yaml`

## Files
- `plan_schema.v1.json`: schema for plan validation.
- `default_report_jobs.v1.json`: the default six report jobs.
- `fill_runner.py`: CLI entrypoint.
- `pack_edit.py`: safe YAML edits (ruamel.yaml required).
- `allowlist_check.py`: Tier B allowlist pre-checks.
- `runlog.py`: runlog writer.

## Commands
## Quick Start
1) Scaffold a plan
```
python "08 - Operations/fill_runner/fill_runner.py" scaffold-plan \
  --country HUN \
  --domains A6,A8 \
  --pack "04 - Data & Ontology/Ontology/_machine/country_packs/hungary.v1.yaml" \
  --out "04 - Data & Ontology/Ontology/_machine/plans/hun_a6_a8.plan.v1.json"
```

2) Or copy the golden template plan:
- `08 - Operations/fill_runner/examples/plan.template.v1.json`

3) Apply (dry-run, then live)
```
python "08 - Operations/fill_runner/fill_runner.py" apply --plan "04 - Data & Ontology/Ontology/_machine/plans/hun_a6_a8.plan.v1.json" --dry-run
python "08 - Operations/fill_runner/fill_runner.py" apply --plan "04 - Data & Ontology/Ontology/_machine/plans/hun_a6_a8.plan.v1.json"
```

Validate a plan:
```
python "08 - Operations/fill_runner/fill_runner.py" validate-plan --plan path/to/plan.json
```

Scaffold a plan:
```
python "08 - Operations/fill_runner/fill_runner.py" scaffold-plan \
  --country HUN \
  --domains A6,A8 \
  --pack "04 - Data & Ontology/Ontology/_machine/country_packs/hungary.v1.yaml" \
  --out "04 - Data & Ontology/Ontology/_machine/plans/hun_a6_a8.plan.v1.json"
```

Apply a plan (dry-run):
```
python "08 - Operations/fill_runner/fill_runner.py" apply --plan path/to/plan.json --dry-run
```

Apply a plan (live run):
```
python "08 - Operations/fill_runner/fill_runner.py" apply --plan path/to/plan.json
```

Batch apply (all plans in a folder):
```
python "08 - Operations/fill_runner/fill_runner.py" apply-batch \
  --dir "04 - Data & Ontology/Ontology/_machine/plans" \
  --pattern "*.plan.v1.json" \
  --dry-run \
  --continue-on-error
```

## Tier B allowlist enforcement
If any update sets `evidence_tier: B`, the runner checks `TIERB_ALLOWLIST.v1.json`.
If tokens/domains do not match, the runner fails and prints a copy-paste allowlist skeleton.

## Enterprise Surveys adapter (v0.1)
Plan usage (alias):
```
"provenance": {
  "adapter": "enterprise_surveys",
  "query": "inadequately_educated_workforce_major_constraint_pct"
}
```

Plan usage (raw variable code):
```
"provenance": {
  "adapter": "enterprise_surveys",
  "query": "IC.FRM.WRKF.WK10"
}
```

## Runlogs
Runlogs are written to:
`04 - Data & Ontology/Ontology/_machine/runlogs/fill_runner_<ISO3>_<YYYY-MM-DD_HHMM>.txt`

Each runlog includes:
- plan metadata
- strict validation output
- applied updates
- exact command lines
- outputs produced

## Memo Generator v0
Generate memo.v1 JSON + markdown from report artifacts:
```
python "08 - Operations/fill_runner/memo_generator/generate_memo.py" \
  --report "04 - Data & Ontology/Ontology/_machine/reports/hungary.ev_oem_export.wp-ev-oem-export-1.1.balanced.report.v1.json"
```

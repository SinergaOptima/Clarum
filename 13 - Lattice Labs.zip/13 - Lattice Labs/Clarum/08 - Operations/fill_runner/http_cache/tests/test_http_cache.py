import json
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path

import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from http_cache.http_cache import (
    _build_cache_key,
    fetch_json,
    set_cache_root,
    set_transport_get,
)


class HttpCacheTests(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        set_cache_root(Path(self.temp_dir.name))
        self.calls = 0

    def tearDown(self):
        set_transport_get(None)
        self.temp_dir.cleanup()

    def test_cache_miss_then_hit(self):
        payload = {"ok": True}
        body = json.dumps(payload).encode("utf-8")

        def transport(url: str):
            self.calls += 1
            return 200, {"Content-Type": "application/json"}, body

        set_transport_get(transport)
        first = fetch_json("https://example.com/data")
        second = fetch_json("https://example.com/data")

        self.assertEqual(self.calls, 1)
        self.assertEqual(first["data"], payload)
        self.assertEqual(second["data"], payload)
        self.assertFalse(first["provenance"]["cache_hit"])
        self.assertTrue(second["provenance"]["cache_hit"])

    def test_expired_refetch(self):
        body_v1 = json.dumps({"v": 1}).encode("utf-8")
        body_v2 = json.dumps({"v": 2}).encode("utf-8")
        url = "https://example.com/expiring"

        def transport_first(url: str):
            self.calls += 1
            return 200, {"Content-Type": "application/json"}, body_v1

        set_transport_get(transport_first)
        fetch_json(url, ttl_days=1)

        key = _build_cache_key("GET", url)
        meta_path = Path(self.temp_dir.name) / key[:2] / f"{key}.json"
        meta = json.loads(meta_path.read_text(encoding="utf-8"))
        meta["expires_at"] = (
            datetime.now(timezone.utc) - timedelta(days=1)
        ).replace(microsecond=0).isoformat()
        meta_path.write_text(json.dumps(meta, indent=2), encoding="utf-8")

        def transport_second(url: str):
            self.calls += 1
            return 200, {"Content-Type": "application/json"}, body_v2

        set_transport_get(transport_second)
        refreshed = fetch_json(url, ttl_days=1)

        self.assertEqual(refreshed["data"], {"v": 2})
        self.assertFalse(refreshed["provenance"]["cache_hit"])

    def test_stale_if_error(self):
        body = json.dumps({"v": "stale"}).encode("utf-8")
        url = "https://example.com/stale"

        def transport_ok(url: str):
            self.calls += 1
            return 200, {"Content-Type": "application/json"}, body

        set_transport_get(transport_ok)
        fetch_json(url, ttl_days=1)

        key = _build_cache_key("GET", url)
        meta_path = Path(self.temp_dir.name) / key[:2] / f"{key}.json"
        meta = json.loads(meta_path.read_text(encoding="utf-8"))
        meta["expires_at"] = (
            datetime.now(timezone.utc) - timedelta(days=1)
        ).replace(microsecond=0).isoformat()
        meta_path.write_text(json.dumps(meta, indent=2), encoding="utf-8")

        def transport_fail(url: str):
            raise RuntimeError("network down")

        set_transport_get(transport_fail)
        stale = fetch_json(url, ttl_days=1, stale_if_error=True)
        self.assertEqual(stale["data"], {"v": "stale"})
        self.assertTrue(stale["provenance"]["stale_used"])

    def test_deterministic_key(self):
        url_a = "https://example.com/path?b=2&a=1"
        url_b = "https://example.com/path?a=1&b=2"
        self.assertEqual(_build_cache_key("GET", url_a), _build_cache_key("GET", url_b))


if __name__ == "__main__":
    unittest.main()

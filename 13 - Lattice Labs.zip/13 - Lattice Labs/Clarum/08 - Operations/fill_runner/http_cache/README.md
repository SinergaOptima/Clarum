# HTTP Cache

Disk-backed HTTP cache for adapters (GET-only).

## Location
- Cache root: `08 - Operations/fill_runner/.cache/http/`
- Layout:
  - `<root>/<key_prefix>/<key>.json` (metadata)
  - `<root>/<key_prefix>/<key>.bin` (raw body)

## TTL rules
- Default TTL: 30 days
- `ttl_days=0` means "cache forever" (no expires)
- Expired entries refetch; if the fetch fails and `stale_if_error=True`, the cache serves stale data and records `stale_used_at` in metadata.

## Public API
- `fetch_json(url, ttl_days=30, stale_if_error=True)`
- `fetch_bytes(url, ttl_days=30, stale_if_error=True)`

Both return `{ data, provenance }` with provenance:
- `url`, `status`, `fetched_at`, `cache_hit`, `stale_used`, `sha256`, `expires_at`

## Clearing the cache
Delete the cache directory:
- `08 - Operations/fill_runner/.cache/http/`

from __future__ import annotations

import hashlib
import json
import urllib.parse
import urllib.request
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Callable


_CACHE_ROOT = Path(__file__).resolve().parents[1] / ".cache" / "http"
_TRANSPORT_GET: Callable[[str], tuple[int, dict[str, str], bytes]] | None = None


class HttpCacheError(RuntimeError):
    def __init__(self, status: int, url: str):
        super().__init__(f"HTTP {status} for {url}")
        self.status = status
        self.url = url


def set_cache_root(path: Path) -> None:
    global _CACHE_ROOT
    _CACHE_ROOT = path


def set_transport_get(
    func: Callable[[str], tuple[int, dict[str, str], bytes]] | None,
) -> None:
    global _TRANSPORT_GET
    _TRANSPORT_GET = func


def _now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def _normalize_url(url: str) -> str:
    parts = urllib.parse.urlsplit(url)
    query_pairs = urllib.parse.parse_qsl(parts.query, keep_blank_values=True)
    query_pairs.sort()
    normalized_query = urllib.parse.urlencode(query_pairs)
    return urllib.parse.urlunsplit(
        (parts.scheme, parts.netloc, parts.path, normalized_query, parts.fragment)
    )


def _header_fingerprint(headers: dict[str, str] | None) -> str:
    if not headers:
        return ""
    items = sorted((key.lower(), value.strip()) for key, value in headers.items())
    return "\n".join(f"{key}:{value}" for key, value in items)


def _build_cache_key(
    method: str, url: str, headers: dict[str, str] | None = None
) -> str:
    normalized_url = _normalize_url(url)
    header_fp = _header_fingerprint(headers)
    fingerprint = "\n".join([method.upper(), normalized_url, header_fp])
    return hashlib.sha256(fingerprint.encode("utf-8")).hexdigest()


def _cache_paths(key: str) -> tuple[Path, Path]:
    prefix = key[:2]
    base_dir = _CACHE_ROOT / prefix
    return base_dir / f"{key}.json", base_dir / f"{key}.bin"


def _ensure_parent(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)


def _load_meta(path: Path) -> dict[str, Any] | None:
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return None


def _parse_iso(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        return datetime.fromisoformat(value)
    except ValueError:
        return None


def _is_fresh(meta: dict[str, Any]) -> bool:
    expires_at = _parse_iso(meta.get("expires_at"))
    if expires_at is None:
        return True
    return datetime.now(timezone.utc) <= expires_at


def _default_transport_get(url: str) -> tuple[int, dict[str, str], bytes]:
    import urllib.error

    request = urllib.request.Request(url, method="GET")
    try:
        with urllib.request.urlopen(request, timeout=20) as response:
            status = getattr(response, "status", None) or response.getcode()
            headers = dict(response.headers.items())
            body = response.read()
        return status, headers, body
    except urllib.error.HTTPError as exc:
        return (
            exc.code,
            dict(exc.headers.items()) if exc.headers else {},
            exc.read() if exc.fp else b"",
        )


def _transport_get(url: str) -> tuple[int, dict[str, str], bytes]:
    if _TRANSPORT_GET is not None:
        return _TRANSPORT_GET(url)
    return _default_transport_get(url)


def _select_response_headers(headers: dict[str, str]) -> dict[str, str]:
    selected = {}
    for key in ("content-type", "content-length", "last-modified", "etag"):
        for header_key, header_value in headers.items():
            if header_key.lower() == key:
                selected[header_key] = header_value
    return selected


def _write_cache(
    key: str,
    url: str,
    status: int,
    headers: dict[str, str],
    body: bytes,
    ttl_days: int,
) -> dict[str, Any]:
    fetched_at = _now_iso()
    if ttl_days == 0:
        expires_at = None
    else:
        expires_at = (
            (datetime.now(timezone.utc) + timedelta(days=ttl_days))
            .replace(microsecond=0)
            .isoformat()
        )
    sha256 = hashlib.sha256(body).hexdigest()

    meta = {
        "cache_key": key,
        "url": url,
        "method": "GET",
        "status": status,
        "headers": _select_response_headers(headers),
        "fetched_at": fetched_at,
        "expires_at": expires_at,
        "sha256": sha256,
        "body_length": len(body),
        "ttl_days": ttl_days,
    }
    meta_path, body_path = _cache_paths(key)
    _ensure_parent(meta_path)
    meta_path.write_text(
        json.dumps(meta, indent=2, ensure_ascii=True) + "\n", encoding="utf-8"
    )
    body_path.write_bytes(body)
    return meta


def _read_cached(
    meta_path: Path, body_path: Path
) -> tuple[dict[str, Any], bytes] | None:
    meta = _load_meta(meta_path)
    if meta is None or not body_path.exists():
        return None
    try:
        body = body_path.read_bytes()
    except OSError:
        return None
    return meta, body


def _build_provenance(
    url: str,
    meta: dict[str, Any],
    cache_hit: bool,
    stale_used: bool,
) -> dict[str, Any]:
    return {
        "url": url,
        "status": meta.get("status"),
        "fetched_at": meta.get("fetched_at"),
        "cache_hit": cache_hit,
        "stale_used": stale_used,
        "sha256": meta.get("sha256"),
        "expires_at": meta.get("expires_at"),
    }


def fetch_bytes(
    url: str,
    *,
    ttl_days: int = 30,
    stale_if_error: bool = True,
) -> dict[str, Any]:
    key = _build_cache_key("GET", url)
    meta_path, body_path = _cache_paths(key)
    cached = _read_cached(meta_path, body_path)

    if cached:
        meta, body = cached
        if _is_fresh(meta):
            provenance = _build_provenance(url, meta, cache_hit=True, stale_used=False)
            return {"data": body, "provenance": provenance}

    try:
        status, headers, body = _transport_get(url)
        if status != 200:
            raise HttpCacheError(status, url)
        meta = _write_cache(key, url, status, headers, body, ttl_days)
        provenance = _build_provenance(url, meta, cache_hit=False, stale_used=False)
        return {"data": body, "provenance": provenance}
    except Exception as exc:
        if cached and stale_if_error:
            meta, body = cached
            meta["stale_used_at"] = _now_iso()
            meta["last_error"] = str(exc)
            meta_path.write_text(
                json.dumps(meta, indent=2, ensure_ascii=True) + "\n", encoding="utf-8"
            )
            provenance = _build_provenance(url, meta, cache_hit=True, stale_used=True)
            return {"data": body, "provenance": provenance}
        raise


def fetch_json(
    url: str,
    *,
    ttl_days: int = 30,
    stale_if_error: bool = True,
) -> dict[str, Any]:
    result = fetch_bytes(url, ttl_days=ttl_days, stale_if_error=stale_if_error)
    body = result["data"]
    try:
        payload = json.loads(body.decode("utf-8"))
    except json.JSONDecodeError as exc:
        raise RuntimeError(f"Failed to parse JSON from {url}: {exc}") from exc
    return {"data": payload, "provenance": result["provenance"]}

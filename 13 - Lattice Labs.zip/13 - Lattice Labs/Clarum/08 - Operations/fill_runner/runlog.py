from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

from utils import now_stamp, try_git_hash, url_domains_summary


@dataclass
class UpdateRow:
    indicator_id: str
    evidence_tier: str
    value: str
    url: str
    retrieved_date: str
    notes: str
    transform: str | None


@dataclass
class AdapterFillRow:
    indicator_id: str
    country_iso3: str
    country_pack: str
    adapter_name: str
    action: str
    old_value: str
    new_value: str
    evidence_tier: str
    source_url: str
    sha256: str
    cache_hit: bool
    stale_used: bool
    method_note: str
    skip_reason: str | None = None
    snapshot_attempted: bool = False
    snapshot_used: bool = False


@dataclass
class RunlogPayload:
    plan_path: Path
    country_iso3: str
    working_dir: Path
    strict_status: str
    strict_output: str
    report_only: bool
    scope_expansion_note: str | None
    commands: list[str]
    report_files: list[str]
    memo_json_files: list[str]
    memo_md_files: list[str]
    memo_json_unique_count: int
    memo_md_unique_count: int
    memo_collisions: list[dict]
    site_export_summary: str | None
    updates: list[UpdateRow]
    adapter_fills: list[AdapterFillRow]


def runlog_path(machine_dir: Path, country_iso3: str) -> Path:
    return machine_dir / "runlogs" / f"fill_runner_{country_iso3}_{now_stamp()}.txt"


def format_update_rows(rows: Iterable[UpdateRow]) -> list[str]:
    lines = []
    for row in rows:
        domain = url_domains_summary(row.url)
        notes = (row.notes or "").splitlines()[0] if row.notes else ""
        transform = row.transform or ""
        lines.append(
            f"- {row.indicator_id} | tier={row.evidence_tier} | value={row.value} | domain={domain} | "
            f"retrieved={row.retrieved_date} | notes={notes} | transform={transform}"
        )
    return lines


def write_runlog(payload: RunlogPayload, machine_dir: Path) -> Path:
    log_path = runlog_path(machine_dir, payload.country_iso3)
    git_hash = try_git_hash(payload.working_dir) or "unavailable"

    lines = []
    lines.append("AI Fill Runner v0 Runlog")
    lines.append(f"Plan: {payload.plan_path}")
    lines.append(f"Timestamp: {now_stamp()}")
    lines.append(f"Working directory: {payload.working_dir}")
    lines.append(f"Git hash: {git_hash}")
    lines.append(f"Report-only mode: {str(payload.report_only).lower()}")
    if payload.scope_expansion_note:
        lines.append(payload.scope_expansion_note)
    lines.append("")
    lines.append("Strict validation")
    lines.append(f"- Status: {payload.strict_status}")
    if payload.strict_output:
        lines.append("- Output:")
        for line in payload.strict_output.splitlines():
            lines.append(f"  {line}")
    lines.append("")
    lines.append("Applied updates")
    lines.extend(format_update_rows(payload.updates))
    if payload.adapter_fills:
        lines.append("")
        lines.append("Adapter fills")
        for row in payload.adapter_fills:
            lines.append(
                "- "
                f"{row.indicator_id} | iso={row.country_iso3} | pack={row.country_pack} | "
                f"adapter={row.adapter_name} | action={row.action} | old={row.old_value} | "
                f"new={row.new_value} | tier={row.evidence_tier} | url={row.source_url} | "
                f"sha256={row.sha256} | cache_hit={str(row.cache_hit).lower()} | "
                f"stale_used={str(row.stale_used).lower()} | "
                f"snapshot_attempted={str(row.snapshot_attempted).lower()} | "
                f"snapshot_used={str(row.snapshot_used).lower()} | "
                f"skip_reason={row.skip_reason or 'none'} | note={row.method_note}"
            )
    lines.append("")
    lines.append("Commands executed")
    for cmd in payload.commands:
        lines.append(f"- {cmd}")
    lines.append("")
    lines.append("Outputs produced")
    if payload.report_files:
        lines.append("- Reports:")
        for report in payload.report_files:
            lines.append(f"  - {report}")
    if payload.memo_json_files:
        lines.append("- Memos (JSON):")
        for memo in payload.memo_json_files:
            lines.append(f"  - {memo}")
    if payload.memo_md_files:
        lines.append("- Memos (MD):")
        for memo in payload.memo_md_files:
            lines.append(f"  - {memo}")
    lines.append(
        f"- Memo outputs (unique): JSON={payload.memo_json_unique_count}, MD={payload.memo_md_unique_count}"
    )
    if payload.memo_collisions:
        lines.append("- Memo collisions (first 10):")
        for collision in payload.memo_collisions[:10]:
            lines.append(
                "  - "
                f"[{collision.get('kind')}] {collision.get('memo_path')} <- "
                f"{collision.get('first_report')} & {collision.get('second_report')}"
            )
    else:
        lines.append("- Memo collisions: none")
    if payload.site_export_summary:
        lines.append(f"- Site export: {payload.site_export_summary}")

    log_path.parent.mkdir(parents=True, exist_ok=True)
    log_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return log_path

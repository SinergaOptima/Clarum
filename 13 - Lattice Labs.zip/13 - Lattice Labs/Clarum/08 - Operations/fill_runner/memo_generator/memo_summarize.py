from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable


@dataclass
class MemoSummary:
    executive_summary: str
    key_findings: list[dict]
    risk_register: list[dict]
    open_questions: list[str]
    data_quality: dict


def _compute_confidence(completeness_pct: float, tier_b_present: bool, overall_cap: str | None) -> float:
    base = min(1.0, completeness_pct / 100.0)
    cap = 1.0
    if tier_b_present:
        cap = min(cap, 0.6)
    if overall_cap and overall_cap != "high":
        cap = min(cap, 0.5)
    return round(min(base, cap), 2)


def _domain_rankings(by_domain: dict) -> tuple[list[str], list[str]]:
    items = [(k, v) for k, v in by_domain.items() if isinstance(v, (int, float))]
    if not items:
        return [], []
    items.sort(key=lambda kv: (-kv[1], kv[0]))
    top = [k for k, _ in items[:2]]
    bottom = [k for k, _ in sorted(items, key=lambda kv: (kv[1], kv[0]))[:2]]
    return top, bottom


def _extract_domains(report: dict) -> dict:
    return report.get("completeness", {}).get("by_domain", {}) or {}


def _extract_case(report: dict) -> dict:
    meta = report.get("meta", {})
    case = meta.get("case", {})
    methodology = meta.get("methodology", {})
    return {
        "country": case.get("country"),
        "sector": case.get("sector"),
        "role": case.get("role"),
        "track": case.get("mode"),
        "weight_profile": methodology.get("weight_profile_id"),
        "overlay": methodology.get("overlay_id"),
    }


def _indicator_ids_for_domain(report: dict, domain: str) -> list[str]:
    return [
        ind_id
        for ind_id in (report.get("indicators") or {}).keys()
        if ind_id.startswith(f"IND-{domain}-")
    ]


def _first_refs(indicator_ids: Iterable[str], indicator_refs: dict) -> list[str]:
    refs = []
    for ind_id in indicator_ids:
        for ref in indicator_refs.get(ind_id, []):
            if ref not in refs:
                refs.append(ref)
        if refs:
            break
    return refs


def build_summary(
    report: dict,
    indicator_refs: dict,
    audit_notes: list[str],
    question: str | None,
    audience: str | None,
    purpose: str | None,
) -> MemoSummary:
    completeness = report.get("completeness", {})
    overall_pct = float(completeness.get("overall_pct") or 0)
    by_domain = _extract_domains(report)
    top_domains, bottom_domains = _domain_rankings(by_domain)
    case = _extract_case(report)

    tier_summary = report.get("meta", {}).get("evidence_tier_summary", {})
    tier_b_present = (tier_summary.get("B") or 0) > 0
    overall_cap = report.get("confidence", {}).get("overall_cap")

    confidence = _compute_confidence(overall_pct, tier_b_present, overall_cap)

    context = []
    if question:
        context.append(f"Question focus: {question}.")
    if audience:
        context.append(f"Audience: {audience}.")
    if purpose:
        context.append(f"Purpose: {purpose}.")
    context_line = " ".join(context)

    strengths = ", ".join(top_domains) if top_domains else "key domains"
    weaknesses = ", ".join(bottom_domains) if bottom_domains else "open domains"

    exec_lines = [
        f"This memo summarizes the {case.get('country')} {case.get('sector')} {case.get('role')} {case.get('track')} report using deterministic rules and cited sources.",
        f"Data quality is anchored by completeness at {overall_pct:.0f}% with an overall confidence cap of {overall_cap or 'unknown'}.",
        f"Strengths cluster in {strengths}, while {weaknesses} warrant closer scrutiny based on available signals.",
        "Key takeaways include one structural opportunity, one major risk, and one watch item tied to proxy reliance or missingness.",
    ]
    if context_line:
        exec_lines.append(context_line)
    exec_lines.append(
        "Overall, the evidence base is sufficient for directional insights but should be refreshed as Tier B proxies are replaced with primary sources."
    )

    executive_summary = " ".join(exec_lines)

    key_findings = []
    finding_id = 1
    for domain in top_domains:
        refs = _first_refs(_indicator_ids_for_domain(report, domain), indicator_refs)
        key_findings.append(
            {
                "finding_id": f"F-{finding_id:03d}",
                "claim": f"{domain} indicators show consistent coverage with no major gaps in current artifacts.",
                "risk_direction": "down",
                "confidence": confidence,
                "evidence_refs": refs,
            }
        )
        finding_id += 1

    for domain in bottom_domains:
        refs = _first_refs(_indicator_ids_for_domain(report, domain), indicator_refs)
        key_findings.append(
            {
                "finding_id": f"F-{finding_id:03d}",
                "claim": f"{domain} signals rely on proxies and should be treated as higher-uncertainty risk indicators.",
                "risk_direction": "up",
                "confidence": confidence,
                "evidence_refs": refs,
            }
        )
        finding_id += 1

    if tier_b_present:
        key_findings.append(
            {
                "finding_id": f"F-{finding_id:03d}",
                "claim": "Tier B sources are present; confidence should be capped until primary sources are substituted.",
                "risk_direction": "mixed",
                "confidence": confidence,
                "evidence_refs": [],
            }
        )
        finding_id += 1

    while len(key_findings) < 5:
        key_findings.append(
            {
                "finding_id": f"F-{finding_id:03d}",
                "claim": "Cross-domain signals indicate stable baseline conditions with monitoring required for policy shifts.",
                "risk_direction": "mixed",
                "confidence": confidence,
                "evidence_refs": [],
            }
        )
        finding_id += 1

    risk_register = []
    for domain in [f"A{i}" for i in range(1, 9)]:
        refs = _first_refs(_indicator_ids_for_domain(report, domain), indicator_refs)
        severity = 50
        if domain in by_domain:
            severity = round(100.0 - float(by_domain[domain]), 2)
        risk_register.append(
            {
                "risk_id": f"R-{domain}",
                "description": f"Domain {domain} exposure derived from report completeness and proxy reliance.",
                "domain": domain,
                "severity": severity,
                "confidence": confidence,
                "evidence_refs": refs,
            }
        )

    open_questions = []
    if tier_b_present:
        open_questions.append("Which Tier B proxies can be replaced with primary datasets next cycle?")
    if overall_cap and overall_cap != "high":
        open_questions.append("Which domains drive the overall confidence cap and can be strengthened?")
    if report.get("fatal_missingness", {}).get("triggered"):
        open_questions.append("What actions are needed to resolve fatal missingness indicators?")

    while len(open_questions) < 3:
        open_questions.append("Are there upcoming policy or market shifts not captured in the current evidence set?")

    data_quality = {
        "completeness_pct": overall_pct,
        "tier_b_present": tier_b_present,
        "confidence_caps": [overall_cap] if overall_cap else [],
    }

    if audit_notes:
        data_quality["confidence_caps"].extend(audit_notes)

    return MemoSummary(
        executive_summary=executive_summary,
        key_findings=key_findings[:8],
        risk_register=risk_register[:12],
        open_questions=open_questions[:6],
        data_quality=data_quality,
    )

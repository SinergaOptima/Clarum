from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable


@dataclass
class UrlRecord:
    indicator_id: str
    url: str
    retrieved_date: str | None
    tier: str | None


@dataclass
class Citation:
    cite_id: str
    title: str
    url: str
    retrieved_date: str | None
    tier: str


def _split_urls(url_value: str) -> list[str]:
    if not url_value or not isinstance(url_value, str):
        return []
    return [segment.strip() for segment in url_value.split("|") if segment.strip()]


def _hash_url(url: str) -> str:
    return hashlib.sha1(url.encode("utf-8")).hexdigest()[:10]


def _evidence_index_paths(project_root: Path) -> list[Path]:
    return [
        project_root
        / "09 - Publishing"
        / "site_export"
        / "v1"
        / "evidence"
        / "evidence_index.v1.json",
    ]


def _load_evidence_index(project_root: Path) -> dict:
    for path in _evidence_index_paths(project_root):
        if path.exists():
            payload = json.loads(path.read_text(encoding="utf-8"))
            index = {}
            for entry in payload:
                for url in entry.get("urls", []) or []:
                    index[url] = entry
            return index
    return {}


def extract_url_records(report: dict) -> list[UrlRecord]:
    records = []
    for ind_id, entry in (report.get("indicators") or {}).items():
        urls = _split_urls(entry.get("url", ""))
        for url in urls:
            records.append(
                UrlRecord(
                    indicator_id=ind_id,
                    url=url,
                    retrieved_date=entry.get("retrieved_date"),
                    tier=entry.get("evidence_tier"),
                )
            )
    return records


def build_citations(project_root: Path, records: Iterable[UrlRecord]) -> tuple[list[Citation], dict[str, list[str]], list[str]]:
    evidence_index = _load_evidence_index(project_root)
    citations = {}
    indicator_refs: dict[str, list[str]] = {}
    audit_notes = []

    for record in records:
        cite_id = f"C-{_hash_url(record.url)}"
        entry = evidence_index.get(record.url)
        title = entry.get("title") if entry else None
        tier = entry.get("tier") if entry else None
        if not title:
            title = record.indicator_id or "Source"
        if not tier:
            tier = record.tier or "B"
            if record.tier is None:
                audit_notes.append(
                    f"Citation tier unknown for {record.url}; defaulted to B."
                )
        citations.setdefault(
            record.url,
            Citation(
                cite_id=cite_id,
                title=title,
                url=record.url,
                retrieved_date=record.retrieved_date,
                tier=tier,
            ),
        )
        indicator_refs.setdefault(record.indicator_id, [])
        if cite_id not in indicator_refs[record.indicator_id]:
            indicator_refs[record.indicator_id].append(cite_id)

    return list(citations.values()), indicator_refs, audit_notes

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from memo_render import render_markdown
from memo_sources import build_citations, extract_url_records
from memo_summarize import build_summary
from memo_validate import validate_memo


def _project_root_from_here() -> Path:
    return Path(__file__).resolve().parents[3]


def _normalize_timestamp(value: str | None) -> str | None:
    if not value:
        return None
    value = value.strip()
    if "T" in value:
        return value
    if " " in value:
        return value.replace(" ", "T")
    return value


def _extract_iso3(case_id: str | None, country: str | None, audit_notes: list[str]) -> str:
    if case_id:
        for part in case_id.split("-"):
            if len(part) == 3 and part.isalpha():
                return part.upper()
    if country and len(country) == 3 and country.isalpha():
        return country.upper()
    audit_notes.append("country_iso3 missing; defaulted to UNK.")
    return "UNK"


def _relative_path(path: Path, project_root: Path) -> str:
    try:
        return path.resolve().relative_to(project_root.resolve()).as_posix()
    except Exception:
        return path.as_posix()


def _string_or_unknown(value: str | None) -> str:
    if isinstance(value, str) and value.strip():
        return value
    return "unknown"


def _default_out_paths(report_path: Path, project_root: Path) -> tuple[Path, Path]:
    name = report_path.name
    suffix = ".report.v1.json"
    if name.endswith(suffix):
        base = name[: -len(suffix)]
    else:
        base = report_path.stem
    memo_base = f"{base}.memo.v1"
    out_json = (
        project_root
        / "04 - Data & Ontology"
        / "Ontology"
        / "_machine"
        / "memos"
        / f"{memo_base}.json"
    )
    out_md = (
        project_root
        / "04 - Data & Ontology"
        / "Ontology"
        / "_machine"
        / "memos"
        / "rendered"
        / f"{memo_base}.md"
    )
    return out_json, out_md


def build_memo(
    report: dict,
    report_path: Path,
    project_root: Path,
    question: str | None = None,
    audience: str | None = None,
    purpose: str | None = None,
) -> dict:
    audit_notes: list[str] = []

    records = extract_url_records(report)
    citations, indicator_refs, citation_notes = build_citations(project_root, records)
    audit_notes.extend(citation_notes)

    meta = report.get("meta", {})
    case_meta = meta.get("case", {})
    methodology = meta.get("methodology", {})
    case_id = case_meta.get("case_id")

    iso3 = _extract_iso3(case_id, case_meta.get("country"), audit_notes)

    generated_at = _normalize_timestamp(meta.get("generated_at"))
    if not generated_at:
        generated_at = "1970-01-01T00:00:00"
        audit_notes.append("generated_at missing; defaulted to epoch.")

    track_value = case_meta.get("mode")
    track = track_value.lower() if isinstance(track_value, str) else "unknown"

    summary = build_summary(
        report,
        indicator_refs,
        audit_notes,
        question=question,
        audience=audience,
        purpose=purpose,
    )

    citation_list = sorted(citations, key=lambda c: c.cite_id)

    memo = {
        "memo_version": "memo.v1",
        "created_at": generated_at,
        "case": {
            "country_iso3": iso3,
            "track": track,
            "sector": _string_or_unknown(case_meta.get("sector")),
            "role": _string_or_unknown(case_meta.get("role")),
            "weight_profile": _string_or_unknown(methodology.get("weight_profile_id")),
            "overlay": _string_or_unknown(methodology.get("overlay_id")),
            "report_artifact_path": _relative_path(report_path, project_root),
        },
        "executive_summary": summary.executive_summary,
        "key_findings": summary.key_findings,
        "risk_register": summary.risk_register,
        "open_questions": summary.open_questions,
        "data_quality": summary.data_quality,
        "citations": [
            {
                "cite_id": cite.cite_id,
                "title": cite.title,
                "url": cite.url,
                "retrieved_date": cite.retrieved_date,
                "tier": cite.tier,
            }
            for cite in citation_list
        ],
        "audit_trail": {
            "inputs": [_relative_path(report_path, project_root)],
            "generated_by": "memo_generator.v0",
            "notes": "; ".join(audit_notes),
        },
    }

    return memo


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Generate memo.v1 JSON and markdown.")
    parser.add_argument("--report", required=True, help="Path to report.v1.json artifact.")
    parser.add_argument(
        "--project-root",
        help="Project root (defaults to Clarum workspace root).",
    )
    parser.add_argument("--out-json", help="Output memo JSON path.")
    parser.add_argument("--out-md", help="Output memo markdown path.")
    parser.add_argument("--question", help="Optional question focus.")
    parser.add_argument("--audience", help="Optional audience.")
    parser.add_argument("--purpose", help="Optional purpose.")
    parser.add_argument("--skip-render", action="store_true", help="Skip markdown output.")
    return parser.parse_args()


def main() -> int:
    args = _parse_args()
    report_path = Path(args.report)
    if not report_path.exists():
        print(f"Report not found: {report_path}", file=sys.stderr)
        return 1

    project_root = Path(args.project_root) if args.project_root else _project_root_from_here()

    report = json.loads(report_path.read_text(encoding="utf-8"))
    memo = build_memo(
        report,
        report_path=report_path,
        project_root=project_root,
        question=args.question,
        audience=args.audience,
        purpose=args.purpose,
    )

    errors = validate_memo(memo)
    if errors:
        print("Memo schema validation failed:", file=sys.stderr)
        for err in errors:
            print(f"- {err}", file=sys.stderr)
        return 1

    out_json = Path(args.out_json) if args.out_json else _default_out_paths(report_path, project_root)[0]
    out_json.parent.mkdir(parents=True, exist_ok=True)
    out_json.write_text(json.dumps(memo, indent=2) + "\n", encoding="utf-8")

    if not args.skip_render:
        out_md = Path(args.out_md) if args.out_md else _default_out_paths(report_path, project_root)[1]
        render_markdown(memo, out_md)

    print(f"Wrote memo JSON: {out_json}")
    if not args.skip_render:
        print(f"Wrote memo markdown: {out_md}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())

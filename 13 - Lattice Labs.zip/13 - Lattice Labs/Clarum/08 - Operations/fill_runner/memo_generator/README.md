# Memo Generator v0

A deterministic, rules-based memo generator that consumes report artifacts and evidence URLs to produce memo.v1 JSON and an optional markdown render.

## Requirements
- Python 3.11+
- `jsonschema` (for memo schema validation):
  - `pip install jsonschema`

## Inputs
- Report artifact: `04 - Data & Ontology/Ontology/_machine/reports/*.report.v1.json`
- Evidence index: `09 - Publishing/site_export/v1/evidence/evidence_index.v1.json`

## Outputs
- Memo JSON: `04 - Data & Ontology/Ontology/_machine/memos/*.memo.v1.json`
- Memo markdown: `04 - Data & Ontology/Ontology/_machine/memos/rendered/*.memo.v1.md`

## Command
```
python "08 - Operations/fill_runner/memo_generator/generate_memo.py" \
  --report "04 - Data & Ontology/Ontology/_machine/reports/hungary.ev_oem_export.wp-ev-oem-export-1.1.balanced.report.v1.json"
```

Optional context inputs:
```
python "08 - Operations/fill_runner/memo_generator/generate_memo.py" \
  --report "04 - Data & Ontology/Ontology/_machine/reports/hungary.ev_oem_export.wp-ev-oem-export-1.1.balanced.report.v1.json" \
  --question "What are the top policy risks?" \
  --audience "Investment committee" \
  --purpose "Preliminary diligence"
```

## Notes
- The generator does not modify country packs.
- If the evidence index is missing, citations will fall back to indicator IDs and default Tier B.

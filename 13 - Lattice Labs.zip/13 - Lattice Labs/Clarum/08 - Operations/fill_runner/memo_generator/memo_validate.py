from __future__ import annotations

import json
from pathlib import Path


def _schema_path() -> Path:
    return Path(__file__).resolve().parents[1] / "memo_spec.v1.json"


def validate_memo(memo: dict, schema_path: Path | None = None) -> list[str]:
    try:
        from jsonschema import Draft202012Validator
    except Exception as exc:  # pragma: no cover - deterministic failure
        raise RuntimeError(
            "jsonschema is required for memo validation. Install with: pip install jsonschema"
        ) from exc

    schema_path = schema_path or _schema_path()
    schema = json.loads(schema_path.read_text(encoding="utf-8"))
    validator = Draft202012Validator(schema)
    errors = sorted(validator.iter_errors(memo), key=lambda e: e.path)
    return [f"{list(err.path)}: {err.message}" for err in errors]

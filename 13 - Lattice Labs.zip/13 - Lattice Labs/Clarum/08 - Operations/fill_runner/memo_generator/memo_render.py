from __future__ import annotations

from pathlib import Path


def render_markdown(memo: dict, out_path: Path):
    case = memo.get("case", {})
    title = f"Memo: {case.get('country_iso3')} {case.get('sector')} {case.get('role')} {case.get('track')}"
    lines = [f"# {title}", "", "## Executive Summary", memo.get("executive_summary", ""), ""]

    lines.append("## Key Findings")
    for finding in memo.get("key_findings", []):
        refs = ", ".join(finding.get("evidence_refs", [])) or "none"
        lines.append(
            f"- {finding.get('claim')} (confidence {finding.get('confidence')}, refs: {refs})"
        )
    lines.append("")

    lines.append("## Risk Register")
    for risk in memo.get("risk_register", []):
        refs = ", ".join(risk.get("evidence_refs", [])) or "none"
        lines.append(
            f"- {risk.get('risk_id')} | {risk.get('domain')} | severity {risk.get('severity')} | confidence {risk.get('confidence')} | refs: {refs}"
        )
    lines.append("")

    dq = memo.get("data_quality", {})
    lines.append("## Data Quality")
    lines.append(
        f"- completeness_pct: {dq.get('completeness_pct')} | tier_b_present: {dq.get('tier_b_present')} | confidence_caps: {dq.get('confidence_caps')}"
    )
    lines.append("")

    lines.append("## Citations")
    for cite in memo.get("citations", []):
        lines.append(f"- {cite.get('cite_id')}: {cite.get('url')}")

    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text("\n".join(lines) + "\n", encoding="utf-8")

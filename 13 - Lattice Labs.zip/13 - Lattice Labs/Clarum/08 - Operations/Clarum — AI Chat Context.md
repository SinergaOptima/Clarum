# Clarum — AI Chat Context

Last Updated: 2026-02-10 19:48

1) Purpose & Non-Negotiables
- Clarum provides AI-powered market-entry risk analysis for tech, EV, and semis; decision support, not prediction.
- Evidence tiering is strict (Tier A/B/C). No hallucinated URLs; every link must be verified.
- Lens layer is separated from evidence layer (interpretation never overwrites sources).
- Outputs are deterministic and auditable (same inputs yield same outputs).

2) Vault Canonical Structure (current)
- 00 - Dashboard & Index: navigation, dashboards, decision logs.
- 01 - Framework: LRF-1 core docs, indicator library, rubric anchors, weight profiles.
- 02 - Evidence Library: evidence index, tiering/gating, source register.
- 03 - Product: PRD, output spec, report schema.
- 04 - Data & Ontology: country packs, machine layer artifacts, ontology notes.
- 05 - Engineering: pipelines, future scoring engine, infra notes.
- 06 - Validation & Evals: dossiers, validation plan, eval rubrics.
- 07 - Go-to-Market: GTM notes, pricing, positioning.
- 08 - Operations: scripts, runlogs, process docs.
- 09 - Legal & Brand: brand system, legal notes.
- 99 - Archive: deprecated or historical materials.
- Duplicate non-numbered roots were removed; canonical numbered structure is enforced.

3) Methodology Stack (current, versioned)
- LRF-1 Indicator Library v1
- LRF-1 Weight Profiles v1.1
- LRF-1 Rubric Anchors & Thresholds v1
- Indicator Ops Registry v1
- Country Pack Template v1
- Machine layer artifacts (catalog/schema/template/packs)
- Deterministic report generator v1
- Validator strict-by-default (use --relaxed to bypass guardrails)

4) Machine Layer — What exists and where
- 04 - Data & Ontology/Ontology/_machine/indicator_catalog.v1.json: catalog of indicators, canonical sources, and metadata.
- 04 - Data & Ontology/Ontology/_machine/country_pack.schema.v1.json: schema for country pack validation.
- 04 - Data & Ontology/Ontology/_machine/country_pack_template.v1.yaml: starter template for packs.
- 04 - Data & Ontology/Ontology/_machine/country_packs/*.v1.yaml: Hungary, Mexico, Malaysia pack data.
- 04 - Data & Ontology/Ontology/_machine/reports/*.report.v1.json: generated report artifacts per case.
- 04 - Data & Ontology/Ontology/_machine/runlogs/*: run logs for validation, generator, and patch actions.

5) Scripts — What exists and how to run
- lrf_machine_export.py: exports LRF-1 assets to the machine layer (catalog/schema/template/packs).
- validate_country_pack.py: validates packs against schema plus strict guardrails; add --relaxed to skip guardrails.
- generate_report_artifact.py: generates deterministic report artifacts and runlogs.
- wb_helper.py: caches World Bank indicator list and exposes search/series helpers for Tier-A pulls.

Website export plumbing (see handoff for full details)
- site_export builder: 09 - Publishing/site_export/ outputs v1 bundle with unified index.
- Website reads public/data/site_export.v1/* via src/data/loaders.ts with demo fallback.
- Sync pipeline: scripts/sync_site_export_to_public.js extracts from 13 - Lattice Labs.zip.
- Handoff: 08 - Operations/Clarum — NEW CHAT HANDOFF (Start Here).md

Examples (Windows):
- "C:\Users\Melek\Documents\Sinerga-Optima\.venv\Scripts\python.exe" "C:\Users\Melek\Documents\Sinerga-Optima\13 - Lattice Labs\Clarum\08 - Operations\scripts\validate_country_pack.py" "C:\Users\Melek\Documents\Sinerga-Optima\13 - Lattice Labs\Clarum\04 - Data & Ontology\Ontology\_machine\country_pack.schema.v1.json" "C:\Users\Melek\Documents\Sinerga-Optima\13 - Lattice Labs\Clarum\04 - Data & Ontology\Ontology\_machine\country_packs\mexico.v1.yaml"
- "C:\Users\Melek\Documents\Sinerga-Optima\.venv\Scripts\python.exe" "C:\Users\Melek\Documents\Sinerga-Optima\13 - Lattice Labs\Clarum\08 - Operations\scripts\validate_country_pack.py" --relaxed "C:\Users\Melek\Documents\Sinerga-Optima\13 - Lattice Labs\Clarum\04 - Data & Ontology\Ontology\_machine\country_pack.schema.v1.json" "C:\Users\Melek\Documents\Sinerga-Optima\13 - Lattice Labs\Clarum\04 - Data & Ontology\Ontology\_machine\country_packs\mexico.v1.yaml"
- "C:\Users\Melek\Documents\Sinerga-Optima\.venv\Scripts\python.exe" "C:\Users\Melek\Documents\Sinerga-Optima\13 - Lattice Labs\Clarum\08 - Operations\scripts\generate_report_artifact.py" --country-pack "C:\Users\Melek\Documents\Sinerga-Optima\13 - Lattice Labs\Clarum\04 - Data & Ontology\Ontology\_machine\country_packs\mexico.v1.yaml" --case-id "PD-MEX-EV-OEM-EXPORT-001" --country "Mexico" --sector "EV" --role "OEM" --mode "EXPORT" --weight-profile "WP-EV-OEM-EXPORT-1.1" --overlay "Balanced" --out "C:\Users\Melek\Documents\Sinerga-Optima\13 - Lattice Labs\Clarum\04 - Data & Ontology\Ontology\_machine\reports\mexico.ev_oem_export.wp-ev-oem-export-1.1.balanced.report.v1.json"

6) Current State Snapshot (as of 2026-02-10)
- Indicators extracted: 42.
- Packs (Hungary, Mexico, Malaysia) validate OK in strict mode.
- Fatal missingness cleared: IND-A2-GEO-002 and IND-A2-GEO-003 now filled.
- A4 completeness is 100% for all three packs (INF-001..INF-006 filled).
- A4 fills used World Bank proxies:
	- IND-A4-INF-002: EG.ELC.LOSS.ZS (electric power transmission and distribution losses % of output).
	- IND-A4-INF-003: 3y volatility proxy from EG.ELC.LOSS.ZS (std dev).
	- IND-A4-INF-004: IC.CUS.DURS.EX (customs clearance time).
	- IND-A4-INF-005: IT.NET.BBND.P2 (fixed broadband subscriptions per 100 people).
	- IND-A4-INF-006: IC.FRM.DURS (operating license time).
- A1 regulatory quality and rule of law estimates (RQ.EST, RL.EST) filled for Hungary/Mexico/Malaysia.
- A5 manufacturing value added % GDP (NV.IND.MANF.ZS) filled for Hungary/Mexico/Malaysia.
- A6 Human Capital Index (HD.HCI.OVRL) filled for Hungary/Mexico/Malaysia.
- Profile-scope TODOs: none (A2-GEO-005 scored via eCFR listing).
- Profile-weighted completeness now computed in generator (renormalizes weights when domains are out-of-scope).
- Weight profiles mapped in _machine/weight_profiles.v1.json (v1.1 Stable).
- Overall completeness (reports): Hungary 46.67%, Mexico 34.17%, Malaysia 34.17%.
- Profile-weighted completeness (reports): Hungary 80.0%, Mexico 80.0%, Malaysia 86.67%.
- Validator guardrails and token sync applied; warnings reduced to zero.
- Recent runlogs: flagship_sprint4_phase0_baseline_2026-02-10_1903.txt; flagship_sprint4_phase1_required_by_expand_2026-02-10_1904.txt; flagship_sprint4_phase2_fills_2026-02-10_1907.txt; flagship_sprint4_hungary_regen_2026-02-10_1907.txt; flagship_sprint4_mexico_regen_2026-02-10_1907.txt; flagship_sprint4_malaysia_regen_2026-02-10_1907.txt; flagship_sprint4_phase4_dossiers_2026-02-10_1930.txt.

7) Known Issues / Watchlist
- Fatal-missingness list is still hardcoded in generator; should be parsed from rubric.
- A5/A6 Tier-A coverage is sparse beyond SUP-002 and LAB-001.
- IND-A3-POL-002 is Tier-B (WEF/ITU) and remains a policy decision.
- Maintain source token discipline: use canonical short tokens in packs (World Bank, IMF, Eurostat, IEA, UNCTAD, US BIS, European Union, UK OFSI, US Treasury OFAC, UN Security Council).

8) Next Actions (ranked, concrete)
- (A) Expand A5/A6 coverage beyond SUP-002 and LAB-001 (Tier A only).
- (B) Decide whether to expand scope to A3/A7/A8 for flagship profiles.
- (C) Replace A4 proxies with national Tier-A sources (KSH, INEGI, DOSM) where feasible.
- (D) Upgrade scoring from skeleton to rubric-driven scoring once MV-EF thresholds are met.

9) Update Protocol (strict)
- After every Codex run: append a changelog entry with date/time and changes, update snapshot metrics, and add runlog links.
- Changelog is append-only; never delete previous entries.
- Always re-run validator and generator after data edits; record outputs in runlogs.
- New runlogs must be saved in 04 - Data & Ontology/Ontology/_machine/runlogs/.

Changelog (append-only)
- 2026-02-09 15:28: Hungary A3 POL fill (IND-A3-POL-001/003/004/005), strict validation OK, Hungary report regenerated, runlog mv_ef_hungary_a3_pol_fill_2026-02-09_1528.txt.
- 2026-02-09 15:59: Added profile-weighted completeness + weight profile map, filled Mexico IND-A5-SUP-002 (World Bank MVA % GDP), regenerated reports, runlog mv_ef_profile_weighted_mexico_a5_2026-02-09_1559.txt.
- 2026-02-09 16:28: Added profile scope map script and handoff scope map; Tier-A attempts logged for Mexico A5 and Malaysia A6; A4 proxy replacement attempt logged; progress dashboard created; website prerequisites added to handoff; reports regenerated (Hungary/Mexico/Malaysia); open decision remains IND-A3-POL-002 Tier-B not authorized.

Policy Decision (2026-02-09)
- Tier-B is allowed ONLY for indicators whose unit is Score (1–7) and are inherently survey-scale. These must be labeled ‘Tier-B (survey)’ in notes, and must never be treated as Tier-A in downstream rendering.

Changelog (append-only)
- 2026-02-09 16:45: Appended website build transition note to handoff; focus shifts to Clarum website repo. Use Progress Dashboard and reports for UI data contract; keep Tier-B (survey) labeling rule in UI.
- 2026-02-10 02:07: Added Tier-A proxy fills for IND-A2-GEO-004, IND-A4-INF-004, IND-A4-INF-006 across Hungary/Mexico/Malaysia; updated indicator catalog sources; added Evidence Anchor Pack EV-2026-001..EV-2026-015; upgraded three dossiers to Gold Dossier v1 structure; new phase runlogs. Strict validation and report regeneration blocked (pwsh unavailable), pending rerun.
- 2026-02-10 03:15: Added wb_helper.py and filled IND-A4-INF-003 via EG.ELC.LOSS.ZS volatility proxy; added EV-2026-016..EV-2026-023 evidence entries; updated validator overrides, dossiers, and Progress Dashboard; strict validation and report regeneration completed (generate_report_artifact_2026-02-09_2307.txt; regen_reports_2026-02-09_2315.txt).
- 2026-02-10 17:45: Sprint 2 compliance pass: wb_indicator_discovery.py and wb_helper.py updated with retry/backoff + HTTP 200 checks; IND-A4-INF-003 standardized to CV proxy; IND-A2-GEO-005 now references BIS Interactive Country Groups and eCFR link; strict validation OK and reports regenerated (2026-02-10 17:40); new flagship_sprint2 runlogs written.
- 2026-02-10 19:30: Sprint 4 Tier-A expansion complete: indicator catalog required_by updated for A1/A5/A6; WGI RQ/RL, MVA % GDP, and HCI filled for Hungary/Mexico/Malaysia; reports regenerated; EV-2026-024..EV-2026-032 added; dossiers updated; new flagship_sprint4 runlogs written.
- 2026-02-10 19:48: Sprint 5 website gate pack exported (Option A). Site export bundle created at 09 - Publishing/site_export/v1; publish_manifest + payloads + schemas generated; dossiers + evidence exported; validate_site_export.py PASS.

Addendum (2026-02-10 17:45)
- A4 INF-003 proxy now uses CV (std/mean) for EG.ELC.LOSS.ZS 3-year window.
- Latest report artifacts generated at 2026-02-10 17:40:29.
 - Reports regenerated again at 2026-02-10 17:52:41 after blocked URL note updates.

# QA Checklist (Dossier)

## Critical Failures (Do Not Publish)
- [ ] **Missing Evidence:** Any score > 3.0 has zero citations.
- [ ] **Hallucination:** Citation [X] does not support the claim.
- [ ] **Stale Data:** Using 2021 data for a 2026 report without flagging it.
- **Tone Violation:** Using emotional words ("Terrifying," "Disaster").

## Hygiene
- [ ] All acronyms defined on first use.
- [ ] Maps/Charts have clear legends.
- [ ] "Executive Summary" matches the detailed sections.

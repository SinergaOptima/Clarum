import argparse
import json
from datetime import datetime
from pathlib import Path


DOMAIN_IDS = ["A1", "A2", "A3", "A4", "A5", "A6", "A7", "A8"]
FATAL_MISSINGNESS_IDS = [
    "IND-A2-GEO-002",
    "IND-A2-GEO-003",
]
TODO_SENTINEL = "TODO"


def load_yaml_or_json(path: Path):
    text = path.read_text(encoding="utf-8")
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        try:
            import yaml  # type: ignore
        except Exception as exc:
            raise RuntimeError("YAML parser not available; JSON parse failed.") from exc
        return yaml.safe_load(text)


def is_type(value, expected):
    if isinstance(expected, list):
        return any(is_type(value, e) for e in expected)
    if expected == "object":
        return isinstance(value, dict)
    if expected == "array":
        return isinstance(value, list)
    if expected == "string":
        return isinstance(value, str)
    if expected == "number":
        return isinstance(value, (int, float)) and not isinstance(value, bool)
    if expected == "null":
        return value is None
    return True


def validate_schema(data, schema):
    errors = []

    if schema.get("type") == "object":
        if not isinstance(data, dict):
            errors.append("Root must be an object.")
            return errors
        required = schema.get("required", [])
        for key in required:
            if key not in data:
                errors.append(f"Missing required key: {key}")
        properties = schema.get("properties", {})
        for key, prop_schema in properties.items():
            if key in data:
                errors.extend(validate_schema(data[key], prop_schema))

        pattern_props = schema.get("patternProperties", {})
        if pattern_props:
            for key, value in data.items():
                matched = False
                for pattern, prop_schema in pattern_props.items():
                    if __import__("re").match(pattern, key):
                        matched = True
                        errors.extend(validate_schema(value, prop_schema))
                if not matched and schema.get("additionalProperties") is False:
                    errors.append(f"Unexpected key: {key}")

    expected_type = schema.get("type")
    if expected_type:
        if not is_type(data, expected_type):
            errors.append(f"Type mismatch: expected {expected_type}")

    if schema.get("type") == "object":
        required = schema.get("required", [])
        props = schema.get("properties", {})
        for key in required:
            if key in data:
                errors.extend(validate_schema(data[key], props.get(key, {})))

    return errors


def normalize_path(path_value: str, base_dir: Path) -> Path:
    path = Path(path_value)
    return path if path.is_absolute() else (base_dir / path).resolve()


def contains_todo(value) -> bool:
    if not isinstance(value, str):
        return False
    return TODO_SENTINEL in value


def is_value_complete(value) -> bool:
    if value is None:
        return False
    if contains_todo(value):
        return False
    return True


def is_url_complete(url_value) -> bool:
    if not url_value:
        return False
    if contains_todo(url_value):
        return False
    return True


def is_date_complete(date_value) -> bool:
    if not date_value:
        return False
    if contains_todo(date_value):
        return False
    return True


def is_indicator_complete(entry: dict) -> bool:
    return (
        is_value_complete(entry.get("value"))
        and is_url_complete(entry.get("url"))
        and is_date_complete(entry.get("retrieved_date"))
    )


def completeness_for_domain(domain_ids, indicators):
    total = len(domain_ids)
    if total == 0:
        return 0.0, 0, 0
    complete = 0
    for ind_id in domain_ids:
        entry = indicators.get(ind_id, {})
        if is_indicator_complete(entry):
            complete += 1
    return (complete / total) * 100.0, total, complete


def load_weight_profiles(weight_profiles_path: Path) -> dict:
    if not weight_profiles_path.exists():
        return {}
    payload = json.loads(weight_profiles_path.read_text(encoding="utf-8"))
    if isinstance(payload, dict) and "profiles" in payload:
        return payload.get("profiles", {})
    if isinstance(payload, dict):
        return payload
    return {}


def cap_from_pct(pct: float) -> str:
    if pct < 50.0:
        return "low"
    if pct < 75.0:
        return "medium"
    return "high"


def main():
    parser = argparse.ArgumentParser(description="Generate LRF-1 report artifact (v1)")
    parser.add_argument("--country-pack", required=True)
    parser.add_argument("--case-id", required=True)
    parser.add_argument("--country", required=True)
    parser.add_argument("--sector", required=True)
    parser.add_argument("--role", required=True)
    parser.add_argument("--mode", required=True)
    parser.add_argument("--weight-profile", required=True)
    parser.add_argument("--overlay", required=True)
    parser.add_argument("--out", required=True)
    args = parser.parse_args()

    script_dir = Path(__file__).resolve().parent
    clarum_root = (script_dir / ".." / "..").resolve()
    machine_dir = clarum_root / "04 - Data & Ontology" / "Ontology" / "_machine"
    runlogs_dir = machine_dir / "runlogs"
    reports_dir = machine_dir / "reports"

    runlogs_dir.mkdir(parents=True, exist_ok=True)
    reports_dir.mkdir(parents=True, exist_ok=True)

    runlog_path = runlogs_dir / f"generate_report_artifact_{datetime.now().strftime('%Y-%m-%d_%H%M')}.txt"
    log_lines = [f"TIMESTAMP: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"]

    try:
        pack_path = normalize_path(args.country_pack, clarum_root)
        out_path = normalize_path(args.out, clarum_root)
        schema_path = machine_dir / "country_pack.schema.v1.json"
        catalog_path = machine_dir / "indicator_catalog.v1.json"
        weight_profiles_path = machine_dir / "weight_profiles.v1.json"

        log_lines.append(f"COUNTRY_PACK: {pack_path}")
        log_lines.append(f"SCHEMA: {schema_path}")
        log_lines.append(f"CATALOG: {catalog_path}")
        log_lines.append(f"OUTPUT: {out_path}")
        log_lines.append(f"WEIGHT_PROFILES: {weight_profiles_path}")

        pack = load_yaml_or_json(pack_path)
        schema = json.loads(schema_path.read_text(encoding="utf-8"))
        errors = validate_schema(pack, schema)
        if errors:
            log_lines.append("VALIDATION: FAILED")
            log_lines.extend([f"ERROR: {err}" for err in errors])
            runlog_path.write_text("\n".join(log_lines), encoding="utf-8")
            print("VALIDATION_FAILED")
            for err in errors:
                print(f"- {err}")
            raise SystemExit(1)

        log_lines.append("VALIDATION: OK")

        catalog = json.loads(catalog_path.read_text(encoding="utf-8"))
        weight_profiles = load_weight_profiles(weight_profiles_path)
        domain_map = {domain: [] for domain in DOMAIN_IDS}
        required_by_map = {}
        for ind in catalog:
            domain = ind.get("domain")
            ind_id = ind.get("id")
            if domain in domain_map and ind_id:
                domain_map[domain].append(ind_id)
                required_by_map[ind_id] = ind.get("required_by", [])

        indicators = pack.get("indicators", {})
        evidence_tier_summary = {"A": 0, "B": 0}
        tier_b_ids = []
        indicators_out = {}
        for ind_id, entry in indicators.items():
            evidence_tier = entry.get("evidence_tier", "A")
            if evidence_tier not in ("A", "B"):
                warnings.append(
                    f"Evidence tier for {ind_id} invalid; defaulted to Tier A."
                )
                evidence_tier = "A"
            if evidence_tier == "B":
                tier_b_ids.append(ind_id)
            evidence_tier_summary[evidence_tier] += 1
            indicator_out = dict(entry)
            indicator_out["evidence_tier"] = evidence_tier
            indicator_out["confidence_cap"] = 0.6 if evidence_tier == "B" else 1.0
            indicators_out[ind_id] = indicator_out
        completeness_by_domain = {}
        domain_caps = {}
        for domain in DOMAIN_IDS:
            pct, total, _ = completeness_for_domain(domain_map.get(domain, []), indicators)
            completeness_by_domain[domain] = round(pct, 2)
            domain_caps[domain] = cap_from_pct(pct)
            log_lines.append(f"COMPLETENESS_{domain}: {pct:.2f} ({total} indicators)")

        overall_pct = round(sum(completeness_by_domain.values()) / len(DOMAIN_IDS), 2)
        overall_cap = min(domain_caps.values(), key=lambda cap: ["low", "medium", "high"].index(cap))

        fatal_missing = []
        for ind_id in FATAL_MISSINGNESS_IDS:
            entry = indicators.get(ind_id, {})
            if not is_indicator_complete(entry):
                fatal_missing.append(ind_id)

        fatal_triggered = len(fatal_missing) > 0
        warnings = []
        warnings.append("Fatal-missingness list is provisional; sync from rubric in v1.1.")

        if fatal_triggered:
            overall_cap = "low"
            warnings.append("Fatal missingness triggered; overall confidence capped to low.")

        if tier_b_ids:
            warnings.append(
                "Tier B evidence present; per-indicator confidence capped to 0.60."
            )

        confidence_reasons = []
        for domain in DOMAIN_IDS:
            cap = domain_caps[domain]
            if cap == "low":
                confidence_reasons.append(f"{domain} completeness < 50%")
            elif cap == "medium":
                confidence_reasons.append(f"{domain} completeness < 75%")

        if fatal_triggered:
            confidence_reasons.append("Fatal missingness indicators incomplete")

        metadata = pack.get("metadata", {})
        profile_weights = weight_profiles.get(args.weight_profile, {})
        if not profile_weights:
            warnings.append(
                f"Weight profile not found in weight_profiles.v1.json: {args.weight_profile}."
            )
        profile_domains = {}
        omitted_domains = []
        weight_sum = 0.0
        for domain in DOMAIN_IDS:
            in_scope_ids = [
                ind_id
                for ind_id in domain_map.get(domain, [])
                if args.weight_profile in required_by_map.get(ind_id, [])
            ]
            pct, total, complete = completeness_for_domain(in_scope_ids, indicators)
            profile_domains[domain] = {
                "pct": round(pct, 2),
                "in_scope": total,
                "complete": complete,
            }
            weight_value = profile_weights.get(domain)
            if total == 0:
                omitted_domains.append(domain)
                continue
            if weight_value is None:
                warnings.append(
                    f"Weight missing for profile {args.weight_profile} domain {domain}."
                )
                continue
            weight_sum += weight_value

        weights_used = {}
        if weight_sum > 0:
            for domain in DOMAIN_IDS:
                if profile_domains[domain]["in_scope"] == 0:
                    continue
                weight_value = profile_weights.get(domain)
                if weight_value is None:
                    continue
                weights_used[domain] = weight_value / weight_sum
        else:
            warnings.append(
                f"Profile-weighted completeness not computed; no weights resolved for {args.weight_profile}."
            )

        profile_weighted_pct = None
        if weights_used:
            profile_weighted_pct = round(
                sum(
                    profile_domains[domain]["pct"] * weight
                    for domain, weight in weights_used.items()
                ),
                2,
            )
        report = {
            "meta": {
                "report_version": "v1",
                "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "case": {
                    "case_id": args.case_id,
                    "country": args.country,
                    "sector": args.sector,
                    "role": args.role,
                    "mode": args.mode,
                },
                "methodology": {
                    "lrf_version": "LRF-1",
                    "indicator_catalog_version": "v1",
                    "country_pack_version": "v1",
                    "weight_profile_id": args.weight_profile,
                    "overlay_id": args.overlay,
                    "rubric_version": "LRF-1.1",
                },
                "normalization": {
                    "comparator_set_id": metadata.get("comparator_set_id", "GLOBAL-GDP-10B+"),
                    "method": metadata.get("normalization_method", "PERCENTILE-RANK"),
                },
                "evidence_tier_summary": evidence_tier_summary,
            },
            "completeness": {
                "overall_pct": overall_pct,
                "by_domain": completeness_by_domain,
                "profile_weighted_pct": profile_weighted_pct,
                "domain_breakdown": profile_domains,
                "weights_used": weights_used,
            },
            "confidence": {
                "overall_cap": overall_cap,
                "by_domain_cap": domain_caps,
                "reasons": confidence_reasons,
            },
            "fatal_missingness": {
                "triggered": fatal_triggered,
                "missing_indicator_ids": fatal_missing,
                "notes": ["Provisional fatal list; sync from rubric note."],
            },
            "indicators": indicators_out,
            "scores": {
                "composite": {
                    "value": None,
                    "reason": "scoring not computed in v1",
                },
                "domains": {
                    domain: {
                        "value": None,
                        "cap": domain_caps[domain],
                        "reason": "insufficient data" if completeness_by_domain[domain] < 75.0 else "scoring not computed in v1",
                        "missing_pct": round(100.0 - completeness_by_domain[domain], 2),
                    }
                    for domain in DOMAIN_IDS
                },
            },
            "flags": {
                "triggered": [],
                "watchlist": [],
            },
            "warnings": warnings,
            "next_actions": [
                "Implement scoring once MV-EF completeness >= 75% for key domains.",
                "Sync fatal-missingness list automatically from rubric note.",
            ],
        }

        if tier_b_ids:
            report["flags"]["triggered"].append(
                {
                    "id": "FLAG-TIERB-PRESENT",
                    "summary": "Tier B evidence present; confidence capped per indicator.",
                    "indicator_ids": sorted(tier_b_ids),
                }
            )

        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(json.dumps(report, indent=2), encoding="utf-8")

        log_lines.append(f"OVERALL_COMPLETENESS: {overall_pct:.2f}")
        log_lines.append(f"PROFILE_WEIGHTED_COMPLETENESS: {profile_weighted_pct}")
        if omitted_domains:
            log_lines.append(
                "PROFILE_WEIGHTED_OMITTED_DOMAINS: " + ", ".join(omitted_domains)
            )
        log_lines.append(f"OVERALL_CONFIDENCE_CAP: {overall_cap}")
        log_lines.append(f"FATAL_MISSINGNESS_TRIGGERED: {fatal_triggered}")
        if fatal_missing:
            log_lines.append("FATAL_MISSING_IDS: " + ", ".join(fatal_missing))

        runlog_path.write_text("\n".join(log_lines), encoding="utf-8")

        print(f"REPORT_WRITTEN: {out_path}")
        print(f"COMPLETENESS_OVERALL: {overall_pct:.2f}")
        print("COMPLETENESS_BY_DOMAIN: " + ", ".join([f"{d}={completeness_by_domain[d]:.2f}" for d in DOMAIN_IDS]))
        print(f"FATAL_MISSINGNESS_TRIGGERED: {fatal_triggered}")
        if fatal_missing:
            print("FATAL_MISSING_IDS: " + ", ".join(fatal_missing))

    except SystemExit:
        raise
    except Exception as exc:
        log_lines.append(f"ERROR: {exc}")
        runlog_path.write_text("\n".join(log_lines), encoding="utf-8")
        raise


if __name__ == "__main__":
    main()

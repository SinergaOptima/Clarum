import argparse
import datetime as dt
from pathlib import Path

from wits_helper import get_indicator_value_for_year, get_indicator_value_latest


CLARUM_ROOT = Path(__file__).resolve().parents[2]
PACK_DIR = (
    CLARUM_ROOT
    / "04 - Data & Ontology"
    / "Ontology"
    / "_machine"
    / "country_packs"
)

DATASOURCE = "tradestats-trade"
INDICATOR_CODE = "HH-MKT-CNCNTRTN-NDX"
DEFAULT_COUNTRIES = "hun,mex,mys"

COUNTRY_MAP = {
    "hun": {"iso3": "HUN", "pack": "hungary.v1.yaml", "name": "Hungary"},
    "mex": {"iso3": "MEX", "pack": "mexico.v1.yaml", "name": "Mexico"},
    "mys": {"iso3": "MYS", "pack": "malaysia.v1.yaml", "name": "Malaysia"},
}


def _format_float(value: float) -> str:
    text = f"{value:.12f}".rstrip("0").rstrip(".")
    return text if text else "0"


def _build_indicator_block(indent: str, value: float, url: str, retrieved_date: str, notes: str) -> list[str]:
    field_indent = indent + "  "
    lines = [f'{indent}"IND-A5-SUP-001": {{']
    lines.append(f'{field_indent}"value": {_format_float(value)},')
    lines.append(f'{field_indent}"unit": "Score (0-1)",')
    lines.append(f'{field_indent}"source_institution": "WITS (World Bank)",')
    lines.append(f'{field_indent}"url": "{url}",')
    lines.append(f'{field_indent}"retrieved_date": "{retrieved_date}",')
    lines.append(f'{field_indent}"notes": "{notes}"')
    lines.append(f"{indent}}},")
    return lines


def _replace_indicator_block(text: str, new_block_lines: list[str]) -> str:
    lines = text.splitlines()
    start_index = None
    end_index = None
    indent = None

    for idx, line in enumerate(lines):
        if '"IND-A5-SUP-001": {' in line:
            start_index = idx
            indent = line.split('"')[0]
            break

    if start_index is None or indent is None:
        raise RuntimeError("IND-A5-SUP-001 block not found in country pack.")

    for idx in range(start_index + 1, len(lines)):
        if lines[idx].startswith(indent) and lines[idx].strip() in ("}", "},"):
            end_index = idx
            break

    if end_index is None:
        raise RuntimeError("Failed to locate end of IND-A5-SUP-001 block.")

    rebuilt = lines[:start_index] + new_block_lines + lines[end_index + 1 :]
    return "\n".join(rebuilt) + ("\n" if text.endswith("\n") else "")


def _diff_block(path: Path, old_block: list[str], new_block: list[str]) -> None:
    print(f"--- {path}")
    print(f"+++ {path}")
    for line in old_block:
        print(f"- {line}")
    for line in new_block:
        print(f"+ {line}")


def _extract_existing_block(text: str) -> list[str]:
    lines = text.splitlines()
    start_index = None
    end_index = None

    for idx, line in enumerate(lines):
        if '"IND-A5-SUP-001": {' in line:
            start_index = idx
            indent = line.split('"')[0]
            break

    if start_index is None:
        return []

    for idx in range(start_index + 1, len(lines)):
        if lines[idx].startswith(indent) and lines[idx].strip() in ("}", "},"):
            end_index = idx
            break

    if end_index is None:
        return []

    return lines[start_index : end_index + 1]


def _get_value_for_country(iso3: str, year_override: int | None) -> tuple[int, float, str]:
    if year_override is not None:
        return get_indicator_value_for_year(DATASOURCE, iso3, INDICATOR_CODE, year_override)
    return get_indicator_value_latest(DATASOURCE, iso3, INDICATOR_CODE)


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Fill IND-A5-SUP-001 using WITS TradeStats HH market concentration index.",
    )
    parser.add_argument(
        "--countries",
        default=DEFAULT_COUNTRIES,
        help="Comma-separated country codes (hun,mex,mys by default).",
    )
    parser.add_argument("--dry-run", action="store_true", help="Print changes without writing.")
    parser.add_argument("--year", type=int, help="Optional override year.")
    args = parser.parse_args()

    requested = [item.strip().lower() for item in args.countries.split(",") if item.strip()]
    today = dt.date.today().isoformat()

    for code in requested:
        if code not in COUNTRY_MAP:
            raise RuntimeError(f"Unknown country code: {code}")

        meta = COUNTRY_MAP[code]
        pack_path = PACK_DIR / meta["pack"]
        year, value, url = _get_value_for_country(meta["iso3"], args.year)

        ui_url = (
            "https://wits.worldbank.org/CountryProfile/en/country/by-country/"
            "startyear/ltst/endyear/ltst/indicator/HH-MKT-CNCNTRTN-NDX"
        )
        if args.year is not None:
            notes = (
                "Proxy for export concentration: WITS TradeStats HH market concentration index "
                f"(HH-MKT-CNCNTRTN-NDX), year {year} (override). UI: {ui_url}"
            )
        else:
            notes = (
                "Proxy for export concentration: WITS TradeStats HH market concentration index "
                f"(HH-MKT-CNCNTRTN-NDX), latest available year {year}. UI: {ui_url}"
            )

        pack_text = pack_path.read_text(encoding="utf-8")
        new_block = _build_indicator_block("    ", value, url, today, notes)
        old_block = _extract_existing_block(pack_text)

        updated_text = _replace_indicator_block(pack_text, new_block)

        if args.dry_run:
            _diff_block(pack_path, old_block, new_block)
        else:
            pack_path.write_text(updated_text, encoding="utf-8")
            print(
                f"Updated {meta['name']} (year {year}, value {value}) -> {pack_path}"
            )


if __name__ == "__main__":
    main()

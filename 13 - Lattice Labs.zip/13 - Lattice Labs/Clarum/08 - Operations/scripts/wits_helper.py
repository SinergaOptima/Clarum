import json
import re
import time
import xml.etree.ElementTree as ET
from typing import Any, Iterable

from http_cache.http_cache import HttpCacheError, fetch_bytes, fetch_json


def fetch_xml(url: str, *, stale_if_error: bool = True) -> ET.Element:
    result = fetch_bytes(url, stale_if_error=stale_if_error)
    body = result["data"]
    try:
        xml_text = body.decode("utf-8-sig", errors="replace")
        return ET.fromstring(xml_text)
    except ET.ParseError as exc:
        raise RuntimeError(f"Failed to parse XML from {url}: {exc}") from exc


def fetch_json_payload(url: str, *, stale_if_error: bool = True) -> dict:
    result = fetch_json(url, stale_if_error=stale_if_error)
    payload = result["data"]
    if not isinstance(payload, dict):
        raise RuntimeError(f"Expected JSON object from {url}, got {type(payload).__name__}.")
    return payload


def fetch_json_with_provenance(url: str, *, stale_if_error: bool = True) -> tuple[dict, dict]:
    result = fetch_json(url, stale_if_error=stale_if_error)
    payload = result["data"]
    if not isinstance(payload, dict):
        raise RuntimeError(f"Expected JSON object from {url}, got {type(payload).__name__}.")
    return payload, result["provenance"]


def fetch_xml_with_provenance(url: str, *, stale_if_error: bool = True) -> tuple[ET.Element, dict]:
    result = fetch_bytes(url, stale_if_error=stale_if_error)
    body = result["data"]
    try:
        xml_text = body.decode("utf-8-sig", errors="replace")
        return ET.fromstring(xml_text), result["provenance"]
    except ET.ParseError as exc:
        raise RuntimeError(f"Failed to parse XML from {url}: {exc}") from exc


def _extract_years(root: ET.Element) -> list[int]:
    years: set[int] = set()
    for element in root.iter():
        if element.text:
            text = element.text.strip()
            if re.fullmatch(r"\d{4}", text):
                years.add(int(text))
        for value in element.attrib.values():
            if isinstance(value, str):
                text = value.strip()
                if re.fullmatch(r"\d{4}", text):
                    years.add(int(text))
    return sorted(years)


def get_latest_year_for_indicator(datasource: str, country_iso3: str, indicator_code: str) -> int:
    base_url = (
        "https://wits.worldbank.org/API/V1/wits/datasource/"
        f"{datasource}/dataavailability/country/{country_iso3}/indicator/{indicator_code}"
    )
    fallback_url = (
        "https://wits.worldbank.org/API/V1/wits/datasource/"
        f"{datasource}/dataavailability/country/{country_iso3}/year/all/indicator/{indicator_code}"
    )

    try:
        root = fetch_xml(base_url)
        years = _extract_years(root)
        if years:
            return max(years)
        print(
            "WITS dataavailability endpoint returned no years; "
            f"trying fallback endpoint: {fallback_url}"
        )
    except Exception as exc:
        print(
            "WITS dataavailability endpoint failed; "
            f"trying fallback endpoint: {fallback_url} ({exc})"
        )

    root = fetch_xml(fallback_url)
    years = _extract_years(root)
    if years:
        return max(years)

    raise RuntimeError(
        "No available years returned from WITS dataavailability endpoints. "
        f"Tried {base_url} and {fallback_url}."
    )


def _build_sdmx_url(
    datasource: str,
    country_iso3: str,
    year: int,
    indicator_code: str,
    partner: str | None = None,
    product: str | None = None,
) -> str:
    parts = [
        "https://wits.worldbank.org/API/V1/SDMX/V21/datasource",
        datasource,
        "reporter",
        country_iso3,
    ]
    if partner:
        parts.extend(["partner", partner])
    if product:
        parts.extend(["product", product])
    parts.extend(["year", str(year), "indicator", indicator_code])
    return "/".join(parts) + "?format=JSON"


def _coerce_obs_value(obs_value: Any) -> float | None:
    if isinstance(obs_value, list) and obs_value:
        if obs_value[0] is None:
            return None
        try:
            return float(obs_value[0])
        except (TypeError, ValueError):
            return None
    if isinstance(obs_value, dict) and "value" in obs_value:
        try:
            return float(obs_value["value"])
        except (TypeError, ValueError):
            return None
    return None


def _extract_values_from_sdmx(payload: dict) -> list[float]:
    values: list[float] = []
    data_sets = payload.get("dataSets")
    if not isinstance(data_sets, list):
        return values

    for data_set in data_sets:
        if not isinstance(data_set, dict):
            continue
        series_map = data_set.get("series")
        if isinstance(series_map, dict):
            for series in series_map.values():
                if not isinstance(series, dict):
                    continue
                observations = series.get("observations")
                if isinstance(observations, dict):
                    for obs_value in observations.values():
                        value = _coerce_obs_value(obs_value)
                        if value is not None:
                            values.append(value)
        observations = data_set.get("observations")
        if isinstance(observations, dict):
            for obs_value in observations.values():
                value = _coerce_obs_value(obs_value)
                if value is not None:
                    values.append(value)

    return values


def _select_single_value(values: Iterable[float], url: str) -> float:
    values_list = list(values)
    if not values_list:
        raise RuntimeError(f"No observations returned from {url}.")
    unique_values = {round(value, 12) for value in values_list}
    if len(unique_values) == 1:
        return values_list[0]
    raise RuntimeError(
        "Multiple distinct values returned from WITS SDMX response. "
        "Add partner/product filters or inspect the raw payload. "
        f"URL: {url}"
    )


def get_indicator_value_for_year(
    datasource: str, country_iso3: str, indicator_code: str, year: int
) -> tuple[int, float, str]:
    candidate_urls = [
        _build_sdmx_url(datasource, country_iso3, year, indicator_code),
        _build_sdmx_url(
            datasource, country_iso3, year, indicator_code, partner="wld"
        ),
        _build_sdmx_url(
            datasource, country_iso3, year, indicator_code, product="total"
        ),
        _build_sdmx_url(
            datasource,
            country_iso3,
            year,
            indicator_code,
            partner="wld",
            product="total",
        ),
    ]

    last_error = None
    for url in candidate_urls:
        try:
            payload = fetch_json_payload(url)
            values = _extract_values_from_sdmx(payload)
            if values:
                value = _select_single_value(values, url)
                return year, value, url
            last_error = RuntimeError("Empty SDMX response")
            print(f"No observations found; trying fallback URL: {url}")
        except Exception as exc:
            last_error = exc
            print(f"Failed SDMX request; trying fallback URL: {url} ({exc})")

    raise RuntimeError(
        "WITS SDMX response returned no usable values. "
        f"Last error: {last_error}. "
        "Try adding partner/product filters or inspect WITS UI."
    )


def get_indicator_value_latest(
    datasource: str, country_iso3: str, indicator_code: str
) -> tuple[int, float, str]:
    year = get_latest_year_for_indicator(datasource, country_iso3, indicator_code)
    return get_indicator_value_for_year(datasource, country_iso3, indicator_code, year)


def get_indicator_value_for_year_cached(
    datasource: str,
    country_iso3: str,
    indicator_code: str,
    year: int,
    *,
    stale_if_error: bool = True,
) -> tuple[int, float, str, dict]:
    candidate_urls = [
        _build_sdmx_url(datasource, country_iso3, year, indicator_code),
        _build_sdmx_url(datasource, country_iso3, year, indicator_code, partner="wld"),
        _build_sdmx_url(datasource, country_iso3, year, indicator_code, product="total"),
        _build_sdmx_url(
            datasource,
            country_iso3,
            year,
            indicator_code,
            partner="wld",
            product="total",
        ),
    ]

    last_error = None
    for url in candidate_urls:
        try:
            payload, provenance = fetch_json_with_provenance(
                url, stale_if_error=stale_if_error
            )
            values = _extract_values_from_sdmx(payload)
            if values:
                value = _select_single_value(values, url)
                return year, value, url, provenance
            last_error = RuntimeError("Empty SDMX response")
        except HttpCacheError:
            raise
        except Exception as exc:
            last_error = exc
            continue

    raise RuntimeError(
        "WITS SDMX response returned no usable values. "
        f"Last error: {last_error}."
    )


def get_indicator_value_latest_cached(
    datasource: str,
    country_iso3: str,
    indicator_code: str,
    *,
    stale_if_error: bool = True,
) -> tuple[int, float, str, dict]:
    base_url = (
        "https://wits.worldbank.org/API/V1/wits/datasource/"
        f"{datasource}/dataavailability/country/{country_iso3}/indicator/{indicator_code}"
    )
    fallback_url = (
        "https://wits.worldbank.org/API/V1/wits/datasource/"
        f"{datasource}/dataavailability/country/{country_iso3}/year/all/indicator/{indicator_code}"
    )

    try:
        root, _ = fetch_xml_with_provenance(base_url, stale_if_error=stale_if_error)
        years = _extract_years(root)
        if years:
            year = max(years)
        else:
            root, _ = fetch_xml_with_provenance(
                fallback_url, stale_if_error=stale_if_error
            )
            years = _extract_years(root)
            if not years:
                raise RuntimeError("No years returned from WITS dataavailability endpoints.")
            year = max(years)
    except HttpCacheError:
        raise
    except Exception as exc:
        raise RuntimeError(
            "WITS dataavailability endpoint failed for cached fetch: "
            f"{exc}"
        ) from exc

    candidate_urls = [
        _build_sdmx_url(datasource, country_iso3, year, indicator_code),
        _build_sdmx_url(datasource, country_iso3, year, indicator_code, partner="wld"),
        _build_sdmx_url(datasource, country_iso3, year, indicator_code, product="total"),
        _build_sdmx_url(
            datasource,
            country_iso3,
            year,
            indicator_code,
            partner="wld",
            product="total",
        ),
    ]

    last_error = None
    for url in candidate_urls:
        try:
            payload, provenance = fetch_json_with_provenance(
                url, stale_if_error=stale_if_error
            )
            values = _extract_values_from_sdmx(payload)
            if values:
                value = _select_single_value(values, url)
                return year, value, url, provenance
            last_error = RuntimeError("Empty SDMX response")
        except HttpCacheError:
            raise
        except Exception as exc:
            last_error = exc
            continue

    raise RuntimeError(
        "WITS SDMX response returned no usable values. "
        f"Last error: {last_error}."
    )

import argparse
import json
import os
import time
import urllib.error
import urllib.request


ROOT = os.path.abspath(
    os.path.join(os.path.dirname(__file__), "..", "..", "04 - Data & Ontology", "Ontology", "_machine")
)
CACHE_DIR = os.path.join(ROOT, "cache")
CACHE_FILE = os.path.join(CACHE_DIR, "wb_indicators.json")
WB_INDICATOR_URL = "https://api.worldbank.org/v2/indicator?format=json&per_page=20000"


def _http_get_json(url: str, retries: int = 3, backoff_seconds: float = 1.0):
    last_error = None
    for attempt in range(1, retries + 1):
        try:
            with urllib.request.urlopen(url) as response:
                status = response.getcode()
                if status != 200:
                    raise RuntimeError(f"HTTP {status} for {url}")
                return json.loads(response.read().decode("utf-8"))
        except (urllib.error.URLError, RuntimeError, json.JSONDecodeError) as exc:
            last_error = exc
            if attempt < retries:
                time.sleep(backoff_seconds * (2 ** (attempt - 1)))
    raise RuntimeError(f"Failed to fetch {url} after {retries} attempts: {last_error}")


def ensure_cache() -> list:
    os.makedirs(CACHE_DIR, exist_ok=True)
    if os.path.exists(CACHE_FILE):
        with open(CACHE_FILE, "r", encoding="utf-8") as handle:
            return json.load(handle)
    data = _http_get_json(WB_INDICATOR_URL)
    indicators = data[1] if isinstance(data, list) and len(data) > 1 else []
    if not indicators:
        raise RuntimeError("World Bank indicator list returned no data.")
    with open(CACHE_FILE, "w", encoding="utf-8") as handle:
        json.dump(indicators, handle, ensure_ascii=True, indent=2)
    return indicators


def search_indicators(keyword: str) -> list:
    indicators = ensure_cache()
    keyword_lower = keyword.lower()
    matches = [
        item
        for item in indicators
        if keyword_lower in (item.get("name") or "").lower()
        or keyword_lower in (item.get("id") or "").lower()
    ]
    return matches


def fetch_latest_values(country_code: str, indicator_id: str, years: int) -> list:
    url = f"https://api.worldbank.org/v2/country/{country_code}/indicator/{indicator_id}?format=json&per_page=200"
    data = _http_get_json(url)
    series = data[1] if len(data) > 1 else []
    values = []
    for entry in series:
        if entry.get("value") is None:
            continue
        values.append(
            {
                "date": entry.get("date"),
                "value": entry.get("value"),
            }
        )
        if len(values) >= years:
            break
    return values


def main():
    parser = argparse.ArgumentParser(
        description="World Bank indicator discovery helper.",
        epilog='Example: python wb_indicator_discovery.py --search "Political Stability and Absence of Violence"',
    )
    parser.add_argument("--search", help="Keyword search in indicator list.")
    parser.add_argument("--country", help="ISO3 country code for data retrieval.")
    parser.add_argument("--indicator", help="World Bank indicator ID for data retrieval.")
    parser.add_argument("--years", type=int, default=5, help="Number of years to return.")
    args = parser.parse_args()

    if args.search:
        matches = search_indicators(args.search)
        print(json.dumps(matches, ensure_ascii=True, indent=2))
        return

    if args.country and args.indicator:
        values = fetch_latest_values(args.country, args.indicator, args.years)
        print(json.dumps(values, ensure_ascii=True, indent=2))
        return

    parser.error("Provide --search or --country and --indicator.")


if __name__ == "__main__":
    main()

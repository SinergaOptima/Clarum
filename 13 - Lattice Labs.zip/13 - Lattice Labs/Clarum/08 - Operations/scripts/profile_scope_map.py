import json
from pathlib import Path


def resolve_clarum_root() -> Path:
    return (Path(__file__).resolve().parent / ".." / "..").resolve()


def load_catalog(catalog_path: Path) -> list[dict]:
    return json.loads(catalog_path.read_text(encoding="utf-8"))


def load_profiles_from_reports(reports_dir: Path) -> list[str]:
    profiles = set()
    for report_path in sorted(reports_dir.glob("*.report.v1.json")):
        payload = json.loads(report_path.read_text(encoding="utf-8"))
        profile_id = (
            payload.get("meta", {})
            .get("methodology", {})
            .get("weight_profile_id")
        )
        if profile_id:
            profiles.add(profile_id)
    return sorted(profiles)


def build_scope_map(catalog: list[dict], profile_ids: list[str]) -> dict[str, list[str]]:
    scope_map = {profile_id: [] for profile_id in profile_ids}
    for entry in catalog:
        ind_id = entry.get("id")
        required_by = entry.get("required_by", [])
        if not ind_id or not isinstance(required_by, list):
            continue
        for profile_id in profile_ids:
            if profile_id in required_by:
                scope_map[profile_id].append(ind_id)
    for profile_id, indicators in scope_map.items():
        scope_map[profile_id] = sorted(indicators)
    return scope_map


def main() -> None:
    clarum_root = resolve_clarum_root()
    machine_dir = clarum_root / "04 - Data & Ontology" / "Ontology" / "_machine"
    catalog_path = machine_dir / "indicator_catalog.v1.json"
    reports_dir = machine_dir / "reports"

    catalog = load_catalog(catalog_path)
    profile_ids = load_profiles_from_reports(reports_dir)
    scope_map = build_scope_map(catalog, profile_ids)

    print("PROFILE_SCOPE_MAP")
    for profile_id in profile_ids:
        indicators = scope_map.get(profile_id, [])
        print(f"- {profile_id} ({len(indicators)} indicators)")
        for ind_id in indicators:
            print(f"  - {ind_id}")


if __name__ == "__main__":
    main()

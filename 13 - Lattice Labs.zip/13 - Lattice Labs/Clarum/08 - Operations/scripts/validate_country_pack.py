import argparse
import json
import re
import sys
import urllib.parse
from pathlib import Path


EXPECTED_UNITS = {
    "IND-A5-SUP-005": ["Index (50=neutral)", "Index (50 = neutral)", "Index(50=neutral)"],
}

A8_CONTRACT_INDICATORS = {
    "IND-A8-ESG-001",
    "IND-A8-ESG-002",
}

A8_EXPECTED_UNIT = "Score (0-100)"

SOURCE_TOKEN_OVERRIDES = {
    "IND-A2-GEO-005": ["BIS", "Wassenaar"],
    "IND-A4-INF-003": ["World Bank"],
    "IND-A6-LAB-002": ["World Bank"],
    "IND-A5-SUP-005": ["S&P", "S&P Global", "PMI"],
    "IND-A7-CAP-003": ["World Bank"],
    "IND-A5-SUP-001": [
        "WITS (World Bank)",
        "World Bank WITS",
        "WITS",
        "World Bank",
        "WITS TradeStats",
        "WITS (World Bank) TradeStats",
        "World Bank (WITS)",
    ],
}

DOMAIN_SOURCE_RULES = [
    ("api.worldbank.org", ["world bank"]),
    ("worldbank.org", ["world bank"]),
    ("imf.org", ["imf"]),
    ("oecd.org", ["oecd"]),
    ("weforum.org", ["wef", "world economic forum"]),
    ("bis.gov", ["bis"]),
    ("eur-lex.europa.eu", ["european union", "eu"]),
    ("europa.eu", ["european union", "eu"]),
    ("ofac.treasury.gov", ["ofac", "treasury"]),
    ("treasury.gov", ["treasury"]),
    ("gov.uk", ["uk", "united kingdom", "fcdo", "hmt", "hm treasury"]),
    ("un.org", ["un", "united nations"]),
    ("unctad.org", ["unctad"]),
    ("iea.org", ["iea"]),
    ("unesco.org", ["unesco"]),
    ("acleddata.com", ["acled"]),
    ("ucdp.uu.se", ["ucdp"]),
]


def _check_pack_header(text: str) -> None:
    stripped = text.lstrip("\ufeff").lstrip()
    if not stripped:
        raise RuntimeError("Pack header corruption: empty file.")
    first = stripped[0]
    if first == "Z":
        raise RuntimeError(
            "Pack header corruption: unexpected leading char(s). Likely stray `Z` prefix. Fix by removing leading `Z`."
        )
    if first not in ("{", "-", "?", "%", "["):
        raise RuntimeError(
            "Pack header corruption: unexpected leading char(s). "
            f"First non-whitespace char '{first}'. Expected '{{' or a YAML token. "
            "Likely stray `Z` prefix. Fix by removing leading `Z`."
        )


def load_yaml_or_json(path: Path):
    text = path.read_text(encoding="utf-8")
    _check_pack_header(text)
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        try:
            import yaml  # type: ignore
        except Exception as exc:
            raise RuntimeError("YAML parser not available; JSON parse failed.") from exc
        return yaml.safe_load(text)


def is_type(value, expected):
    if isinstance(expected, list):
        return any(is_type(value, e) for e in expected)
    if expected == "object":
        return isinstance(value, dict)
    if expected == "array":
        return isinstance(value, list)
    if expected == "string":
        return isinstance(value, str)
    if expected == "number":
        return isinstance(value, (int, float)) and not isinstance(value, bool)
    if expected == "null":
        return value is None
    return True


def validate_schema(data, schema):
    errors = []

    if schema.get("type") == "object":
        if not isinstance(data, dict):
            errors.append("Root must be an object.")
            return errors
        required = schema.get("required", [])
        for key in required:
            if key not in data:
                errors.append(f"Missing required key: {key}")
        properties = schema.get("properties", {})
        for key, prop_schema in properties.items():
            if key in data:
                errors.extend(validate_schema(data[key], prop_schema))

        pattern_props = schema.get("patternProperties", {})
        if pattern_props:
            for key, value in data.items():
                matched = False
                for pattern, prop_schema in pattern_props.items():
                    if __import__("re").match(pattern, key):
                        matched = True
                        errors.extend(validate_schema(value, prop_schema))
                if not matched and schema.get("additionalProperties") is False:
                    errors.append(f"Unexpected key: {key}")

    expected_type = schema.get("type")
    if expected_type:
        if not is_type(data, expected_type):
            errors.append(f"Type mismatch: expected {expected_type}")

    if schema.get("type") == "object":
        required = schema.get("required", [])
        props = schema.get("properties", {})
        for key in required:
            if key in data:
                errors.extend(validate_schema(data[key], props.get(key, {})))

    return errors


def find_machine_dir(pack_path: Path) -> Path | None:
    for parent in [pack_path.parent, *pack_path.parents]:
        if parent.name == "_machine":
            return parent
    return None


def load_indicator_catalog(machine_dir: Path) -> dict:
    catalog_path = machine_dir / "indicator_catalog.v1.json"
    if not catalog_path.exists():
        return {}
    catalog = json.loads(catalog_path.read_text(encoding="utf-8"))
    return {entry.get("id"): entry for entry in catalog if isinstance(entry, dict)}


def load_tierb_allowlist(machine_dir: Path) -> tuple[dict | None, Path]:
    allowlist_path = machine_dir / "TIERB_ALLOWLIST.v1.json"
    if not allowlist_path.exists():
        return None, allowlist_path
    payload = json.loads(allowlist_path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        return None, allowlist_path
    return payload, allowlist_path


def extract_url_domains(url_value: str) -> list[str]:
    if not isinstance(url_value, str) or not url_value or "TODO(URL)" in url_value:
        return []
    segments = [segment.strip() for segment in url_value.split("|") if segment.strip()]
    domains = []
    for segment in segments:
        parsed = urllib.parse.urlparse(segment)
        if parsed.netloc:
            domains.append(parsed.netloc.lower())
    return domains


def normalize_unit(unit_value: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", unit_value.lower())


def extract_year_hint(value: str) -> int | None:
    if not isinstance(value, str):
        return None
    years = re.findall(r"\b(19\d{2}|20\d{2})\b", value)
    if not years:
        return None
    return int(years[-1])


def build_allowed_source_tokens(catalog_map: dict) -> dict:
    allowed = {}
    for ind_id, entry in catalog_map.items():
        canonical = entry.get("canonical_source_institution")
        if not canonical:
            continue
        tokens = [canonical]
        for part in re.split(r"[/,&;]", canonical):
            part = part.strip()
            if part:
                tokens.append(part)
        tokens = list({token.strip() for token in tokens if token.strip()})
        allowed[ind_id] = tokens

    for ind_id, tokens in SOURCE_TOKEN_OVERRIDES.items():
        allowed.setdefault(ind_id, [])
        allowed[ind_id].extend(tokens)

    for ind_id, tokens in allowed.items():
        allowed[ind_id] = list({token.strip() for token in tokens if token.strip()})

    return allowed


def validate_guardrails(
    pack: dict,
    catalog_map: dict,
    tierb_allowlist: dict | None,
    allowlist_path: Path,
):
    errors = []
    warnings = []
    tier_b_count = 0
    allowlist_ok = 0
    allowlist_fail = 0

    indicators = pack.get("indicators", {})
    allowed_source_tokens = build_allowed_source_tokens(catalog_map)

    for ind_id, entry in indicators.items():
        evidence_tier = entry.get("evidence_tier", "A")
        allowlist_passed = False
        if evidence_tier not in ("A", "B"):
            errors.append(
                f"Evidence tier for {ind_id} must be 'A' or 'B'; got '{evidence_tier}'"
            )
        if evidence_tier == "B":
            tier_b_count += 1
            if tierb_allowlist is None:
                allowlist_fail += 1
                errors.append(
                    f"Tier B allowlist missing at {allowlist_path} for {ind_id}."
                )
            else:
                allowlist_entry = (
                    tierb_allowlist.get("indicators", {}) if isinstance(tierb_allowlist, dict) else {}
                ).get(ind_id)
                if not allowlist_entry:
                    allowlist_fail += 1
                    errors.append(
                        f"Tier B not allowlisted for {ind_id}. Add it to TIERB_ALLOWLIST.v1.json."
                    )
                else:
                    tokens = allowlist_entry.get("allowed_source_institution_tokens", [])
                    domains = allowlist_entry.get("allowed_url_domains", [])
                    required_any = allowlist_entry.get("required_any") or [
                        "source_institution_token",
                        "url_domain",
                    ]
                    source_token_ok = any(
                        token.lower() in source_lower for token in tokens if isinstance(token, str)
                    )
                    url_domains = extract_url_domains(entry.get("url") or "")
                    allowed_domains = {
                        domain.lower() for domain in domains if isinstance(domain, str)
                    }
                    url_domain_ok = any(domain in allowed_domains for domain in url_domains)

                    required_ok = False
                    if "source_institution_token" in required_any and source_token_ok:
                        required_ok = True
                    if "url_domain" in required_any and url_domain_ok:
                        required_ok = True

                    if required_ok:
                        allowlist_passed = True
                        allowlist_ok += 1
                    else:
                        allowlist_fail += 1
                        errors.append(
                            "Tier B allowlist mismatch for "
                            f"{ind_id}. source_institution='{source}', "
                            f"url='{entry.get('url')}', "
                            f"parsed_domains={url_domains or ['missing']}, "
                            f"allowed_tokens={tokens}, allowed_domains={domains}."
                        )
        unit = entry.get("unit")
        expected_units = EXPECTED_UNITS.get(ind_id)
        if expected_units and isinstance(unit, str):
            normalized_unit = normalize_unit(unit)
            normalized_expected = {normalize_unit(u) for u in expected_units}
            if normalized_unit not in normalized_expected:
                errors.append(
                    f"Unit mismatch for {ind_id}: '{unit}' not in {expected_units}"
                )

        if ind_id in A8_CONTRACT_INDICATORS:
            if evidence_tier != "A":
                warnings.append(
                    f"A8 contract warning for {ind_id}: evidence_tier should be 'A' (got '{evidence_tier}')"
                )

            unit_value = entry.get("unit", "")
            if normalize_unit(str(unit_value)) != normalize_unit(A8_EXPECTED_UNIT):
                warnings.append(
                    f"A8 contract warning for {ind_id}: unit should be '{A8_EXPECTED_UNIT}' (got '{unit_value}')"
                )

            period_value = entry.get("period")
            has_int_period = isinstance(period_value, int)
            has_notes_year = extract_year_hint(entry.get("notes", "")) is not None
            if not has_int_period and not has_notes_year:
                warnings.append(
                    f"A8 contract warning for {ind_id}: missing period year (no int period and no year hint in notes)"
                )

        source = entry.get("source_institution", "") or ""
        source_lower = source.lower()
        if ind_id in allowed_source_tokens:
            if not any(token.lower() in source_lower for token in allowed_source_tokens[ind_id]):
                if not (evidence_tier == "B" and allowlist_passed):
                    warnings.append(
                        f"Source warning for {ind_id}: '{source}' not aligned with catalog tokens"
                    )

        url = entry.get("url")
        if isinstance(url, str) and url and "TODO(URL)" not in url:
            url_segments = [segment.strip() for segment in url.split("|") if segment.strip()]
            for segment in url_segments:
                segment_lower = segment.lower()
                for domain, required_tokens in DOMAIN_SOURCE_RULES:
                    if domain in segment_lower:
                        if not any(token in source_lower for token in required_tokens):
                            errors.append(
                                f"URL domain mismatch for {ind_id}: '{domain}' not aligned with '{source}'"
                            )

    return errors, warnings, tier_b_count, allowlist_ok, allowlist_fail


def main():
    parser = argparse.ArgumentParser(description="Validate country pack against schema")
    parser.add_argument("schema", help="Path to country_pack.schema.v1.json")
    parser.add_argument("pack", help="Path to country pack YAML/JSON")
    parser.add_argument(
        "--relaxed",
        action="store_true",
        help="Skip strict guardrails (unit/source/url checks).",
    )
    args = parser.parse_args()

    schema_path = Path(args.schema)
    pack_path = Path(args.pack)

    schema = json.loads(schema_path.read_text(encoding="utf-8"))
    pack = load_yaml_or_json(pack_path)

    errors = validate_schema(pack, schema)
    warnings = []

    if not args.relaxed:
        machine_dir = find_machine_dir(pack_path)
        catalog_map = load_indicator_catalog(machine_dir) if machine_dir else {}
        tierb_allowlist, allowlist_path = load_tierb_allowlist(machine_dir) if machine_dir else (None, Path(""))
        guard_errors, guard_warnings, tier_b_count, allowlist_ok, allowlist_fail = validate_guardrails(
            pack, catalog_map, tierb_allowlist, allowlist_path
        )
        errors.extend(guard_errors)
        warnings.extend(guard_warnings)
    else:
        tier_b_count = sum(
            1
            for entry in pack.get("indicators", {}).values()
            if entry.get("evidence_tier", "A") == "B"
        )
        allowlist_ok = 0
        allowlist_fail = 0

    if errors:
        print("VALIDATION_FAILED")
        for err in errors:
            print(f"- {err}")
        if warnings:
            print("VALIDATION_WARNINGS")
            for warning in warnings:
                print(f"- {warning}")
        print(f"EVIDENCE_TIER_B_COUNT: {tier_b_count}")
        print(f"TIERB_ALLOWLIST_OK: {allowlist_ok}")
        print(f"TIERB_ALLOWLIST_FAIL: {allowlist_fail}")
        sys.exit(1)

    if warnings:
        print("VALIDATION_WARNINGS")
        for warning in warnings:
            print(f"- {warning}")

    print(f"EVIDENCE_TIER_B_COUNT: {tier_b_count}")
    print(f"TIERB_ALLOWLIST_OK: {allowlist_ok}")
    print(f"TIERB_ALLOWLIST_FAIL: {allowlist_fail}")

    print("VALIDATION_OK")


if __name__ == "__main__":
    main()

import json
import time
from pathlib import Path
from typing import Any
import urllib.error
import urllib.request


SCRIPT_DIR = Path(__file__).resolve().parent
CLARUM_ROOT = (SCRIPT_DIR / ".." / "..").resolve()
MACHINE_DIR = CLARUM_ROOT / "04 - Data & Ontology" / "Ontology" / "_machine"
CACHE_DIR = MACHINE_DIR / "cache"
INDICATOR_CACHE = CACHE_DIR / "wb_indicators.json"

WB_INDICATOR_URL = "https://api.worldbank.org/v2/indicator?format=json&per_page=20000"


def _http_get_json(url: str, retries: int = 3, backoff_seconds: float = 1.0) -> Any:
    last_error = None
    for attempt in range(1, retries + 1):
        try:
            with urllib.request.urlopen(url) as response:
                status = response.getcode()
                if status != 200:
                    raise RuntimeError(f"HTTP {status} for {url}")
                return json.loads(response.read().decode("utf-8"))
        except (urllib.error.URLError, RuntimeError, json.JSONDecodeError) as exc:
            last_error = exc
            if attempt < retries:
                time.sleep(backoff_seconds * (2 ** (attempt - 1)))
    raise RuntimeError(f"Failed to fetch {url} after {retries} attempts: {last_error}")


def ensure_indicator_cache(force_refresh: bool = False) -> list[dict]:
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    if INDICATOR_CACHE.exists() and not force_refresh:
        return json.loads(INDICATOR_CACHE.read_text(encoding="utf-8"))
    payload = _http_get_json(WB_INDICATOR_URL)
    indicators = payload[1] if isinstance(payload, list) and len(payload) > 1 else []
    if not indicators:
        raise RuntimeError("World Bank indicator list returned no data.")
    INDICATOR_CACHE.write_text(
        json.dumps(indicators, ensure_ascii=True, indent=2), encoding="utf-8"
    )
    return indicators


def search_indicators(keyword: str) -> list[dict]:
    indicators = ensure_indicator_cache()
    keyword_lower = keyword.lower()
    return [
        item
        for item in indicators
        if keyword_lower in (item.get("name") or "").lower()
        or keyword_lower in (item.get("id") or "").lower()
    ]


def fetch_series(country_code: str, indicator_id: str, per_page: int = 200) -> list[dict]:
    url = (
        f"https://api.worldbank.org/v2/country/{country_code}/indicator/{indicator_id}"
        f"?format=json&per_page={per_page}"
    )
    payload = _http_get_json(url)
    if isinstance(payload, list) and len(payload) > 1 and isinstance(payload[1], list):
        return payload[1]
    return []


def series(country_code: str, indicator_id: str, n_years: int = 10) -> list[tuple[str, float]]:
    raw_series = fetch_series(country_code, indicator_id)
    values: list[tuple[str, float]] = []
    for entry in raw_series:
        if not isinstance(entry, dict):
            continue
        value = entry.get("value")
        if value is None:
            continue
        year = entry.get("date")
        values.append((year, value))
        if len(values) >= n_years:
            break
    if not values:
        raise ValueError(
            f"No data returned for {country_code} {indicator_id}; World Bank API returned no non-null values."
        )
    return values


def latest_value(country_code: str, indicator_id: str) -> tuple[str, float]:
    values = series(country_code, indicator_id, n_years=1)
    year, value = values[0]
    return year, value

import json
import re
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List

ROOT = Path(__file__).resolve().parents[2]
REPORTS = {
    "Hungary": ROOT / "04 - Data & Ontology" / "Ontology" / "_machine" / "reports" / "hungary.ev_oem_export.wp-ev-oem-export-1.1.balanced.report.v1.json",
    "Mexico": ROOT / "04 - Data & Ontology" / "Ontology" / "_machine" / "reports" / "mexico.ev_oem_export.wp-ev-oem-export-1.1.balanced.report.v1.json",
    "Malaysia": ROOT / "04 - Data & Ontology" / "Ontology" / "_machine" / "reports" / "malaysia.semi_osat_export.wp-semi-osat-export-1.1.balanced.report.v1.json",
}

TARGET_DOMAINS = {"A1", "A2", "A4", "A5", "A6"}
YEAR_RE = re.compile(r"\b(19|20)\d{2}\b")


def load_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def extract_year(notes: str, retrieved_date: str | None) -> int | None:
    if notes:
        matches = [int(match.group(0)) for match in YEAR_RE.finditer(notes)]
        if matches:
            return max(matches)
    if retrieved_date:
        try:
            return int(retrieved_date.split("-")[0])
        except (ValueError, IndexError):
            return None
    return None


def indicator_domain(indicator_id: str) -> str:
    parts = indicator_id.split("-")
    return parts[1] if len(parts) > 1 else ""


def build_top_drivers(report: Dict[str, Any]) -> List[Dict[str, Any]]:
    weights = report.get("completeness", {}).get("weights_used", {})
    indicators = report.get("indicators", {})

    domain_order = sorted(weights.items(), key=lambda item: (-item[1], item[0]))
    drivers: List[Dict[str, Any]] = []

    for domain, weight in domain_order:
        for ind_id, ind_data in indicators.items():
            if indicator_domain(ind_id) != domain:
                continue
            if ind_data.get("value") in ("VALUE(TODO)", None):
                continue
            drivers.append({
                "indicator_id": ind_id,
                "domain": domain,
                "weight": weight,
            })
            break

    extra_candidates = [
        {
            "indicator_id": ind_id,
            "domain": indicator_domain(ind_id),
            "weight": weights.get(indicator_domain(ind_id), 0),
        }
        for ind_id, ind_data in indicators.items()
        if indicator_domain(ind_id) in weights
        and ind_data.get("value") not in ("VALUE(TODO)", None)
    ]
    extra_candidates.sort(key=lambda item: (-item["weight"], item["indicator_id"]))

    seen = {item["indicator_id"] for item in drivers}
    for candidate in extra_candidates:
        if candidate["indicator_id"] in seen:
            continue
        drivers.append(candidate)
        seen.add(candidate["indicator_id"])
        if len(drivers) >= 8:
            break

    return drivers[:8]


def extract_fact_table(report: Dict[str, Any]) -> Dict[str, Any]:
    indicators = []
    for ind_id, ind_data in report.get("indicators", {}).items():
        domain = indicator_domain(ind_id)
        if domain not in TARGET_DOMAINS:
            continue
        indicators.append({
            "id": ind_id,
            "domain": domain,
            "value": ind_data.get("value"),
            "unit": ind_data.get("unit"),
            "year": extract_year(ind_data.get("notes", ""), ind_data.get("retrieved_date")),
            "source_institution": ind_data.get("source_institution"),
            "url": ind_data.get("url"),
            "notes": ind_data.get("notes", ""),
        })
    indicators.sort(key=lambda item: item["id"])

    return {
        "completeness": report.get("completeness"),
        "confidence": report.get("confidence"),
        "flags": report.get("flags"),
        "warnings": report.get("warnings"),
        "next_actions": report.get("next_actions"),
        "indicators": indicators,
        "top_drivers": build_top_drivers(report),
    }


def main() -> None:
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M")
    payload = {"timestamp": timestamp, "method": {
        "year_extraction": "max 4-digit year found in notes; fallback to retrieved_date year",
        "top_drivers": "ranked by weights_used domain weight; first non-TODO indicator per domain, then fill to max 8 by weight"
    }, "countries": {}}

    for country, path in REPORTS.items():
        report = load_json(path)
        payload["countries"][country] = extract_fact_table(report)

    runlog_path = ROOT / "04 - Data & Ontology" / "Ontology" / "_machine" / "runlogs" / f"flagship_enterprise_v0_2_phase0_fact_tables_{datetime.now().strftime('%Y-%m-%d_%H%M')}.txt"
    with runlog_path.open("w", encoding="utf-8") as handle:
        handle.write("TIMESTAMP: " + timestamp + "\n")
        handle.write("PHASE: 0 (Fact tables + top drivers)\n\n")
        handle.write(json.dumps(payload, indent=2, sort_keys=True))
        handle.write("\n")


if __name__ == "__main__":
    main()

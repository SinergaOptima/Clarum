import json
import os
import re
from datetime import datetime
from pathlib import Path


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def parse_markdown_table(markdown: str, header_match: str):
    lines = markdown.splitlines()
    tables = []
    for i, line in enumerate(lines):
        if line.strip().startswith("|") and header_match in line:
            header = [c.strip() for c in line.strip().strip("|").split("|")]
            rows = []
            j = i + 1
            while j < len(lines) and lines[j].strip().startswith("|"):
                row_line = lines[j].strip()
                separator_check = row_line.replace("|", "").replace(" ", "").replace("\t", "").strip()
                if separator_check and set(separator_check) <= {"-", ":"}:
                    j += 1
                    continue
                cells = [c.strip() for c in row_line.strip().strip("|").split("|")]
                if len(cells) < len(header):
                    cells += [""] * (len(header) - len(cells))
                rows.append(dict(zip(header, cells)))
                j += 1
            tables.append(rows)
    return tables


def parse_indicator_library_units(markdown: str):
    unit_by_id = {}
    lines = markdown.splitlines()
    header = None
    for i, line in enumerate(lines):
        if line.strip().startswith("|") and "ID" in line and "Measurement" in line:
            header = [c.strip() for c in line.strip().strip("|").split("|")]
            continue
        if header and line.strip().startswith("|"):
            row_line = line.strip()
            separator_check = row_line.replace("|", "").replace(" ", "").replace("\t", "").strip()
            if separator_check and set(separator_check) <= {"-", ":"}:
                continue
            cells = [c.strip() for c in row_line.strip().strip("|").split("|")]
            if len(cells) < len(header):
                cells += [""] * (len(header) - len(cells))
            row = dict(zip(header, cells))
            ind_id = row.get("ID", "").replace("**", "")
            if ind_id.startswith("IND-"):
                unit_by_id[ind_id] = row.get("Measurement", "")
        elif header and line.strip() == "":
            header = None
    return unit_by_id


def normalize_required_by(value: str):
    if not value:
        return []
    if "None" in value:
        return []
    return [v.strip() for v in value.split(",") if v.strip()]


def missingness_policy(value: str) -> str:
    if not value:
        return "optional"
    lower = value.lower()
    if "fatal" in lower:
        return "fatal"
    if "penalty" in lower or "fallback" in lower:
        return "penalty"
    return "optional"


def canonical_urls(value: str):
    if not value or "TODO(URL)" in value:
        return []
    parts = [v.strip() for v in value.split(",")]
    return [p for p in parts if p]


def parse_ops_registry(markdown: str, warnings: list):
    tables = parse_markdown_table(markdown, "Indicator ID")
    if not tables:
        warnings.append("No master indicator table found in ops registry.")
        return []
    rows = tables[0]
    indicators = []
    for row in rows:
        ind_id = row.get("Indicator ID", "").strip()
        if not ind_id:
            continue
        domain_sub = row.get("Domain/Sub-dim", "").strip()
        domain = domain_sub.split(".")[0] if domain_sub else ""
        indicators.append(
            {
                "id": ind_id,
                "domain": domain,
                "sub_dimension": domain_sub,
                "name": row.get("Indicator name", "").strip(),
                "canonical_source_institution": row.get("Canonical source (institution)", "").strip(),
                "canonical_urls": canonical_urls(row.get("Canonical URL(s)", "")),
                "retrieval_method": row.get("Retrieval method", "").strip(),
                "update_cadence": row.get("Update cadence", "").strip(),
                "transform_recipe": row.get("Transform recipe", "").strip(),
                "required_by": normalize_required_by(row.get("Required-by (Critical profiles)", "")),
                "missingness_policy": missingness_policy(row.get("Missingness handling", "")),
                "notes": row.get("Notes", "").strip(),
            }
        )
    return indicators


def build_country_pack_template(indicators, unit_by_id, source_by_id, metadata):
    template = {
        "metadata": metadata,
        "indicators": {},
        "completeness": {
            "per_domain": {
                "A1": "VALUE(TODO)",
                "A2": "VALUE(TODO)",
                "A3": "VALUE(TODO)",
                "A4": "VALUE(TODO)",
                "A5": "VALUE(TODO)",
                "A6": "VALUE(TODO)",
                "A7": "VALUE(TODO)",
                "A8": "VALUE(TODO)",
            },
            "overall": "VALUE(TODO)",
        },
        "overrides": [],
    }
    for ind in indicators:
        ind_id = ind["id"]
        template["indicators"][ind_id] = {
            "value": "VALUE(TODO)",
            "unit": unit_by_id.get(ind_id, ""),
            "source_institution": source_by_id.get(ind_id, "TODO"),
            "url": "TODO(URL)",
            "retrieved_date": "DATE(TODO)",
            "notes": "",
        }
    return template


def main():
    warnings = []
    script_dir = Path(__file__).resolve().parent
    clarum_root = (script_dir / ".." / "..").resolve()

    indicator_library_path = clarum_root / "01 - Framework" / "LRF-1 — Indicator Library (v1).md"
    ops_registry_path = clarum_root / "01 - Framework" / "LRF-1 — Indicator Ops Registry (v1).md"
    template_md_path = clarum_root / "04 - Data & Ontology" / "Ontology" / "LRF-1 — Country Indicator Pack Template (v1).md"
    country_packs_dir = clarum_root / "04 - Data & Ontology" / "Ontology" / "Country Packs"

    machine_dir = clarum_root / "04 - Data & Ontology" / "Ontology" / "_machine"
    machine_packs_dir = machine_dir / "country_packs"
    report_dir = clarum_root / "08 - Operations" / "_reports"

    for path in [machine_dir, machine_packs_dir, report_dir]:
        path.mkdir(parents=True, exist_ok=True)

    if not indicator_library_path.exists():
        warnings.append(f"Missing indicator library: {indicator_library_path}")
    if not ops_registry_path.exists():
        warnings.append(f"Missing ops registry: {ops_registry_path}")
    if not template_md_path.exists():
        warnings.append(f"Missing country pack template: {template_md_path}")

    indicator_library_md = read_text(indicator_library_path) if indicator_library_path.exists() else ""
    ops_registry_md = read_text(ops_registry_path) if ops_registry_path.exists() else ""

    unit_by_id = parse_indicator_library_units(indicator_library_md)
    indicators = parse_ops_registry(ops_registry_md, warnings)

    if not indicators:
        warnings.append("No indicators extracted. Check ops registry table format.")

    source_by_id = {i["id"]: i["canonical_source_institution"] or "TODO" for i in indicators}

    indicator_catalog_path = machine_dir / "indicator_catalog.v1.json"
    indicator_catalog_path.write_text(json.dumps(indicators, indent=2), encoding="utf-8")

    schema = {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "title": "LRF-1 Country Pack v1",
        "type": "object",
        "required": ["metadata", "indicators", "completeness", "overrides"],
        "properties": {
            "metadata": {
                "type": "object",
                "required": [
                    "country",
                    "date",
                    "comparator_set_id",
                    "normalization_method",
                    "rubric_version",
                    "profiles",
                    "sector_assumptions",
                    "data_owner",
                    "data_retrieval_window",
                ],
                "properties": {
                    "country": {"type": "string"},
                    "date": {"type": "string"},
                    "comparator_set_id": {"type": "string"},
                    "normalization_method": {"type": "string"},
                    "rubric_version": {"type": "string"},
                    "profiles": {"type": "array", "items": {"type": "string"}},
                    "sector_assumptions": {"type": "string"},
                    "data_owner": {"type": "string"},
                    "data_retrieval_window": {"type": "string"},
                },
            },
            "indicators": {
                "type": "object",
                "patternProperties": {
                    "^IND-[A-Z0-9-]+$": {
                        "type": "object",
                        "required": ["value", "unit", "source_institution", "url", "retrieved_date", "notes"],
                        "properties": {
                            "value": {"type": ["string", "number", "null"]},
                            "unit": {"type": "string"},
                            "source_institution": {"type": "string"},
                            "url": {"type": ["string", "null"]},
                            "retrieved_date": {"type": "string"},
                            "notes": {"type": "string"},
                        },
                    }
                },
                "additionalProperties": False,
            },
            "completeness": {
                "type": "object",
                "required": ["per_domain", "overall"],
                "properties": {
                    "per_domain": {"type": "object"},
                    "overall": {"type": ["string", "number", "null"]},
                },
            },
            "overrides": {"type": "array"},
        },
    }

    schema_path = machine_dir / "country_pack.schema.v1.json"
    schema_path.write_text(json.dumps(schema, indent=2), encoding="utf-8")

    base_metadata = {
        "country": "TODO",
        "date": datetime.now().strftime("%Y-%m-%d"),
        "comparator_set_id": "GLOBAL-GDP-10B+",
        "normalization_method": "PERCENTILE-RANK",
        "rubric_version": "LRF-1.1",
        "profiles": ["TODO"],
        "sector_assumptions": "TODO",
        "data_owner": "Lattice Labs — Research Ops",
        "data_retrieval_window": "DATE(TODO)",
    }

    template = build_country_pack_template(indicators, unit_by_id, source_by_id, base_metadata)
    template_path = machine_dir / "country_pack_template.v1.yaml"
    template_path.write_text(json.dumps(template, indent=2), encoding="utf-8")

    country_profiles = {
        "Hungary": ["WP-EV-OEM-EXPORT-1.1"],
        "Mexico": ["WP-EV-OEM-EXPORT-1.1"],
        "Malaysia": ["WP-SEMI-OSAT-EXPORT-1.1"],
    }
    country_assumptions = {
        "Hungary": "EV OEM export hub (EU market)",
        "Mexico": "EV OEM export hub (USMCA)",
        "Malaysia": "Semiconductor OSAT export hub",
    }

    pack_files = list(country_packs_dir.glob("Country Pack — *.md")) if country_packs_dir.exists() else []
    for md_file in pack_files:
        name_match = re.match(r"Country Pack — (.+) \(LRF-1 v1\)\.md", md_file.name)
        if not name_match:
            warnings.append(f"Country pack name not matched: {md_file.name}")
            continue
        country = name_match.group(1)
        metadata = dict(base_metadata)
        metadata["country"] = country
        metadata["profiles"] = country_profiles.get(country, ["TODO"])
        metadata["sector_assumptions"] = country_assumptions.get(country, "TODO")

        pack = build_country_pack_template(indicators, unit_by_id, source_by_id, metadata)
        out_name = f"{country.lower()}.v1.yaml"
        (machine_packs_dir / out_name).write_text(json.dumps(pack, indent=2), encoding="utf-8")

    report_path = report_dir / f"lrf_machine_export_{datetime.now().strftime('%Y-%m-%d_%H%M')}.txt"
    report_lines = [
        f"TIMESTAMP: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        f"INDICATORS_EXTRACTED: {len(indicators)}",
        f"WARNINGS_COUNT: {len(warnings)}",
        "WARNINGS:",
        *warnings,
    ]
    report_path.write_text("\n".join(report_lines), encoding="utf-8")

    print(f"INDICATORS_EXTRACTED: {len(indicators)}")
    print(f"WARNINGS_COUNT: {len(warnings)}")


if __name__ == "__main__":
    main()

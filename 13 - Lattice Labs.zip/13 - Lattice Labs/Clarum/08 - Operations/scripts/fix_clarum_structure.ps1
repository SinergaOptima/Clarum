param(
    [switch]$DryRun,
    [switch]$Apply
)

$ErrorActionPreference = "Stop"

$IsDryRun = $true
if ($Apply) {
    $IsDryRun = $false
} elseif ($DryRun) {
    $IsDryRun = $true
}

function Get-RelativePath {
    param(
        [Parameter(Mandatory = $true)][string]$BasePath,
        [Parameter(Mandatory = $true)][string]$FullPath
    )
    $base = (Resolve-Path $BasePath).Path.TrimEnd("\\") + "\\"
    $full = (Resolve-Path $FullPath).Path
    if ($full.StartsWith($base, [System.StringComparison]::OrdinalIgnoreCase)) {
        return $full.Substring($base.Length)
    }
    return $full
}

function Ensure-Directory {
    param([string]$Path)
    if ([string]::IsNullOrWhiteSpace($Path)) {
        return
    }
    if (-not (Test-Path -LiteralPath $Path)) {
        if (-not $IsDryRun) {
            New-Item -ItemType Directory -Path $Path -Force | Out-Null
        }
        $script:ReportLines += "CREATE DIR: $Path"
    }
}

function Get-FileHashSafe {
    param([string]$Path)
    return (Get-FileHash -Algorithm SHA256 -LiteralPath $Path).Hash
}

function Print-Tree {
    param([string]$Root)
    Write-Host "" 
    Write-Host "TREE (2 levels): $Root"
    Get-ChildItem -LiteralPath $Root -Force -Recurse -Depth 2 | ForEach-Object {
        $rel = Get-RelativePath -BasePath $Root -FullPath $_.FullName
        if ($_.PSIsContainer) {
            Write-Host "[D] $rel"
        } else {
            Write-Host "[F] $rel"
        }
    }
}

$ScriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$ClarumRoot = Resolve-Path (Join-Path $ScriptRoot "..\..")

$DataRoot = Join-Path $ClarumRoot "Data"
$FrameworkRoot = Join-Path $ClarumRoot "Framework"
$DestFrameworkRoot = Join-Path $ClarumRoot "01 - Framework"
$DestDataRoot = Join-Path $ClarumRoot "04 - Data & Ontology"
$ArchiveRoot = Join-Path $ClarumRoot "99 - Archive\_duplicates"
$ReportDir = Join-Path $ClarumRoot "08 - Operations\_reports"
$ReportStamp = Get-Date -Format "yyyy-MM-dd_HHmm"
$ReportPath = Join-Path $ReportDir "fix_clarum_structure_$ReportStamp.txt"

$ReportLines = @()
$ReportLines += "MODE: " + $(if ($IsDryRun) { "DryRun" } else { "Apply" })
$ReportLines += "CLARUM ROOT: $ClarumRoot"
$ReportLines += "TIMESTAMP: $(Get-Date -Format "yyyy-MM-dd HH:mm:ss")"

Print-Tree -Root $ClarumRoot

if (Test-Path -LiteralPath $DataRoot) {
    $dataCount = (Get-ChildItem -LiteralPath $DataRoot -File -Recurse | Measure-Object).Count
} else {
    $dataCount = 0
}
if (Test-Path -LiteralPath $FrameworkRoot) {
    $frameworkCount = (Get-ChildItem -LiteralPath $FrameworkRoot -File -Recurse | Measure-Object).Count
} else {
    $frameworkCount = 0
}

Write-Host ""
Write-Host "FILE COUNT: $DataRoot -> $dataCount"
Write-Host "FILE COUNT: $FrameworkRoot -> $frameworkCount"

$ReportLines += "FILE COUNT: Data = $dataCount"
$ReportLines += "FILE COUNT: Framework = $frameworkCount"

$Moves = @()
$Duplicates = @()
$Collisions = @()
$LinkUpdates = @()

function Process-Root {
    param(
        [string]$SourceRoot,
        [string]$DestRoot
    )

    if (-not (Test-Path -LiteralPath $SourceRoot)) {
        return
    }

    Ensure-Directory -Path $DestRoot

    $files = Get-ChildItem -LiteralPath $SourceRoot -File -Recurse
    foreach ($file in $files) {
        $rel = $file.FullName.Substring($SourceRoot.Length).TrimStart([char[]]"\\/")
        $destPath = Join-Path $DestRoot $rel
        $destDir = Split-Path -Parent $destPath
        Ensure-Directory -Path $destDir

        if (Test-Path -LiteralPath $destPath) {
            $srcSize = (Get-Item -LiteralPath $file.FullName).Length
            $destSize = (Get-Item -LiteralPath $destPath).Length
            $srcHash = Get-FileHashSafe -Path $file.FullName
            $destHash = Get-FileHashSafe -Path $destPath

            if (($srcSize -eq $destSize) -and ($srcHash -eq $destHash)) {
                $Duplicates += "DUPLICATE IDENTICAL: $($file.FullName) -> $destPath"
                continue
            }

            $relFromClarum = Get-RelativePath -BasePath $ClarumRoot -FullPath $file.FullName
            $archivePath = Join-Path $ArchiveRoot (Join-Path (Get-Date -Format "yyyy-MM-dd") $relFromClarum)
            $archiveDir = Split-Path -Parent $archivePath
            Ensure-Directory -Path $archiveDir

            if (Test-Path -LiteralPath $archivePath) {
                $base = [System.IO.Path]::GetFileNameWithoutExtension($archivePath)
                $ext = [System.IO.Path]::GetExtension($archivePath)
                $archivePath = Join-Path $archiveDir ("{0}_dup{1}{2}" -f $base, (Get-Date -Format "HHmmss"), $ext)
            }

            if (-not $IsDryRun) {
                Move-Item -LiteralPath $file.FullName -Destination $archivePath
            }
            $Collisions += "COLLISION ARCHIVED: $($file.FullName) -> $archivePath"
            continue
        }

        if (-not $IsDryRun) {
            Move-Item -LiteralPath $file.FullName -Destination $destPath
        }
        $Moves += "MOVED: $($file.FullName) -> $destPath"
    }
}

Process-Root -SourceRoot $FrameworkRoot -DestRoot $DestFrameworkRoot
Process-Root -SourceRoot $DataRoot -DestRoot $DestDataRoot

function Remove-IfEmpty {
    param([string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) {
        return
    }
    $files = Get-ChildItem -LiteralPath $Path -Recurse -File -Force
    if ($files.Count -eq 0) {
        if (-not $IsDryRun) {
            Remove-Item -LiteralPath $Path -Recurse -Force
        }
        $script:ReportLines += "REMOVED EMPTY DIR: $Path"
    }
}

Remove-IfEmpty -Path $FrameworkRoot
Remove-IfEmpty -Path $DataRoot

$mdFiles = Get-ChildItem -LiteralPath $ClarumRoot -Recurse -Filter "*.md" -File
foreach ($md in $mdFiles) {
    $content = Get-Content -LiteralPath $md.FullName -Raw
    $updated = $content.Replace("(Data/", "(04 - Data & Ontology/")
    $updated = $updated.Replace("](Data/", "](04 - Data & Ontology/")
    $updated = $updated.Replace("(Framework/", "(01 - Framework/")
    $updated = $updated.Replace("](Framework/", "](01 - Framework/")

    if ($updated -ne $content) {
        $LinkUpdates += "LINK UPDATED: $($md.FullName)"
        if (-not $IsDryRun) {
            Set-Content -LiteralPath $md.FullName -Value $updated
        }
    }
}

$ReportLines += ""
$ReportLines += "MOVES:"
$ReportLines += $Moves
$ReportLines += ""
$ReportLines += "DUPLICATE IDENTICAL:"
$ReportLines += $Duplicates
$ReportLines += ""
$ReportLines += "COLLISION ARCHIVED:"
$ReportLines += $Collisions
$ReportLines += ""
$ReportLines += "LINK UPDATES:"
$ReportLines += $LinkUpdates

if (-not (Test-Path -LiteralPath $ReportDir)) {
    New-Item -ItemType Directory -Path $ReportDir -Force | Out-Null
}
Set-Content -LiteralPath $ReportPath -Value $ReportLines

Write-Host ""
Write-Host "REPORT: $ReportPath"

if (-not $IsDryRun) {
    Print-Tree -Root $ClarumRoot
}
